package com.bt.service;

import java.util.List;

import com.bt.entity.ReportData;

public interface ReportDataService {

	public List<ReportData> getAllReports();
}
