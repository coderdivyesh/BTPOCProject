package com.bt.common;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bt.config.CassandraSessionFactory;
import com.bt.entity.ReportData;
import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Row;
import com.datastax.driver.core.Statement;
import com.datastax.driver.core.querybuilder.QueryBuilder;

/**
 * This utility class holds all crud operation
 * 
 * @author 611022163
 *
 */
public class CassandraReportDataQueryUtil extends CassandraSessionFactory {
    
	private static final String OPENEDAT = "openedat";

	private static final String NAME = "name";

	private static final String ID = "id";

	private static final Logger logger = LoggerFactory.getLogger(CassandraReportDataQueryUtil.class);
	
	private int fetchsize=5;

	public int getFetchsize() {
		return fetchsize;
	}


	public void setFetchsize(int fetchsize) {
		this.fetchsize = fetchsize;
	}

	/**
	 * This method will ftech report for event-list table
	 * 
	 * @return
	 */
	public List<ReportData> selectAllReportData() {
		Statement statement = buildQuery(ReportData.class);
		ResultSet resultset = getSession().execute(statement);
		return processResultSet(resultset);
	}

	/**
	 * Build query according to parameter
	 * @param claz
	 * @return
	 */
	private Statement buildQuery(Class claz) {
		return QueryBuilder.select().all().from("event_live").setFetchSize(fetchsize);
	
	}

	/**
	 * This method will map query result with report data.
	 * It explicitly hard cord as going to deal with single table.
	 * 
	 * @param resultset
	 * @param reportdata
	 * @param list
	 * @throws Exception
	 */
	public List<ReportData>  processResultSet(ResultSet resultset){
		List<ReportData>  reportlist=new ArrayList<ReportData>();
		int count=0;
	
		for (Row row : resultset) {
			if(count<=fetchsize){
			count=count+1;
			//ReportData report = (ReportData) reportdata.newInstance();
			ReportData report=new ReportData();
			report.setId(row.getLong("id"));
			report.setName(row.getString("name"));
			report.setOpenedat(row.getInt("openedat"));
			report.setAcknowledged(row.getByte("acknowledged"));
			report.setAcknowledgedFirstUser(row.getString("acknowledgedFirstUser"));
			report.setActive(row.getByte("active"));
			report.setCategory(row.getString("category"));
			report.setCertainty(row.getFloat("certainty"));
			report.setClassdisplayname(row.getString("classdisplayname"));
			report.setClassName(row.getString("classname"));
			report.setCloseDat(row.getInt("closedat"));
			report.setDuration(row.getInt("duration"));
			report.setElementclassname(row.getString("elementclassname"));
			report.setElementname(row.getString("elementname"));
			report.setEventdisplayname(row.getString("eventdisplayname"));
			report.setEventname(row.getString("eventname"));
			report.setEventtext(row.getString("eventtext"));
			report.setEventtype(row.getString("eventtype"));
			report.setFirstnotifiedat(row.getInt("firstnotifiedat"));
			report.setFirsttimetoacknowledged(row.getInt("firsttimetoacknowledged"));
			report.setFirsttimetoowner(row.getInt("firsttimetoowner"));
			report.setFirsttimetotroubleticketid(row.getInt("firsttimetotroubleticketid"));
			report.setImpact(row.getLong("impact"));
			report.setInmaintenance(row.getByte("inmaintenance"));
			report.setInstancedisplayname(row.getString("instancedisplayname"));
			report.setInstancename(row.getString("instancename"));
			report.setIsproblem(row.getByte("isproblem"));
			report.setIsroot(row.getByte("isroot"));
			report.setIsrootfirstvalue(row.getByte("isrootfirstvalue"));
			report.setLastchangedat(row.getInt("lastchangedat"));
			report.setOccurrencecount(row.getInt("occurrencecount"));
			report.setOwner(row.getString("owner"));
			report.setOwnerfirstuser(row.getString("ownerfirstuser"));
			report.setSeverity(row.getByte("severity"));
			report.setSource(row.getString("source"));
			report.setSourcedomainname(row.getString("sourcedomainname"));
			report.setSourceeventtype(row.getString("sourceeventtype"));
			report.setTroubleticketid(row.getString("troubleticketid"));
			report.setTroubleticketidfirstvalue(row.getString("troubleticketidfirstvalue"));
			report.setUpdatedat(row.getInt("updatedat"));
			report.setUserdefined1(row.getString("userdefined1"));
			report.setUserdefined2(row.getString("userdefined2"));
			report.setUserdefined3(row.getString("userdefined3"));
			report.setUserdefined4(row.getString("userdefined4"));
			report.setUserdefined5(row.getString("userdefined5"));
			report.setUserdefined6(row.getString("userdefined6"));
			report.setUserdefined7(row.getString("userdefined7"));
			report.setUserdefined8(row.getString("userdefined8"));
			report.setUserdefined9(row.getString("userdefined9"));
			report.setUserdefined10(row.getString("userdefined10"));
			report.setUserdefined11(row.getString("userdefined11"));
			report.setUserdefined12(row.getString("userdefined12"));
			report.setUserdefined13(row.getString("userdefined13"));
			report.setUserdefined14(row.getString("userdefined14"));
			report.setUserdefined15(row.getString("userdefined15"));
			report.setUserdefined16(row.getString("userdefined16"));
			report.setUserdefined17(row.getString("userdefined17"));
			report.setUserdefined18(row.getString("userdefined18"));
			report.setUserdefined19(row.getString("userdefined19"));
			report.setUserdefined20(row.getString("userdefined20"));
			reportlist.add(report);
			}else{
				break;
			}
		}
      return reportlist;
		}





	

}
