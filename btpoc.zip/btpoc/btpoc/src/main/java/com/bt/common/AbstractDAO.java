package com.bt.common;

import java.io.Serializable;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bt.entity.ReportData;

@Repository
public class AbstractDAO extends CassandraReportDataQueryUtil implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 3530428536344475625L;

	

      public List<ReportData> selectAll(){
    	  return selectAllReportData();
      }

}
