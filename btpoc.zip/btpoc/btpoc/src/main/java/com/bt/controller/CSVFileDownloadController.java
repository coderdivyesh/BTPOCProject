package com.bt.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.supercsv.io.CsvBeanWriter;
import org.supercsv.io.ICsvBeanWriter;
import org.supercsv.prefs.CsvPreference;

import com.bt.common.CassandraReportDataQueryUtil;
import com.bt.entity.ReportData;


@RestController
public class CSVFileDownloadController {
	//private String filePath = "C:/Users/611022675/Downloads/report_data.csv";
	//private static final int BUFFER_SIZE = 4096;
	
	@RequestMapping(value = "/csvReportData", method = RequestMethod.GET)
	public void downloadCSV(HttpServletRequest request, HttpServletResponse response) throws IOException {
		String csvFileName = "report_data.csv";
		response.setContentType("text/csv");
        String headerKey = "Content-Disposition";
        String headerValue = String.format("attachment; filename=\"%s\"",csvFileName);
        response.setHeader(headerKey, headerValue);
		ICsvBeanWriter csvWriter = new CsvBeanWriter(response.getWriter(), CsvPreference.STANDARD_PREFERENCE);
		String[] header = { "id", "name", "openedat", "acknowledged", "acknowledgedfirstuser", "active", "category",
				"certainty", "classdisplayname", "classname", "closedat", "duration", "elementclassname", "elementname",
				"eventdisplayname", "eventname", "eventtext", "eventtype", "firstnotifiedat", "firsttimetoacknowledged",
				"firsttimetoowner", "firsttimetotroubleticketid", "impact", "inmaintenance", "instancedisplayname",
				"instancename", "isproblem", "isroot", "isrootfirstvalue", "lastchangedat", "occurrencecount", "owner",
				"ownerfirstuser", "severity", "source", "sourcedomainname", "sourceeventtype", "troubleticketid",
				"troubleticketidfirstvalue", "updatedat", "userdefined1", "userdefined2", "userdefined3",
				"userdefined4", "userdefined5", "userdefined6", "userdefined7", "userdefined8", "userdefined9",
				"userdefined10", "userdefined11", "userdefined12", "userdefined13", "userdefined14", "userdefined15",
				"userdefined16", "userdefined17", "userdefined18", "userdefined19", "userdefined20" };
		
		csvWriter.writeHeader(header);
		CassandraReportDataQueryUtil query=new CassandraReportDataQueryUtil();
		List<ReportData> reportDataList=query.selectAllReportData();
		 for (ReportData list : reportDataList) {
	            csvWriter.write(list, header);
	        }
		csvWriter.close();
		}
	}


