package com.bt.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bt.entity.ReportData;
import com.bt.service.ReportDataService;

@RestController
@RequestMapping("/report")
public class ReportDataController {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ReportDataController.class);

	@Autowired
	ReportDataService reportDataService;

	@RequestMapping(value = "/getRowReport", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<ReportData>> getAllReportData(@RequestBody ReportData reportData) {
		List<ReportData> reportdatalist=reportDataService.getAllReports();
		return new ResponseEntity<List<ReportData>>(reportdatalist, HttpStatus.OK);
	}

}
