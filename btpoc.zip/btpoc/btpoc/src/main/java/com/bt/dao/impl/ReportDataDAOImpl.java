package com.bt.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bt.common.AbstractDAO;
import com.bt.dao.ReportDataDAO;
import com.bt.entity.ReportData;

@Repository
public class ReportDataDAOImpl implements ReportDataDAO {

	@Autowired
	 AbstractDAO abstractDAO;

	public List<ReportData> getAllReportData() {
		return null;
	}

	public List<ReportData> getAllReports(){
		return abstractDAO.selectAll();
	}

	
}
