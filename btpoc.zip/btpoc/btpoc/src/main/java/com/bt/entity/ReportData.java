package com.bt.entity;

import java.io.Serializable;

import com.datastax.driver.core.querybuilder.Ordering;
import com.datastax.driver.mapping.annotations.Column;
import com.datastax.driver.mapping.annotations.PartitionKey;
import com.datastax.driver.mapping.annotations.Table;

@Table(name = "event_live")
public class ReportData implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7989810572276469598L;
	public ReportData(){};

	 //@PrimaryKeyColumn(name = "id", ordinal = 0, ordering = Ordering.ASCENDING)
	@PartitionKey
	@Column(name = "id")
	private long id;
	
	@PartitionKey
	 @Column(name = "name")
	 private String name;
	 
	 @Column(name = "openedat")
	 private int openedat;
	 
	@Column(name = "acknowledged")
	private byte acknowledged;
	
	@Column(name = "acknowledgedfirstuser")
	private String acknowledgedFirstUser;
	 
	@Column(name = "active")
	private byte active;
	
	@Column(name = "category")
	private String category;
	
	@Column(name = "certainty")
	private float certainty;
		 
	 @Column(name = "classdisplayname") 
	 private String classdisplayname;
			
	@Column(name = "classname")
	 private String className;
	 
	@Column(name = "closedat")
	private int closeDat;
	
	@Column(name = "duration")
	private int duration;
	
	@Column(name = "elementclassname")
	private String elementclassname;
		 
	@Column(name = "elementname")
	private String elementname;
		 
	@Column(name = "eventdisplayname")
	private String eventdisplayname;
		 
	@Column(name = "eventname")
	private String eventname;
	
	@Column(name = "eventtext")
	private String eventtext;
	
	@Column(name = "eventtype")
	private String eventtype;
	
	@Column(name = "firstnotifiedat")
	private int firstnotifiedat;
	
	@Column(name = "firsttimetoacknowledged")
	private int firsttimetoacknowledged;
	
	@Column(name = "firsttimetoowner")
	private int firsttimetoowner;
	
	@Column(name = "firsttimetotroubleticketid")
	private int firsttimetotroubleticketid;
	
	@Column(name = "impact")
	private long impact;
	
	@Column(name = "inmaintenance")
	private byte inmaintenance;
	
	@Column(name = "instancedisplayname") 
	private String instancedisplayname;
		
	@Column(name = "instancename")
	private String instancename;
	
	@Column(name = "isproblem")
	private byte isproblem;
	
	@Column(name = "isroot")
	private byte isroot;
	 
	@Column(name = "isrootfirstvalue")
	private byte isrootfirstvalue;
	
	@Column(name = "lastchangedat")
	private int lastchangedat;
	
	@Column(name = "occurrencecount")
	private int occurrencecount;
	 
	@Column(name = "owner")
	private String owner;

	@Column(name = "ownerfirstuser")
	private String ownerfirstuser;
	 
	@Column(name = "severity")
	private byte severity;
	
	@Column(name = "source")
	private String source;
	 
	@Column(name = "sourcedomainname")	 
	private String sourcedomainname;
	  
	@Column(name = "sourceeventtype")
	private String sourceeventtype;
	 
	@Column(name = "troubleticketid")
	private String troubleticketid;
	
	@Column(name = "troubleticketidfirstvalue")
	private String troubleticketidfirstvalue;
	
	@Column(name = "updatedat")
	private int updatedat;
	
	@Column(name = "userdefined1")
	private String userdefined1;
	 
	@Column(name = "userdefined2")
	private String userdefined2;
	 
	 @Column(name = "userdefined3")
	 private String userdefined3;
	 
	@Column(name = "userdefined4")
	 private String userdefined4;
	 
	@Column(name = "userdefined5")
	 private String userdefined5;
	 
	@Column(name = "userdefined6")
	 private String userdefined6;
	 
	@Column(name = "userdefined7")
	 private String userdefined7;
	 
	@Column(name = "userdefined8")
	 private String userdefined8;
	 
	@Column(name = "userdefined9")
	 private String userdefined9;
	 
	@Column(name = "userdefined10")
	 private String userdefined10;
	 
	@Column(name = "userdefined11")
	 private String userdefined11;
	 
	 @Column(name = "userdefined12")
	 private String userdefined12;
	 
	 @Column(name = "userdefined13")
	 private String userdefined13;
	 
	 @Column(name = "userdefined14")
	 private String userdefined14;
	 
	@Column(name = "userdefined15")
	 private String userdefined15;
	 
	@Column(name = "userdefined16")
	 private String userdefined16;
	 
	@Column(name = "userdefined17")
	 private String userdefined17;
	 
	@Column(name = "userdefined18")
	 private String userdefined18;
	
	@Column(name = "userdefined19")
	 private String userdefined19;
	 
	 @Column(name = "userdefined20")
	 private String userdefined20;
	 
	 public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getOpenedat() {
		return openedat;
	}

	public void setOpenedat(int openedat) {
		this.openedat = openedat;
	}

	public byte getAcknowledged() {
		return acknowledged;
	}

	public void setAcknowledged(byte acknowledged) {
		this.acknowledged = acknowledged;
	}

	public String getAcknowledgedFirstUser() {
		return acknowledgedFirstUser;
	}

	public void setAcknowledgedFirstUser(String acknowledgedFirstUser) {
		this.acknowledgedFirstUser = acknowledgedFirstUser;
	}

	public byte getActive() {
		return active;
	}

	public void setActive(byte active) {
		this.active = active;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public float getCertainty() {
		return certainty;
	}

	public void setCertainty(float certainty) {
		this.certainty = certainty;
	}

	public String getClassdisplayname() {
		return classdisplayname;
	}

	public void setClassdisplayname(String classdisplayname) {
		this.classdisplayname = classdisplayname;
	}

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public int getCloseDat() {
		return closeDat;
	}

	public void setCloseDat(int closeDat) {
		this.closeDat = closeDat;
	}

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	public String getElementclassname() {
		return elementclassname;
	}

	public void setElementclassname(String elementclassname) {
		this.elementclassname = elementclassname;
	}

	public String getElementname() {
		return elementname;
	}

	public void setElementname(String elementname) {
		this.elementname = elementname;
	}

	public String getEventdisplayname() {
		return eventdisplayname;
	}

	public void setEventdisplayname(String eventdisplayname) {
		this.eventdisplayname = eventdisplayname;
	}

	public String getEventname() {
		return eventname;
	}

	public void setEventname(String eventname) {
		this.eventname = eventname;
	}

	public String getEventtext() {
		return eventtext;
	}

	public void setEventtext(String eventtext) {
		this.eventtext = eventtext;
	}

	public String getEventtype() {
		return eventtype;
	}

	public void setEventtype(String eventtype) {
		this.eventtype = eventtype;
	}

	public int getFirstnotifiedat() {
		return firstnotifiedat;
	}

	public void setFirstnotifiedat(int firstnotifiedat) {
		this.firstnotifiedat = firstnotifiedat;
	}

	public int getFirsttimetoacknowledged() {
		return firsttimetoacknowledged;
	}

	public void setFirsttimetoacknowledged(int firsttimetoacknowledged) {
		this.firsttimetoacknowledged = firsttimetoacknowledged;
	}

	public int getFirsttimetoowner() {
		return firsttimetoowner;
	}

	public void setFirsttimetoowner(int firsttimetoowner) {
		this.firsttimetoowner = firsttimetoowner;
	}

	public int getFirsttimetotroubleticketid() {
		return firsttimetotroubleticketid;
	}

	public void setFirsttimetotroubleticketid(int firsttimetotroubleticketid) {
		this.firsttimetotroubleticketid = firsttimetotroubleticketid;
	}

	public long getImpact() {
		return impact;
	}

	public void setImpact(long impact) {
		this.impact = impact;
	}

	public byte getInmaintenance() {
		return inmaintenance;
	}

	public void setInmaintenance(byte inmaintenance) {
		this.inmaintenance = inmaintenance;
	}

	public String getInstancedisplayname() {
		return instancedisplayname;
	}

	public void setInstancedisplayname(String instancedisplayname) {
		this.instancedisplayname = instancedisplayname;
	}

	public String getInstancename() {
		return instancename;
	}

	public void setInstancename(String instancename) {
		this.instancename = instancename;
	}

	public byte getIsproblem() {
		return isproblem;
	}

	public void setIsproblem(byte isproblem) {
		this.isproblem = isproblem;
	}

	public byte getIsroot() {
		return isroot;
	}

	public void setIsroot(byte isroot) {
		this.isroot = isroot;
	}

	public byte getIsrootfirstvalue() {
		return isrootfirstvalue;
	}

	public void setIsrootfirstvalue(byte isrootfirstvalue) {
		this.isrootfirstvalue = isrootfirstvalue;
	}

	public int getLastchangedat() {
		return lastchangedat;
	}

	public void setLastchangedat(int lastchangedat) {
		this.lastchangedat = lastchangedat;
	}

	public int getOccurrencecount() {
		return occurrencecount;
	}

	public void setOccurrencecount(int occurrencecount) {
		this.occurrencecount = occurrencecount;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public String getOwnerfirstuser() {
		return ownerfirstuser;
	}

	public void setOwnerfirstuser(String ownerfirstuser) {
		this.ownerfirstuser = ownerfirstuser;
	}

	public byte getSeverity() {
		return severity;
	}

	public void setSeverity(byte severity) {
		this.severity = severity;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getSourcedomainname() {
		return sourcedomainname;
	}

	public void setSourcedomainname(String sourcedomainname) {
		this.sourcedomainname = sourcedomainname;
	}

	public String getSourceeventtype() {
		return sourceeventtype;
	}

	public void setSourceeventtype(String sourceeventtype) {
		this.sourceeventtype = sourceeventtype;
	}

	public String getTroubleticketid() {
		return troubleticketid;
	}

	public void setTroubleticketid(String troubleticketid) {
		this.troubleticketid = troubleticketid;
	}

	public String getTroubleticketidfirstvalue() {
		return troubleticketidfirstvalue;
	}

	public void setTroubleticketidfirstvalue(String troubleticketidfirstvalue) {
		this.troubleticketidfirstvalue = troubleticketidfirstvalue;
	}

	public int getUpdatedat() {
		return updatedat;
	}

	public void setUpdatedat(int updatedat) {
		this.updatedat = updatedat;
	}

	public String getUserdefined1() {
		return userdefined1;
	}

	public void setUserdefined1(String userdefined1) {
		this.userdefined1 = userdefined1;
	}

	public String getUserdefined2() {
		return userdefined2;
	}

	public void setUserdefined2(String userdefined2) {
		this.userdefined2 = userdefined2;
	}

	public String getUserdefined3() {
		return userdefined3;
	}

	public void setUserdefined3(String userdefined3) {
		this.userdefined3 = userdefined3;
	}

	public String getUserdefined4() {
		return userdefined4;
	}

	public void setUserdefined4(String userdefined4) {
		this.userdefined4 = userdefined4;
	}

	public String getUserdefined5() {
		return userdefined5;
	}

	public void setUserdefined5(String userdefined5) {
		this.userdefined5 = userdefined5;
	}

	public String getUserdefined6() {
		return userdefined6;
	}

	public void setUserdefined6(String userdefined6) {
		this.userdefined6 = userdefined6;
	}

	public String getUserdefined7() {
		return userdefined7;
	}

	public void setUserdefined7(String userdefined7) {
		this.userdefined7 = userdefined7;
	}

	public String getUserdefined8() {
		return userdefined8;
	}

	public void setUserdefined8(String userdefined8) {
		this.userdefined8 = userdefined8;
	}

	public String getUserdefined9() {
		return userdefined9;
	}

	public void setUserdefined9(String userdefined9) {
		this.userdefined9 = userdefined9;
	}

	public String getUserdefined10() {
		return userdefined10;
	}

	public void setUserdefined10(String userdefined10) {
		this.userdefined10 = userdefined10;
	}

	public String getUserdefined11() {
		return userdefined11;
	}

	public void setUserdefined11(String userdefined11) {
		this.userdefined11 = userdefined11;
	}

	public String getUserdefined12() {
		return userdefined12;
	}

	public void setUserdefined12(String userdefined12) {
		this.userdefined12 = userdefined12;
	}

	public String getUserdefined13() {
		return userdefined13;
	}

	public void setUserdefined13(String userdefined13) {
		this.userdefined13 = userdefined13;
	}

	public String getUserdefined14() {
		return userdefined14;
	}

	public void setUserdefined14(String userdefined14) {
		this.userdefined14 = userdefined14;
	}

	public String getUserdefined15() {
		return userdefined15;
	}

	public void setUserdefined15(String userdefined15) {
		this.userdefined15 = userdefined15;
	}

	public String getUserdefined16() {
		return userdefined16;
	}

	public void setUserdefined16(String userdefined16) {
		this.userdefined16 = userdefined16;
	}

	public String getUserdefined17() {
		return userdefined17;
	}

	public void setUserdefined17(String userdefined17) {
		this.userdefined17 = userdefined17;
	}

	public String getUserdefined18() {
		return userdefined18;
	}

	public void setUserdefined18(String userdefined18) {
		this.userdefined18 = userdefined18;
	}

	public String getUserdefined19() {
		return userdefined19;
	}

	public void setUserdefined19(String userdefined19) {
		this.userdefined19 = userdefined19;
	}

	public String getUserdefined20() {
		return userdefined20;
	}

	public void setUserdefined20(String userdefined20) {
		this.userdefined20 = userdefined20;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	

	 
	 
	 
}
