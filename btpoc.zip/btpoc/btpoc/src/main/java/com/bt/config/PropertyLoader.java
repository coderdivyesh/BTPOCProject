package com.bt.config;

import java.io.InputStream;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PropertyLoader {
	private static final String CASSANDRA_PROPERTIES = "/cassandra.properties";
	private static final Logger logger = LoggerFactory.getLogger(PropertyLoader.class);
	private static PropertyLoader instance = null;
	private static Properties configProp;
	

	private PropertyLoader() {
	   }
/**
 * 
 * @return
 */
	 public static PropertyLoader getInstance() {
	      if(instance == null) {
	         instance = new PropertyLoader();
	         loadProperties();
	      }
	      return instance;
	   }
	/**
	 * 
	 * @return
	 */
	 public Properties getConfigProp() {
			return configProp;
		}
	 /**
	  * 
	  */
	public static void loadProperties() {
		if (null == configProp) {
			try {
				configProp = new Properties();
				InputStream in = PropertyLoader.class.getResourceAsStream(CASSANDRA_PROPERTIES);
				configProp.load(in);
			} catch (Exception ex) {
				logger.error("Unable to load cassandra.properties "+ex.getMessage(),ex);
			}
		}
	}
}
