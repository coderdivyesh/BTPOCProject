package com.bt.config;

import javax.annotation.PreDestroy;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.datastax.driver.core.Cluster;
import com.datastax.driver.core.Session;


public class CassandraSessionFactory {
	private static final Logger logger = LoggerFactory.getLogger(CassandraSessionFactory.class);
	private static PropertyLoader prop=PropertyLoader.getInstance(); 
	private static final String KEYSPACE = "cassandra.keyspace";
	private static final String CONTACTPOINTS = "cassandra.contactpoints";
	private static final String PORT = "cassandra.port";

	private static final Cluster cluster=Cluster.builder().addContactPoint(getContactPoints()).withPort(getPortNumber()).build();
	private Session session;

	private String getKeyspaceName() {
		return prop.getConfigProp().getProperty(KEYSPACE);
	}

	private static String getContactPoints() {
		return prop.getConfigProp().getProperty(CONTACTPOINTS);
	}

	private static int getPortNumber() {
		return Integer.parseInt(prop.getConfigProp().getProperty(PORT));
	}

	/**
	 * This method will form cluster and create session object.
	 * 
	 * @return
	 */
	public synchronized Session getSession() {
		if (null == this.session) {
			this.session = cluster.connect(getKeyspaceName());
		}
		return this.session;
	}


	/**
	 * CassandraSessionFacotry Shutdown.
	 */
	@PreDestroy
	public synchronized void shutdown() {
		if (this.session != null) {
			this.session.close();
		}
		if (this.cluster != null) {
			this.cluster.close();
		}
	}


}
