package com.bt.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.bt.dao.ReportDataDAO;
import com.bt.entity.ReportData;
import com.bt.service.ReportDataService;

/**
 * 
 * @author 611022163
 *
 */
@Service
@Transactional
public class ReportDataServiceImpl implements ReportDataService {
	
	@Autowired
    private ReportDataDAO reportDataDAO;
	


    @ExceptionHandler(Exception.class)
    @Transactional(propagation=Propagation.SUPPORTS, readOnly=true)
	public List<ReportData> getAllReports() {
    	return reportDataDAO.getAllReports();
	}
   

}
