package com.bt.dao;

import java.util.List;

import com.bt.entity.ReportData;

public interface ReportDataDAO {
	
	public List<ReportData> getAllReportData();
	
	public List<ReportData> getAllReports();

}
