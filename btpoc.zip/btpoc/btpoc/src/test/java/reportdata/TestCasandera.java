package reportdata;

import com.datastax.driver.core.Cluster;
import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Row;
import com.datastax.driver.core.Session;

public class TestCasandera {

	public static void main(String args[]) {
		try {

			Cluster cluter = Cluster.builder().addContactPoint("10.52.8.101").build();

			Session sesion1 = cluter.connect();

			String sql = "Select * from event_live";

			ResultSet results = (ResultSet) sesion1.execute(sql);

			for (Row row : results) {

				System.out.println(row.getInt("id"));
				System.out.println(row.getLong("id"));
				System.out.println(row.getString("name").toString());
				System.out.println(row.getString("name").toString());

			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
