db.USER.insert( { _id:3,username: "user", password: "$2a$08$UkVvwpULis18S19S5pZFn.YHPZt3oaqHZnDwqbCW9pft6uFtkXKDC",firstname:"user",lastname:"user", email:"enabled@user.com", enabled : 1} )

db.AUTHORITY.insert( { _id:1,name:"ROLE_USER"} )
db.AUTHORITY.insert( { _id:2,name:"ROLE_ADMIN"} )

db.USER_AUTHORITY.insert( { user_id:1,authority_id:1})
db.USER_AUTHORITY.insert( { user_id:1,authority_id:2})
db.USER_AUTHORITY.insert( { user_id:2,authority_id:2})
db.USER_AUTHORITY.insert( { user_id:2,authority_id:1})
