package reportdata;

import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.ParameterizedType;
import java.util.Collection;

import com.itextpdf.text.DocumentException;

public class TextItext {
	
	 public static void main( String[] args ) throws DocumentException, IOException
	    {
		Field[] fields= DemoEntity.class.getDeclaredFields();
	 
		 for (Field field : fields) {
			
				 ParameterizedType parmeterized =(ParameterizedType) field.getGenericType();
			if (Collection.class.isAssignableFrom((Class<?>) parmeterized.getRawType())) {
				Class<?> childelement = (Class<?>) parmeterized.getActualTypeArguments()[0];
				System.out.println(childelement);
			}
		}
	    }


}
