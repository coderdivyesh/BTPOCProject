package com.bt.constant;

public enum FilterCondition {
	
	AND("AND"), 
	OR("OR"),
	EQUALS("="),
	NOT_EQUALS("!="),
	GRATER_THAN(">"),
	GRATER_THAN_EQUALS(">="),
	LESS_THAN("<"),
	LIKE("%"),
	LESS_THAN_EQUALS("<="),
	MONGO_AND("$and"), 
	MONGO_OR("$or"),
	MONGO_EQUALS("$eq"),
	MONGO_NOT_EQUALS("$ne"),
	MONGO_GRATER_THAN("$gt"),
	MONGO_GRATER_THAN_EQUALS("$gte"),
	MONGO_LESS_THAN("$lt"),
	MONGO_LESS_THAN_EQUALS("$lte"),
	MONGO_LIKE("%"),
	IS_PRESENT("Present"),
	IS_NOT_PRESENT("!Present"),
	IS_LIKE("like"),
	IS_NOT_LIKE("!like"),
	CONTAINS("contains"),
	NOT_CONTAINS("!contains"),
	STARTS_WITH("startsWith"),
	NOT_STARTS_WITH("!startsWith"),
	ENDS_WITH("endsWith"),
	NOT_ENDS_WITH("!endsWith");	
	private final String value;
	private FilterCondition(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}

	public static FilterCondition getEnum(String value) {
		for (FilterCondition v : values())
			if (v.getValue().equals(value))
				return v;
		throw new IllegalArgumentException();
	}

}
