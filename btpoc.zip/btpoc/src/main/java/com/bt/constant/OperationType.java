package com.bt.constant;

public enum OperationType {

	SAVE("+"), 
	DELETE("-"),
	UPDATE("*"),
	SEARCH("%");
	
	private final String value;
	
	private OperationType(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}

	public static OperationType getEnum(String value) {
		for (OperationType v : values())
			if (v.getValue().equals(value))
				return v;
		throw new IllegalArgumentException();
	}

	
}
