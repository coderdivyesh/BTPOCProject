package com.bt.dao.report.template;

import java.util.List;

import com.bt.common.QueryFormParameter;
import com.bt.entity.report.DefaultReport;
import com.bt.entity.report.GlobalReportTemplate;
import com.bt.entity.report.UserReportTemplate;
import com.bt.entity.template.Node;
import com.mongodb.BasicDBObject;

public interface ReportTemplateDAO {
	
	
	public List<GlobalReportTemplate> fetchAllGlobalTemplate() throws Exception;
	
	public List<UserReportTemplate> fetchAllUserTemplate() throws Exception ;

	public UserReportTemplate fetchUserReportTemplate(UserReportTemplate userReportTemplate,BasicDBObject basicdataobject) throws Exception;

	public void removeUserReportTemplateNodes(UserReportTemplate userReportTemplate) throws Exception;

	//public void removeNodes(UserReportTemplate userReportTemplate) throws Exception;

	public void insertNodes(UserReportTemplate userreporttemplate) throws Exception;

	public void updateNodes(UserReportTemplate userreporttemplate,BasicDBObject basicdataobject) throws Exception;

	
	public void insertUserDefaultTemplate(DefaultReport defaultreport)  throws Exception ;
	
	public DefaultReport fetchUserDefaultTemplate(String userid)  throws Exception ;

	
	public void updateNodes(GlobalReportTemplate globalreporttemplate,BasicDBObject basicdataobject) throws Exception;


	//public GlobalReportTemplate fetchGlobalReportTemplate(GlobalReportTemplate globalreporttemplate,BasicDBObject basicdataobject)throws Exception;

	public void insertNodes(GlobalReportTemplate globalreporttemplate)throws Exception;
	
	public UserReportTemplate fetcSingleUserTemplate(String userid)throws Exception;
	
	public void updateDocumentArray(Node inputnode, List<QueryFormParameter> queryParam, Class claz)throws Exception;
	
	public void deteleDocumentArray(Node inputnode, List<QueryFormParameter> queryParam, Class claz)throws Exception;
	
	public UserReportTemplate fetchEditedUserReportTemplate(BasicDBObject basicdataobject) throws Exception;

	
}
