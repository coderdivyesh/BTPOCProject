package com.bt.dao.user;

import com.bt.security.entity.User;

public interface UserServiceDAO {
 	
   User	loadUserByUsername(String username);
}
