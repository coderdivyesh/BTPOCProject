package com.bt.dao.user;

import java.util.List;

import com.bt.entity.report.ReportData;
import com.bt.entity.template.Node;
import com.bt.security.entity.User;
import com.mongodb.BasicDBObject;
import com.bt.security.service.UserActive;
import com.mongodb.BasicDBObject;

public interface UserDAO {
	
	public void insertUser(User newUser) throws Exception;
	
	public void loadUser() throws Exception;

	public void updateUser(User updUser, BasicDBObject basicdataobject) throws Exception;

	public User fetchUserData(User updUser, BasicDBObject basicdataobject) throws Exception;
	/**
	 * 
	 * @param Useract
	 * @return
	 * for insert token
	 * @throws Exception
	 */
	
	
	public void insertToken(UserActive Useract) throws Exception;
	
	/**
	 * 
	 * @return
	 * for showing activeusers
	 * @throws Exception
	 */
	
	public List<UserActive> getActiveUsers() throws Exception;
	/**
	 * 
	 * for delete active users
	 * @throws Exception
	 */
	
	public void killActiveUsers(UserActive uactive) throws Exception;
	/**
	 * 
	 * for fetch active users data for insert purpose
	 * @throws Exception
	 */
	
	public  UserActive fetchActiveUsersInDb(UserActive uactive) throws Exception;
	
	/**
	 * 
	 * for update active users if required
	 * @throws Exception
	 */
	
	public void updateActiveUsers(UserActive uactive) throws Exception;
	

}
