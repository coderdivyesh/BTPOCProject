package com.bt.dao.user.impl;

import java.util.ArrayList;
import java.util.List;

import com.bt.dao.user.UserServiceDAO;
import com.bt.security.entity.Authority;
import com.bt.security.entity.AuthorityName;
import com.bt.security.entity.User;

public class UserServiceDAOImpl implements UserServiceDAO {


	public User loadUserByUsername(String username) {
		User user = new User();
		user.setFirstname("Test ");
		user.setEmail("test@gmail.com");
		List<Authority> authorities = new ArrayList<Authority>();
		Authority auth = new Authority();
		auth.setId(new Long(123));
		auth.setName(AuthorityName.ROLE_ADMIN);
		authorities.add(auth);
		user.setAuthorities(authorities);
		return user;
	}

}
