package com.bt.dao.user.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import com.bt.common.AbstractDAO;
import com.bt.common.Condition;
import com.bt.common.QueryFormParameter;
import com.bt.dao.user.UserDAO;
import com.bt.entity.report.UserReportTemplate;
import com.bt.entity.report.ReportData;
import com.bt.entity.template.Node;
import com.bt.security.entity.User;
import com.bt.security.entity.UserVO;
import com.bt.security.helper.UserFactory;
import com.bt.security.service.UserActive;
import com.bt.security.service.UserService;
import com.mongodb.BasicDBObject;

@Repository
public class UserDAOImpl implements UserDAO {

private static final Logger logger = LoggerFactory.getLogger(UserDAOImpl.class);
	
	@Autowired
	 AbstractDAO abstractDAO;
	
	@Override
	public void insertUser(User newUser) throws Exception {
		
		abstractDAO.insert(newUser, User.class);
		
	}
	
	
	
	@Override
	public void updateUser(User updUser,BasicDBObject basicdataobject) throws Exception {
		
			abstractDAO.update(updUser, basicdataobject, User.class);	
	}

	@Override
	public void loadUser() throws Exception {
		List<User> users = (List<User>) abstractDAO.findAll(User.class);
		for (User usr : users) {
			UserVO uservo = UserFactory.create(usr);
			UserService.addUser(uservo);
		}
	}



	public static List<QueryFormParameter> formFilterParamter(User updUser) {
		
		List<QueryFormParameter> filterparams = new ArrayList<QueryFormParameter>();
		
		if (!StringUtils.isEmpty(updUser.getUsername())) {
			
				QueryFormParameter username = new QueryFormParameter();
				username.setColumname("username");
				username.setColumvalue(updUser.getUsername());
				username.setCondition(Condition.EQUALS);
				filterparams.add(username);
			
		}
		return filterparams;
	
	
	}



	@Override
	public User fetchUserData(User updUser, BasicDBObject basicdataobject) throws Exception {

		if (!StringUtils.isEmpty(updUser.getUsername())) {
			
				return (User) abstractDAO.fetchSingleElement(basicdataobject, User.class);	
		}
		return null;
	
		
	}

	

	@Override
	public void insertToken(UserActive Useract) throws Exception {
		
		abstractDAO.insert(Useract, UserActive.class);
		
	}
/**
 * 
 */	
	@Override
	public List<UserActive> getActiveUsers() throws Exception{
		return (List<UserActive>) abstractDAO.findAll(UserActive.class);
	}
	
	
/**
 * 
 * @param uactive
 * @return
 * @throws Exception
 */
	
	private BasicDBObject killActUserQuery(UserActive uactive) throws Exception {
		List<QueryFormParameter> filterparams=new ArrayList<QueryFormParameter>();
		QueryFormParameter filterparam=new QueryFormParameter();
		filterparam.setColumname("tokenId");
		filterparam.setColumvalue(uactive.getTokenId());
		filterparam.setCondition(Condition.EQUALS);
		filterparams.add(filterparam);
		 return ( abstractDAO.deleteQuery(filterparams,UserActive.class) );
		
	}
	/**
	 * for active users present in db
	 * @param uactive
	 * @return
	 * @throws Exception
	 */
	@Override
		public  UserActive fetchActiveUsersInDb(UserActive uactive) throws Exception {
			List<QueryFormParameter> filterparams=new ArrayList<QueryFormParameter>();
			QueryFormParameter filterparam=new QueryFormParameter();
			filterparam.setColumname("username");
			filterparam.setColumvalue(uactive.getUsername());
			filterparam.setCondition(Condition.EQUALS);
			filterparams.add(filterparam);
			BasicDBObject bsicdbobject=   abstractDAO.deleteQuery(filterparams,UserActive.class);
			return (UserActive) abstractDAO.fetchSingleElement(bsicdbobject, UserActive.class );
			
		}	
	
		/**
		 * for update active users in DB
		 * @param uactive
		 * @return
		 * @throws Exception
		 */
	@Override
		public void updateActiveUsers(UserActive uactive) throws Exception{
			List<QueryFormParameter> filterparams=new ArrayList<QueryFormParameter>();
			QueryFormParameter filterparam=new QueryFormParameter();
			filterparam.setColumname("username");
			filterparam.setColumvalue(uactive.getUsername());
			filterparam.setCondition(Condition.EQUALS);
			filterparams.add(filterparam);
			BasicDBObject whereQuery=   abstractDAO.deleteQuery(filterparams,UserActive.class);
			abstractDAO.update(uactive, whereQuery, UserActive.class);
		}
	
	/**
	 * 
	 */
	public void killActiveUsers(UserActive useractive) throws Exception{
		abstractDAO.delete(killActUserQuery(useractive), UserActive.class);
		
	}
}
