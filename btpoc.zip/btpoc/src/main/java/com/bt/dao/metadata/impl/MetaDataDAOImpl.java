package com.bt.dao.metadata.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bt.common.AbstractDAO;
import com.bt.dao.metadata.MetaDataDAO;
import com.bt.entity.template.CollectionMetaData;
import com.mongodb.BasicDBObject;


/**
 * 
 * @author 611022163
 *
 */
@Repository
public class MetaDataDAOImpl implements MetaDataDAO {

	@Autowired
	 AbstractDAO abstractDAO;
	
	@Override
	public CollectionMetaData loadMetaData(String collectionName) throws Exception {
		BasicDBObject query = new BasicDBObject();
		query.append("_id", collectionName);
		return (CollectionMetaData) abstractDAO.fetchElement(query, CollectionMetaData.class);
	}
	
	
	

}
