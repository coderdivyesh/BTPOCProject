package com.bt.dao.graph;

import com.bt.entity.common.CommonData;
import com.bt.entity.graph.GraphDetails;

public interface GraphDAO {

public GraphDetails fetchGraphdata(CommonData commondata) throws Exception;
}
