package com.bt.dao.metadata;

import org.springframework.stereotype.Repository;

import com.bt.entity.template.CollectionMetaData;


public interface MetaDataDAO {
	
	public CollectionMetaData loadMetaData(String collectionName) throws Exception;

}
