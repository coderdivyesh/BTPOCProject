package com.bt.dao.report.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bt.common.AbstractDAO;
import com.bt.dao.report.ReportDataDAO;
import com.bt.entity.common.CommonData;
import com.bt.entity.report.ReportData;


/**
 * 
 * @author 611022163
 *
 */
@Repository
public  class ReportDataDAOImpl implements ReportDataDAO {

	private static final Logger logger = LoggerFactory.getLogger(ReportDataDAOImpl.class);
	
	@Autowired
	 AbstractDAO abstractDAO;
	
/**
 * This method  will fetch record according to fetch size.
 * The mongo.fetchlimit=1000 is default . It could be change from 
 * mongo.properties file.
 * 
 */
	public List<ReportData> getAllReports(){
		return abstractDAO.selectAll();
	}

	/**
	 * This method will fetch record according to page number and page size.
	 * 
	 */
	public List<ReportData> getAllReports(int pagenumber,int pagesize){
		return abstractDAO.selectAll(pagenumber,pagesize);
	}

	public List<ReportData> getAllReports(CommonData reportdata) throws Exception {
		
		return abstractDAO.getAllObjectsAccordingToTemplate(reportdata);
	}

	public List<ReportData> fetchReports(CommonData reportdata) throws Exception {

		return abstractDAO.fetchAllAccordingToTemplate(reportdata);
	}
}
