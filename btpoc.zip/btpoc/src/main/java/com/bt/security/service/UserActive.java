package com.bt.security.service;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="activeuser")
public class UserActive {
	/**
	 * 
	 */
	private String tokenId;
	private String username;
	private String email;
	public String getTokenId() {
		return tokenId;
	}
	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
     public void setEmail(String email){
    	 this.email = email;
     }
	 public String getEmail() {
	        return email;
	    }
	
}
