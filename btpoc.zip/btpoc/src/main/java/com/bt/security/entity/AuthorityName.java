package com.bt.security.entity;

public enum AuthorityName {
    ROLE_USER, ROLE_ADMIN
}