package com.bt.util;

import com.bt.entity.template.NodeOneTemplate;
import com.bt.entity.template.ParentNodeTemplate;

public class TemplateObjectCreator 
{
	public static Object getTemplateObject(String obj) {
		Object object = null;
		if (obj.equals("children")) {
			object = new NodeOneTemplate();
		} else if (obj.equals("parent")) {
			object = new ParentNodeTemplate();
		}
		return object;
	}

}
