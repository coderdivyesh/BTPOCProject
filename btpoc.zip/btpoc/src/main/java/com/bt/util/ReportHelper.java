package com.bt.util;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Stack;
import java.util.StringTokenizer;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.util.StringUtils;
import org.supercsv.cellprocessor.ift.CellProcessor;
import org.supercsv.io.ICsvBeanWriter;

import com.bt.config.PropertyLoader;
import com.bt.constant.FilterCondition;
import com.bt.entity.common.CommonData;
import com.bt.entity.common.TemplateConfiguration;
import com.bt.entity.report.DefaultReport;
import com.bt.entity.report.ReportData;
import com.bt.entity.report.ReportDataList;
import com.bt.entity.template.ExpressionDetails;
import com.bt.entity.template.Node;
import com.bt.entity.template.NodeColumn;

public class ReportHelper {
	private static final String DELIMITER = "#";
	private static Pattern conditionPattern = Pattern.compile("=|!=|>|>=|<|<=|%");
	
	/**
	 * 
	 * @param reportData
	 */
	public static void getFilterfield(CommonData reportData) {
		List<NodeColumn> filterparams = null;
		String Keys = FileHelper.getPropertieskeyForTemplate(reportData);
		if (!StringUtils.isEmpty(Keys)) {
			String[] keys = Keys.split(",");
			filterparams = new ArrayList<NodeColumn>(keys.length);
			for (String key : keys) {
				if (!StringUtils.isEmpty(key) && !"all".equalsIgnoreCase(key)) {
					NodeColumn filterparam = new NodeColumn();
					filterparam.setName(key.toLowerCase());
					filterparam.setDbname(key); 
					filterparam.setLabel(key.toUpperCase());
					filterparams.add(filterparam);
				}
				}
			reportData.setDisplayprams(filterparams);
		}
	
	}
	
	/**
	 * This method will crate report for CSV
	 * @param csvbeanwriter
	 * @param reportdatalist
	 * @throws Exception
	 */
	public static void createCSV(ICsvBeanWriter csvbeanwriter, ReportDataList reportdetails) throws Exception {
		List<ReportData> reportdatalist = reportdetails.getReportdatalist();
		if (!reportdetails.getReportdatalist().isEmpty()) {
			List<NodeColumn> filterparams = reportdetails.getCommondata().getDisplayprams();
			String[] csvHeader = FileHelper.getHeaderList(filterparams);
			String[] fieldlist = FileHelper.getFieldList(filterparams);
			final CellProcessor[] processors = FileHelper.getProcessors(fieldlist);
			csvbeanwriter.writeHeader(csvHeader);
			for (ReportData report : reportdatalist) {
				csvbeanwriter.write(report, csvHeader, processors);
			}
		}
	}

	/**
	 * This method will create PDF
	 * @param reportDataList
	 * @return
	 * @throws Exception
	 */
	public static void createPDF(String filename,ReportDataList reportdetails,OutputStream outputstream) throws Exception {
		 ReportPDFWriter.getInstance().createPDFContent(filename, reportdetails,outputstream);
	}

	/**
	 * This method will create TXT file 
	 * @param reportDataList
	 * @return
	 * @throws Exception
	 */
	public static ByteArrayOutputStream createTXT(ReportDataList reportdetails) throws Exception {
		InputStream inputstream=null;// FileHelper.createTXT("report", reportDataList);
		ByteArrayOutputStream baos=new ByteArrayOutputStream();
		IOUtils.copy(inputstream, baos);
		return baos;
	}
	
/**
 * Thsi method wiil create xls file 
 * @param workBook
 * @param excelSheet
 * @throws Exception
 */
	public static HSSFWorkbook createExcel(HttpServletResponse response,ReportDataList reportdetails) throws Exception {
		
		response.setContentType("application/vnd.ms-excel");
	    response.setHeader("Expires", "0");
	    response.setHeader("Cache-Control", "must-revalidate, post-check=0, pre-check=0");
	    response.setHeader("Pragma", "public");
	    response.setHeader("Content-Disposition", "attachment; filename=ReportsData.xls");
	    
		HSSFWorkbook workBook = new HSSFWorkbook();
		HSSFSheet excelSheet = workBook.createSheet("report_excel");
		HSSFRow excelHeader = excelSheet.createRow(0);
		String[] xlsHeaders = FileHelper.getHeaderList(reportdetails.getCommondata().getDisplayprams());
		String[] xlsFields =FileHelper.getFieldList(reportdetails.getCommondata().getDisplayprams());
		for (int i = 0; i < xlsHeaders.length; i++) {
			excelHeader.createCell(i).setCellValue(xlsHeaders[i]);
		}
		List<ReportData> reportDataList = reportdetails.getReportdatalist();
		for (int row = 1; row < reportDataList.size(); row++) {
			HSSFRow excelRow = excelSheet.createRow(row);
			for (int record = 0; record < xlsHeaders.length; record++) {
				Field field = ReportData.class.getDeclaredField(xlsFields[record]);
				field.setAccessible(Boolean.TRUE);
				Object value = field.get(reportDataList.get(row));
				excelRow.createCell(record).setCellValue(String.valueOf(value));
			}
		}
		
		return workBook;
	}
	
	
	/**
	 * This  method use to populate default template report 
	 * @param defaultreport
	 */
	public static void pouplateDefaultReport(DefaultReport defaultreport) {
		Properties properties = PropertyLoader.loadProp();
		Node reportConfiguration = new Node();
		TemplateConfiguration templateconfig = new TemplateConfiguration();
		populateDisplayParams(defaultreport, properties, reportConfiguration);

		String pagesizekey = formreporttemplateKey(defaultreport.getUsername(), "pagesize");
		Integer pagesize = Integer.parseInt(String.valueOf(properties.get(pagesizekey)));
		reportConfiguration.setPagesize(pagesize);

		String pagenumberkey = formreporttemplateKey(defaultreport.getUsername(), "pagenumber");
		Integer pagenumber = Integer.parseInt(String.valueOf(properties.get(pagenumberkey)));
		templateconfig.setPagenumber(pagenumber);

		String durationkey = formreporttemplateKey(defaultreport.getUsername(), "duration");
		String duration = (String) properties.get(durationkey);
		reportConfiguration.setDuration(duration);
		templateconfig.setNode(reportConfiguration);
		defaultreport.setCommondata(templateconfig);
	}

	
	/**
	 * This method will populate display display parmas from properties file.
	 * @param defaultreport
	 * @param properties
	 * @param reportConfiguration
	 */
	private static void populateDisplayParams(DefaultReport defaultreport, Properties properties,
			Node reportConfiguration) {
		String columkey = formreporttemplateKey(defaultreport.getUsername(), "NodeColumn");
		String columns = (String) properties.get(columkey);
		String[] listofcolumnsfromprop = StringUtils.commaDelimitedListToStringArray(columns);
		List<NodeColumn> defaultcolumns = new ArrayList<NodeColumn>();
		for (String colum : listofcolumnsfromprop) {
			NodeColumn nodecolumn = new NodeColumn();
			nodecolumn.setDbname(colum);
			nodecolumn.setLabel(colum.toUpperCase());
			nodecolumn.setName(colum.toLowerCase());
			defaultcolumns.add(nodecolumn);
		}
		reportConfiguration.setColumns(defaultcolumns);
	}
	
	
	public static String formreporttemplateKey(String userid, String fieldname) {
		StringBuilder key = new StringBuilder().append("report").append(".").append("default").append(".")
				.append(fieldname);
		return key.toString();
	}

	
/**
 * 
 * @param existexpresion
 * @return
 */
	public static Map<String, ExpressionDetails> expressionAnalyzer (TemplateConfiguration existexpresion) {
		Map<String, ExpressionDetails> expressionMap = new HashMap<String, ExpressionDetails>();
		String filterExpression = existexpresion.getAllfilterexpression();
		if (!StringUtils.isEmpty(filterExpression)) {
			StringTokenizer toknes = new StringTokenizer(filterExpression,DELIMITER);
			Stack<ExpressionDetails> lastvalue = new Stack<ExpressionDetails>();
			FilterCondition joincondtion = null;
			while (toknes.hasMoreTokens()) {
				ExpressionDetails keyvalue = new ExpressionDetails();
				String token = toknes.nextToken();
				
				//Outer Condition token 
				if (FilterCondition.AND.getValue().equals(token)) {
					joincondtion = FilterCondition.AND;
					keyvalue = lastvalue.pop();
					keyvalue.setOuterJoinOperation(joincondtion);
					expressionMap.put(keyvalue.getKey(), keyvalue);
				} else if (FilterCondition.OR.getValue().equals(token)) {
					joincondtion = FilterCondition.OR;
					keyvalue = lastvalue.pop();
					keyvalue.setOuterJoinOperation(joincondtion);
					expressionMap.put(keyvalue.getKey(), keyvalue);
				}
				
				// split tokens for inner condtion
				String[] charparts = conditionPattern.split(token);
				if (token.contains(FilterCondition.EQUALS.getValue())) {
					keyvalue.setKey(charparts[0].trim());
					keyvalue.setInnerJoinOpeartion(FilterCondition.EQUALS);
					keyvalue.setValue(charparts[1].trim());
					lastvalue.push(keyvalue);
				} else if (token.contains(FilterCondition.GRATER_THAN.getValue())) {
					keyvalue.setKey(charparts[0].trim());
					keyvalue.setInnerJoinOpeartion(FilterCondition.GRATER_THAN);
					keyvalue.setValue(charparts[1].trim());
					lastvalue.push(keyvalue);
				} else if (token.contains(FilterCondition.LESS_THAN.getValue())) {
					keyvalue.setKey(charparts[0].trim());
					keyvalue.setInnerJoinOpeartion(FilterCondition.LESS_THAN);
					keyvalue.setValue(charparts[1].trim());
					lastvalue.push(keyvalue);
				} else if (token.contains(FilterCondition.GRATER_THAN_EQUALS.getValue())) {
					keyvalue.setKey(charparts[0].trim());
					keyvalue.setInnerJoinOpeartion(FilterCondition.GRATER_THAN_EQUALS);
					keyvalue.setKey(charparts[1].trim());
					lastvalue.push(keyvalue);
				} else if (token.contains(FilterCondition.LESS_THAN_EQUALS.getValue())) {
					keyvalue.setKey(charparts[0].trim());
					keyvalue.setInnerJoinOpeartion(FilterCondition.LESS_THAN_EQUALS);
					keyvalue.setValue(charparts[1].trim());
					lastvalue.push(keyvalue);
				} else if (token.contains(FilterCondition.NOT_EQUALS.getValue())) {
					keyvalue.setKey(charparts[0].trim());
					keyvalue.setInnerJoinOpeartion(FilterCondition.NOT_EQUALS);
					keyvalue.setValue(charparts[1].trim());
					lastvalue.push(keyvalue);
				}

				// for last tokens
				if (!toknes.hasMoreTokens()) {
					keyvalue.setOuterJoinOperation(joincondtion);
					expressionMap.put(keyvalue.getKey(), keyvalue);
					existexpresion.setExpressionmap(expressionMap);
				}

			}
		}
		return expressionMap;
	}

	/**
	 * 
	 * @param template
	 * @param filterExpression
	 */
	public static void expressionBuilder(TemplateConfiguration template, String filterExpression) {
		StringBuilder newExpression = null;
		if (!StringUtils.isEmpty(filterExpression)) {
			newExpression = new StringBuilder(filterExpression);
		}
		if (null != newExpression) {
			if (!StringUtils.isEmpty(template.getAllfilterexpression())) {
				StringBuilder existExpression = new StringBuilder(template.getAllfilterexpression());
				existExpression.append(FilterCondition.AND.getValue()).append(DELIMITER).append(newExpression).append(DELIMITER);
				template.setAllfilterexpression(existExpression.toString().trim());
			} else {
				template.setAllfilterexpression(newExpression.append(DELIMITER).toString());
			}
		}

	}
	
	
}
