package com.bt.util;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import com.bt.common.FieldVariableConstant;
import com.bt.common.QueryHelper;
import com.bt.entity.common.CommonData;
import com.bt.entity.graph.GraphDetails;
import com.bt.entity.report.ReportData;
import com.bt.entity.template.NodeColumn;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mongodb.AggregationOutput;
import com.mongodb.BasicDBObject;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;


public class ResultSetProcessor implements FieldVariableConstant  {
	
	private static final Logger logger = LoggerFactory.getLogger(ResultSetProcessor.class);
	
	/**
	 * 
	 * @param dbcursor
	 * @return
	 */
	public static List<ReportData> processResultSet(DBCursor dbcursor) {
		if (logger.isDebugEnabled()) {
			logger.debug(" processResultSet() : Fetch result DBCursor: " + dbcursor);
		}
		List<ReportData> reportlist = new ArrayList<ReportData>();
		while (dbcursor.hasNext()) {
			ReportData report = new ReportData();
			DBObject row = dbcursor.next();
			report.setId((Long) row.get(ID));
			report.setName(String.valueOf(row.get(NAME)));
			report.setOpenedat(Integer.parseInt(row.get(OPENED_AT).toString()));
			report.setAcknowledged(Byte.parseByte(row.get(ACKNOWLEDGED).toString()));
			report.setAcknowledgedFirstUser(String.valueOf(row.get(ACKNOWLEDGED_FIRST_USER)));
			report.setActive(Byte.parseByte(row.get(ACTIVE).toString()));
			report.setCategory(String.valueOf(row.get(CATEGORY)));
			report.setCertainty(Float.parseFloat(row.get(CERTAINTY).toString()));
			report.setClassdisplayname(String.valueOf(row.get(CLASS_DISPLAY_NAME)));
			report.setClassName(String.valueOf(row.get(CLASS_NAME)));
			report.setCloseDat(Integer.parseInt(row.get(CLOSED_AT).toString()));
			report.setDuration(Integer.parseInt(row.get(DURATION).toString()));
			report.setElementclassname(String.valueOf(row.get(ELEMENT_CLASS_NAME)));
			report.setElementname(String.valueOf(row.get(ELEMENT_NAME)));
			report.setEventdisplayname(String.valueOf(row.get(EVENT_DISPLAY_NAME)));
			report.setEventname(String.valueOf(row.get(ELEMENT_NAME)));
			report.setEventtext(String.valueOf(row.get("EventText")));
			report.setEventtype(String.valueOf(row.get("EventType")));
			report.setFirstnotifiedat(Integer.parseInt(row.get("FirstNotifiedAt").toString()));
			report.setFirsttimetoacknowledged(Integer.parseInt(row.get("FirstTimeToAcknowledged").toString()));
			report.setFirsttimetoowner(Integer.parseInt(row.get("FirstTimeToOwner").toString()));
			report.setFirsttimetotroubleticketid(Integer.parseInt(row.get("FirstTimeToTroubleTicketID").toString()));
			report.setImpact(Long.parseLong(row.get("Impact").toString()));
			report.setInmaintenance(Byte.parseByte(row.get("InMaintenance").toString()));
			report.setInstancedisplayname(String.valueOf(row.get("InstanceDisplayName")));
			report.setInstancename(String.valueOf(row.get("InstanceName")));
			report.setIsproblem(Byte.parseByte(row.get("IsProblem").toString()));
			report.setIsroot(Byte.parseByte(row.get("IsRoot").toString()));
			report.setIsrootfirstvalue(Byte.parseByte("1"));
			report.setLastchangedat(Integer.parseInt(row.get("LastChangedAt").toString()));
			report.setOccurrencecount(Integer.parseInt(row.get("OccurrenceCount").toString()));
			report.setOwner(String.valueOf(row.get("Owner")));
			report.setOwnerfirstuser(String.valueOf(row.get("OwnerFirstUser")));
			report.setSeverity(Byte.parseByte(row.get("Severity").toString()));
			report.setSource(String.valueOf(row.get("Source")));
			report.setSourcedomainname(String.valueOf(row.get("SourceDomainName")));
			report.setSourceeventtype(String.valueOf(row.get("SourceEventType")));
			report.setTroubleticketid(String.valueOf(row.get("TroubleTicketID")));
			report.setTroubleticketidfirstvalue(String.valueOf(row.get("TroubleTicketIDFirstValue")));
			report.setUpdatedat(0);
			report.setUserdefined1(String.valueOf(row.get("UserDefined1")));
			report.setUserdefined2(String.valueOf(row.get("UserDefined2")));
			report.setUserdefined4(String.valueOf(row.get("UserDefined4")));
			report.setUserdefined3(String.valueOf(row.get("UserDefined3")));
			report.setUserdefined5(String.valueOf(row.get("UserDefined5")));
			report.setUserdefined6(String.valueOf(row.get("UserDefined6")));
			report.setUserdefined7(String.valueOf(row.get("UserDefined7")));
			report.setUserdefined8(String.valueOf(row.get("UserDefined8")));
			report.setUserdefined9(String.valueOf(row.get("UserDefined9")));
			report.setUserdefined10(String.valueOf(row.get("UserDefined10")));
			report.setUserdefined11(String.valueOf(row.get("UserDefined11")));
			report.setUserdefined12(String.valueOf(row.get("UserDefined12")));
			report.setUserdefined13(String.valueOf(row.get("UserDefined13")));
			report.setUserdefined14(String.valueOf(row.get("UserDefined14")));
			report.setUserdefined15(String.valueOf(row.get("UserDefined15")));
			report.setUserdefined16(String.valueOf(row.get("UserDefined16")));
			report.setUserdefined17(String.valueOf(row.get("UserDefined17")));
			report.setUserdefined18(String.valueOf(row.get("UserDefined18")));
			report.setUserdefined19(String.valueOf(row.get("UserDefined19")));
			report.setUserdefined20(String.valueOf(row.get("UserDefined20")));
			reportlist.add(report);
		}
		return reportlist;
	}

	
	/**
	 * 
	 * @param dbcourser
	 * @param filterParameter
	 * @return
	 * @throws SecurityException
	 * @throws NoSuchFieldException
	 * @throws IllegalAccessException
	 * @throws Exception
	 */
	public static List<ReportData> processResultSet(DBCursor dbcourser, List<NodeColumn> filterParameters) {
		List<ReportData> reportlist = null;

		if (null == filterParameters || filterParameters.isEmpty()) {
			reportlist = ResultSetProcessor.processResultSet(dbcourser);
		} else {
			reportlist = new ArrayList<ReportData>();
			while (dbcourser.hasNext()) {
				ReportData report = new ReportData();
				DBObject row = dbcourser.next();
				for (NodeColumn fillparam : filterParameters) {
					Field field = null;
					try {
						field = ReportData.class.getDeclaredField(fillparam.getName());
						field.setAccessible(true);
						field.set(report, row.get(fillparam.getDbname()));
					} catch (Exception exp) {
						if(null!=field){
						if (field.getType().isAssignableFrom(String.class)) {
							try {
								field.set(report, "Empty String");
							} catch (Exception e) {
								logger.error(" Unable perform operation : " + exp.getMessage(), exp);
							}
						}
						logger.error(" Unable perform operation : " + exp.getMessage(), exp);
						}
					}
				}
				reportlist.add(report);
			}

		}
		return reportlist;
	}
	
	
	/**
	 * Returns GraphDetails object having x and y coordinate values
	 * 
	 * @param dbcourser
	 * @param commondata
	 * @return
	 */
	public static GraphDetails processDBCursor(AggregationOutput dbcourser, CommonData commondata) {
		List<NodeColumn> filterParameters = commondata.getDisplayprams();
		GraphDetails graphDetails = new GraphDetails();
		Map<String, Object> graphvalues = new HashMap<String, Object>();
		String xfieldname = null;
		String yfieldname = null;

		for (NodeColumn filter : filterParameters) {
			if (!StringUtils.isEmpty(graphDetails.getXfieldName())
					&& !StringUtils.isEmpty(graphDetails.getYfieldName())) {
				break;
			}
			if (StringUtils.isEmpty(xfieldname)) {
				xfieldname = filter.getDbname();
				graphDetails.setXfieldName(xfieldname);
			} else {
				yfieldname = filter.getDbname();
				graphDetails.setYfieldName(yfieldname);
			}
		}
		
		for (DBObject row : dbcourser.results()) {
			String xkey = "X-"+graphDetails.getXfieldName() + graphvalues.size();
			BasicDBObject dbObj=(BasicDBObject) row.get("_id");
			graphvalues.put(xkey, dbObj.get(xfieldname));
			String ykey = "Y-"+xkey;
			graphvalues.put(ykey, row.get(yfieldname));
		}
		
		//Add missing xParam values to graphvalues
		populateMissingXParams(commondata, graphDetails, graphvalues);
				
		graphDetails.setGraphvalues(graphvalues);
		return graphDetails;
	}


	/**
	 * Add missing xParam values to graphvalues
	 * @param commondata
	 * @param graphDetails
	 * @param graphvalues2
	 */
	private static void populateMissingXParams(CommonData commondata, GraphDetails graphDetails,
			Map<String, Object> graphvalues) {

		// oldXParamValues: List containing X-param values after aggregation
		List<Object> oldXParamValues = new ArrayList<Object>();
		// expectedXParamValues: List containing all X-param points
		List<Object> expectedXParamValues = new ArrayList<Object>();
		long durationVal = QueryHelper.convertToSeconds(commondata.getDuration());
		long samplingPeriodVal = QueryHelper.convertToSeconds(commondata.getSamplingPeriod());
		int totalPoints = (int) (durationVal / samplingPeriodVal);

		for (String key : graphvalues.keySet()) {
			if (key.startsWith("X")) {
				oldXParamValues.add(graphvalues.get(key));
			}
		}

		// sort oldXParamValues
		Collections.sort(oldXParamValues, new Comparator<Object>() {
			public int compare(final Object object1, final Object object2) {
				return object1.toString().compareTo(object2.toString());
			}
		});

		Double xParamVal = (Double) oldXParamValues.get(0);

		while (totalPoints != 0) {
			expectedXParamValues.add(xParamVal);
			xParamVal += samplingPeriodVal;
			totalPoints--;
		}
		if (expectedXParamValues.size() > oldXParamValues.size()) {
			for (Object missingXParamValue : expectedXParamValues) {
				// add missingXParamValue to graphvalues
				if (!oldXParamValues.contains(missingXParamValue)) {
					String xkey = "X-" + graphDetails.getXfieldName() + graphvalues.size();
					graphvalues.put(xkey, missingXParamValue);
					String ykey = "Y-" + xkey;
					graphvalues.put(ykey, 0);
				}
				// if last point reached, break
				if (missingXParamValue.toString().equals(oldXParamValues.get(oldXParamValues.size() - 1).toString())) {
					break;
				}
			}
		}
	}

    /**
     * 
     * @param dbcourser
     * @param claz
     * @return
     * @throws Exception
     */
	public static List<?> processDBCursor(DBCursor dbcourser, Class claz) throws Exception {
		Field[] fields = claz.getDeclaredFields();
		List<Object> listobject = new ArrayList<Object>();
		while (dbcourser.hasNext()) {
			Object parentObject = claz.newInstance();
			DBObject row = dbcourser.next();
			ObjectMapper mapper = new ObjectMapper();
			mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			parentObject = mapper.readValue(row.toString(), claz);
			listobject.add(parentObject);
		}
		return listobject;
	}
	
	  /**
     * 
     * @param dbcourser
     * @param claz
     * @return
     * @throws Exception
     */
	public static Object processDBCursorForSingle(DBCursor dbcourser, Class claz) throws Exception {
		Field[] fields = claz.getDeclaredFields();
		Object parentObject = claz.newInstance();
		while (dbcourser.hasNext()) {
			DBObject row = dbcourser.next();
			ObjectMapper mapper = new ObjectMapper();
			mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			parentObject = mapper.readValue(row.toString(), claz);
		}
		return parentObject;
	}
	
	/**
	 * 
	 * @param row
	 * @param claz
	 * @param childobject
	 * @throws Exception
	 */
//	public static void processDBCursor(BasicDBList row, Class claz, Object childobject) throws Exception {
//		Field[] fields = claz.getDeclaredFields();
//		for (Field field : fields) {
//			Object value=null;
//			Type type = field.getGenericType();
//			Map listchild=HashMap<Object>();
//			Iterator objectiterat=row.toMap().keySet().iterator();
//			listchild.get(objectiterat.hasNext());
//			if (type instanceof ParameterizedType) {
//				List<Object> listelemnts=new ArrayList<Object>();
//				ParameterizedType parmeterized = (ParameterizedType) type;
//				if (Collection.class.isAssignableFrom((Class<?>) parmeterized.getRawType())) {
//					Class<?> childelement = (Class<?>) parmeterized.getActualTypeArguments()[0];
//					Object childObject = childelement.newInstance();
//					BasicDBList listofchildbject=(BasicDBList) listchild.get(field.getName());
//					processDBCursor(listofchildbject, childelement, childObject);
//					listelemnts.add(childObject);
//				}
//				value=listelemnts;
//			}else{
//				
//				value=listchild.get(field.getName());
//				if(value instanceof Double){
//					value =((Double) value).longValue();					
//				}
//			}
//			field.setAccessible(Boolean.TRUE);
//			field.set(childobject, value);
//		}
//
//	}
	
}
