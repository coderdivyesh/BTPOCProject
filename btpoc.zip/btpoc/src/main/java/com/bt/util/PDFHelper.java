package com.bt.util;

import java.util.List;

import com.bt.entity.report.ReportData;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;

/**
 * 
 * @author 611022675
 *
 */
public class PDFHelper {
	/**
	 * 
	 * @param table
	 * @param header
	 * @param font
	 */
	public static void pdfHeaderWriter(PdfPTable table, String[] header, Font font) {
		if (null != header && header.length > 0) {
			for (String name : header) {
				insertCell(table, name.toUpperCase(), Element.ALIGN_RIGHT, 1, font);
			}
		}

	}

	/**
	 * 
	 * @param table
	 * @param text
	 * @param align
	 * @param colspan
	 * @param font
	 */
	private static void insertCell(PdfPTable table, String text, int align, int colspan, Font font) {
		PdfPCell cell = new PdfPCell(new Phrase(text.trim(), font));
		cell.setHorizontalAlignment(align);
		cell.setColspan(colspan);
		if (text.trim().equalsIgnoreCase("")) {
			cell.setMinimumHeight(10f);
		}
		table.addCell(cell);
	}
/**
 * 
 * @param table
 * @param reportdatalist
 * @param font
 * @param document
 * @param paragraph
 * @throws Exception
 */
	public static void pdfContentWriter(PdfPTable table, List<ReportData> reportdatalist, Font font, Document document,
			Paragraph paragraph) throws Exception {
		if (null != reportdatalist && !reportdatalist.isEmpty()) {
			for (ReportData report : reportdatalist) {
				insertCell(table, String.valueOf(report.getId()), Element.ALIGN_RIGHT, 1, font);
				insertCell(table, String.valueOf(report.getName()), Element.ALIGN_RIGHT, 1, font);
				insertCell(table, String.valueOf(report.getOpenedat()), Element.ALIGN_RIGHT, 1, font);
				insertCell(table, String.valueOf(report.getAcknowledged()), Element.ALIGN_RIGHT, 1, font);
				/*
				 * insertCell(table,
				 * String.valueOf(report.getAcknowledgedFirstUser()),
				 * Element.ALIGN_RIGHT, 1, bf12); insertCell(table,
				 * String.valueOf(report.getActive()), Element.ALIGN_RIGHT, 1,
				 * bf12); insertCell(table,
				 * String.valueOf(report.getCategory()), Element.ALIGN_RIGHT, 1,
				 * bf12); insertCell(table,
				 * String.valueOf(report.getCertainty()), Element.ALIGN_RIGHT,
				 * 1, bf12); insertCell(table,
				 * String.valueOf(report.getClassdisplayname()),
				 * Element.ALIGN_RIGHT, 1, bf12); insertCell(table,
				 * String.valueOf(report.getActive()), Element.ALIGN_RIGHT, 1,
				 * bf12); insertCell(table,
				 * String.valueOf(report.getCategory()), Element.ALIGN_RIGHT, 1,
				 * bf12); insertCell(table,
				 * String.valueOf(report.getCertainty()), Element.ALIGN_RIGHT,
				 * 1, bf12); insertCell(table,
				 * String.valueOf(report.getClassdisplayname()),
				 * Element.ALIGN_RIGHT, 1, bf12); insertCell(table,
				 * String.valueOf(report.getClassName()), Element.ALIGN_RIGHT,
				 * 1, bf12); insertCell(table,
				 * String.valueOf(report.getCloseDat()), Element.ALIGN_RIGHT, 1,
				 * bf12); insertCell(table,
				 * String.valueOf(report.getDuration()), Element.ALIGN_RIGHT, 1,
				 * bf12); insertCell(table,
				 * String.valueOf(report.getElementclassname()),
				 * Element.ALIGN_RIGHT, 1, bf12); insertCell(table,
				 * String.valueOf(report.getElementname()), Element.ALIGN_RIGHT,
				 * 1, bf12); insertCell(table,
				 * String.valueOf(report.getEventdisplayname()),
				 * Element.ALIGN_RIGHT, 1, bf12); insertCell(table,
				 * String.valueOf(report.getEventname()), Element.ALIGN_RIGHT,
				 * 1, bf12); insertCell(table,
				 * String.valueOf(report.getEventtext()), Element.ALIGN_RIGHT,
				 * 1, bf12); insertCell(table,
				 * String.valueOf(report.getEventtype()), Element.ALIGN_RIGHT,
				 * 1, bf12); insertCell(table,
				 * String.valueOf(report.getFirstnotifiedat()),
				 * Element.ALIGN_RIGHT, 1, bf12); insertCell(table,
				 * String.valueOf(report.getFirsttimetoacknowledged()),
				 * Element.ALIGN_RIGHT, 1, bf12); insertCell(table,
				 * String.valueOf(report.getFirsttimetoowner()),
				 * Element.ALIGN_RIGHT, 1, bf12); insertCell(table,
				 * String.valueOf(report.getFirsttimetotroubleticketid()),
				 * Element.ALIGN_RIGHT, 1, bf12); insertCell(table,
				 * String.valueOf(report.getImpact()), Element.ALIGN_RIGHT, 1,
				 * bf12); insertCell(table,
				 * String.valueOf(report.getInmaintenance()),
				 * Element.ALIGN_RIGHT, 1, bf12); insertCell(table,
				 * String.valueOf(report.getInstancedisplayname()),
				 * Element.ALIGN_RIGHT, 1, bf12); insertCell(table,
				 * String.valueOf(report.getInstancename()),
				 * Element.ALIGN_RIGHT, 1, bf12); insertCell(table,
				 * String.valueOf(report.getIsproblem()), Element.ALIGN_RIGHT,
				 * 1, bf12); insertCell(table,
				 * String.valueOf(report.getIsroot()), Element.ALIGN_RIGHT, 1,
				 * bf12); insertCell(table,
				 * String.valueOf(report.getIsrootfirstvalue()),
				 * Element.ALIGN_RIGHT, 1, bf12); insertCell(table,
				 * String.valueOf(report.getLastchangedat()),
				 * Element.ALIGN_RIGHT, 1, bf12); insertCell(table,
				 * String.valueOf(report.getOccurrencecount()),
				 * Element.ALIGN_RIGHT, 1, bf12); insertCell(table,
				 * String.valueOf(report.getOwner()), Element.ALIGN_RIGHT, 1,
				 * bf12); insertCell(table,
				 * String.valueOf(report.getOwnerfirstuser()),
				 * Element.ALIGN_RIGHT, 1, bf12); insertCell(table,
				 * String.valueOf(report.getSeverity()), Element.ALIGN_RIGHT, 1,
				 * bf12); insertCell(table, String.valueOf(report.getSource()),
				 * Element.ALIGN_RIGHT, 1, bf12); insertCell(table,
				 * String.valueOf(report.getSourcedomainname()),
				 * Element.ALIGN_RIGHT, 1, bf12); insertCell(table,
				 * String.valueOf(report.getSourceeventtype()),
				 * Element.ALIGN_RIGHT, 1, bf12); insertCell(table,
				 * String.valueOf(report.getTroubleticketid()),
				 * Element.ALIGN_RIGHT, 1, bf12); insertCell(table,
				 * String.valueOf(report.getTroubleticketidfirstvalue()),
				 * Element.ALIGN_RIGHT, 1, bf12); insertCell(table,
				 * String.valueOf(report.getUpdatedat()), Element.ALIGN_RIGHT,
				 * 1, bf12); insertCell(table,
				 * String.valueOf(report.getUserdefined1()),
				 * Element.ALIGN_RIGHT, 1, bf12); insertCell(table,
				 * String.valueOf(report.getUserdefined2()),
				 * Element.ALIGN_RIGHT, 1, bf12); insertCell(table,
				 * String.valueOf(report.getUserdefined4()),
				 * Element.ALIGN_RIGHT, 1, bf12); insertCell(table,
				 * String.valueOf(report.getUserdefined3()),
				 * Element.ALIGN_RIGHT, 1, bf12); insertCell(table,
				 * String.valueOf(report.getUserdefined5()),
				 * Element.ALIGN_RIGHT, 1, bf12); insertCell(table,
				 * String.valueOf(report.getUserdefined6()),
				 * Element.ALIGN_RIGHT, 1, bf12); insertCell(table,
				 * String.valueOf(report.getUserdefined7()),
				 * Element.ALIGN_RIGHT, 1, bf12); insertCell(table,
				 * String.valueOf(report.getUserdefined8()),
				 * Element.ALIGN_RIGHT, 1, bf12); insertCell(table,
				 * String.valueOf(report.getUserdefined9()),
				 * Element.ALIGN_RIGHT, 1, bf12); insertCell(table,
				 * String.valueOf(report.getUserdefined10()),
				 * Element.ALIGN_RIGHT, 1, bf12); insertCell(table,
				 * String.valueOf(report.getUserdefined11()),
				 * Element.ALIGN_RIGHT, 1, bf12); insertCell(table,
				 * String.valueOf(report.getUserdefined12()),
				 * Element.ALIGN_RIGHT, 1, bf12); insertCell(table,
				 * String.valueOf(report.getUserdefined13()),
				 * Element.ALIGN_RIGHT, 1, bf12); insertCell(table,
				 * String.valueOf(report.getUserdefined14()),
				 * Element.ALIGN_RIGHT, 1, bf12); insertCell(table,
				 * String.valueOf(report.getUserdefined15()),
				 * Element.ALIGN_RIGHT, 1, bf12); insertCell(table,
				 * String.valueOf(report.getUserdefined16()),
				 * Element.ALIGN_RIGHT, 1, bf12); insertCell(table,
				 * String.valueOf(report.getUserdefined17()),
				 * Element.ALIGN_RIGHT, 1, bf12); insertCell(table,
				 * String.valueOf(report.getUserdefined18()),
				 * Element.ALIGN_RIGHT, 1, bf12); insertCell(table,
				 * String.valueOf(report.getUserdefined19()),
				 * Element.ALIGN_RIGHT, 1, bf12); insertCell(table,
				 * String.valueOf(report.getUserdefined20()),
				 * Element.ALIGN_RIGHT, 1, bf12);
				 */
			}
			paragraph.add(table);
			document.add(paragraph);
			document.close();
		}

	}

}
