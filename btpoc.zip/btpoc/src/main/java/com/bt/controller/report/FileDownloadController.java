package com.bt.controller.report;

import java.io.ByteArrayOutputStream;
import java.util.List;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.supercsv.io.CsvBeanWriter;
import org.supercsv.io.ICsvBeanWriter;
import org.supercsv.prefs.CsvPreference;

import com.bt.entity.common.CommonData;
import com.bt.entity.report.ReportData;
import com.bt.entity.report.ReportDataList;
import com.bt.service.report.ReportDataService;
import com.bt.util.ReportHelper;

/**
 * Thsi class help to download file as CSV
 * 
 * @author 611022163
 *
 */
@RestController
@RequestMapping("/api/filereport")
public class FileDownloadController {

	private static final String CSV = "CSV";
	private static final String PDF = "PDF";
	private static final String TXT = "TXT";
	private static final String XLS = "XLS";
	private static final Logger logger = LoggerFactory.getLogger(FileDownloadController.class);

	@Autowired
	ReportDataService reportDataService;

	@RequestMapping(value = "/downloadFileReport/{filetype}/{templateid}/{configid}")
	public void getAllReports(@PathVariable String filetype, @PathVariable String templateid,
			@PathVariable String configid, HttpServletRequest request, HttpServletResponse response) {
		logger.debug(" getAllReports() : File Type : " + filetype);
		CommonData commonprop = new CommonData();
		ReportDataList reportdetails=new ReportDataList();
		if (!StringUtils.isEmpty(configid) && !StringUtils.isEmpty(templateid)) {
			commonprop.setConfigid(configid);
			commonprop.setTemplateid(templateid);
			commonprop.setPagesize(1000);
			commonprop.setPagenumber(1);
		}

		if (!StringUtils.isEmpty(filetype)) {
			try {
				List<ReportData> reportdatalist = reportDataService.getAllReportsAccoringtoTemplate(commonprop);
				reportdetails.setReportdatalist(reportdatalist);
				reportdetails.setCommondata(commonprop);
				
				if (CSV.equalsIgnoreCase(filetype)) {
					createCSVFile(response, reportdetails);
				}
				if (PDF.equalsIgnoreCase(filetype)) {
					createPDFFile(response, reportdetails);
				}
				if (TXT.equalsIgnoreCase(filetype)) {
					createTXTFile(response, reportdetails);
				}
				if (XLS.equalsIgnoreCase(filetype)) {
					createXLSFile(response, reportdetails);
				}
			} catch (Exception exp) {
				logger.error(" Unable perform operation : " + exp.getMessage(), exp);
			}

		}

	}

	/**
	 * 
	 * @param response
	 * @param reportdatalist
	 * @throws Exception
	 */
	private void createXLSFile(HttpServletResponse response, ReportDataList reportdetails) throws Exception {
		
		HSSFWorkbook workBook=ReportHelper.createExcel(response,reportdetails);
		//response.getOutputStream().write(workBook.getBytes());
		workBook.write(response.getOutputStream()); 
		
	}

	/**
	 * This method will create csv file
	 * 
	 * @param response
	 * @throws Exception
	 */
	private void createCSVFile(HttpServletResponse response, ReportDataList reportdetails) throws Exception {
		ICsvBeanWriter csvWriter = null;
		try {
			String csvFileName = "report_data.csv";
			response.setContentType("text/csv");
			String headerKey = "Content-Disposition";
			String headerValue = String.format("attachment; filename=\"%s\"", csvFileName);
			response.setHeader(headerKey, headerValue);
			csvWriter = new CsvBeanWriter(response.getWriter(), CsvPreference.STANDARD_PREFERENCE);
			ReportHelper.createCSV(csvWriter, reportdetails);
		} finally {
			if (null != csvWriter) {
				csvWriter.flush();
				csvWriter.close();
			}
		}
	}

	/**
	 * This method will be create pdf
	 * 
	 * @param response
	 * @throws Exception
	 */
	private void createPDFFile(HttpServletResponse response, ReportDataList reportdetails) throws Exception {

		String pdffilename = "report_data.pdf";
		response.setContentType("application/pdf");
		String headerKey = "Content-Disposition";
		String headerValue = String.format("filename=\"%s\"", pdffilename);
		response.setHeader(headerKey, headerValue);
		ByteArrayOutputStream bytearray = ReportHelper.createPDF(reportdetails);
		response.getWriter().write(bytearray.toString("UTF-8"));
		// ServletOutputStream sos = response.getOutputStream();
		// response.setContentLength(bytearray.size());
		// bytearray.writeTo(sos);
		bytearray.flush();
		bytearray.close();
		// sos.flush();
		// sos.close();
		response.getWriter().flush();
		response.getWriter().close();

	}

	/**
	 * This method will be create pdf
	 * 
	 * @param response
	 * @throws Exception
	 */
	private void createTXTFile(HttpServletResponse response, ReportDataList reportdetails) throws Exception {
		String pdffilename = "report_data.pdf";
		response.setContentType("text/plain");
		String headerKey = "Content-Disposition";
		String headerValue = String.format("attachment; filename=\"%s\"", pdffilename);
		response.setHeader(headerKey, headerValue);
		ByteArrayOutputStream bytearray = ReportHelper.createTXT(reportdetails);
		ServletOutputStream sos = response.getOutputStream();
		response.setContentLength(bytearray.size());
		bytearray.writeTo(sos);
		bytearray.flush();
		bytearray.close();
		sos.flush();
		sos.close();

	}
}
