package com.bt.controller.report;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bt.entity.common.CommonData;
import com.bt.entity.report.ReportData;
import com.bt.entity.report.ReportDataList;
import com.bt.entity.template.NodeOneTemplate;
import com.bt.entity.template.ParentNodeTemplate;
import com.bt.service.report.ReportDataService;
import com.bt.util.TemplateObjectCreator;

@RestController
@RequestMapping("/api/report")
public class ReportDataController {

	private static final Logger logger = LoggerFactory.getLogger(ReportDataController.class);

	@Autowired
	ReportDataService reportDataService;

	@RequestMapping(value = "/getAllReports", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<ReportData>> getAllReports() {
		if (logger.isDebugEnabled()) {
			logger.debug(" getAllReports() : ");
		}
		List<ReportData> reportdatalist = reportDataService.getAllReports();
		if (logger.isDebugEnabled()) {
			logger.debug(" getAllReports() : reportdatlist: " + reportdatalist);
		}
		return new ResponseEntity<List<ReportData>>(reportdatalist, HttpStatus.OK);
	}

	@RequestMapping(value = "/getAllReportwithPageination/{pagenumber}/{pagesize}/{lastid}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<ReportData>> getAllReports(@PathVariable int pagenumber, @PathVariable int pagesize,
			@PathVariable int lastid) {
		if (logger.isDebugEnabled()) {
			logger.debug(getAllReports() + " Page Number : " + pagenumber + " Page Size : " + pagesize);
		}
		List<ReportData> reportdatalist = reportDataService.getAllReports(pagenumber, pagesize);
		if (logger.isDebugEnabled()) {
			logger.debug(" getAllReports() : reportdatlist: " + reportdatalist);
		}
		return new ResponseEntity<List<ReportData>>(reportdatalist, HttpStatus.OK);
	}

	/**
	 * 
	 * @param reportData
	 * @return
	 */

	@RequestMapping(value = "/getReportsAccordingTemplate/{pagenumber}/{pagesize}/{templateid}/{configid}/{duration}/{starttime}/{endtime}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ReportDataList> getReportsAccordingTemplate(@PathVariable int pagenumber,
			@PathVariable int pagesize, @PathVariable String templateid, @PathVariable String configid,
			@PathVariable String duration, @PathVariable String starttime, @PathVariable String endtime) {
		if (logger.isDebugEnabled()) {
			logger.debug("getReportsForTemplate() CommonData  ");
		}
		ReportDataList reportdetails = new ReportDataList();
		List<ReportData> reportdatalist = null;
		CommonData commonprop = new CommonData();
		commonprop.setPagenumber(pagenumber);
		commonprop.setPagesize(pagesize);
		if (!StringUtils.isEmpty(duration)) {
			commonprop.setDuration(duration);
		}
		if (!StringUtils.isEmpty(starttime) && !"null".equalsIgnoreCase(starttime)) {
			commonprop.setStarttime(starttime);
		}
		if (!StringUtils.isEmpty(starttime) && !"null".equalsIgnoreCase(starttime)) {
			commonprop.setEndtime(endtime);
		}
		if (!StringUtils.isEmpty(configid) && !StringUtils.isEmpty(templateid)) {
			commonprop.setConfigid(configid);
			commonprop.setTemplateid(templateid);
		} else {
			return new ResponseEntity<ReportDataList>(reportdetails, HttpStatus.BAD_REQUEST);
		}
		try {
			reportdatalist = reportDataService.getAllReportsAccoringtoTemplate(commonprop);
			reportdetails.setReportdatalist(reportdatalist);
			reportdetails.setCommondata(commonprop);
		} catch (Exception ex) {
			logger.error(" Unable to process request :" + ex.getMessage(), ex);
			return new ResponseEntity<ReportDataList>(reportdetails, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		if (logger.isDebugEnabled()) {
			logger.debug(" getAllReports() : reportdatlist: " + reportdatalist);
		}
		return new ResponseEntity<ReportDataList>(reportdetails, HttpStatus.OK);
	}

	@RequestMapping(value = "/saveCustomTemplateSchema", method = RequestMethod.GET, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<ReportData>> saveCustomTemplateSchema(@RequestBody ParentNodeTemplate parentNode) {
		// TODO: Save the parentNode JSON in db against the TEMPLATE ID;
		return null;
	}

	@RequestMapping(value = "/getCustomTemplateData/{templateid}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<ReportData>> getCustomTemplateData(@PathVariable int templateid) {
		// TODO: retrieve the JSON Object against the templateid

		return null;
	}

	@RequestMapping(value = "/getTreeCustomTemplateData", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<ParentNodeTemplate>> getTreeCustomTemplateData() {
		List<ParentNodeTemplate> parentList1 = new ArrayList<ParentNodeTemplate>();
		// Creating the first Parent Item of an array
		ParentNodeTemplate parent1 = (ParentNodeTemplate) TemplateObjectCreator.getTemplateObject("parent");

		parent1.setLabel("BT Test Reports");
		parent1.setId("main");

		// have to add children array
		// parent1.setChildren(children);

		List<NodeOneTemplate> childList1 = new ArrayList<NodeOneTemplate>();
		NodeOneTemplate children1 = (NodeOneTemplate) TemplateObjectCreator.getTemplateObject("children");
		children1.setLabel("All Events All Fields");
		children1.setId("mainchild1");
		childList1.add(children1);

		NodeOneTemplate children2 = (NodeOneTemplate) TemplateObjectCreator.getTemplateObject("children");
		children2.setLabel("Auto TT");
		children2.setId("mainchild2");
		childList1.add(children2);

		parent1.setChildren(childList1);
		parentList1.add(parent1);
		// Creating the second Parent Item of an array

		ParentNodeTemplate parent2 = (ParentNodeTemplate) TemplateObjectCreator.getTemplateObject("parent");

		parent2.setLabel("User Defined Reports");
		parent2.setId("role121");

		// have to add children array
		// parent1.setChildren(children);

		List<NodeOneTemplate> childList2 = new ArrayList<NodeOneTemplate>();
		NodeOneTemplate children3 = (NodeOneTemplate) TemplateObjectCreator.getTemplateObject("children");
		children3.setLabel("New Report 1");
		children3.setId("udchild1");
		childList2.add(children3);

		NodeOneTemplate children4 = (NodeOneTemplate) TemplateObjectCreator.getTemplateObject("children");
		children4.setLabel("New Report 2");
		children4.setId("udchild2");
		childList2.add(children4);

		parent2.setChildren(childList2);
		parentList1.add(parent2);

		// Creating the third Parent Item of an array

		ParentNodeTemplate parent3 = (ParentNodeTemplate) TemplateObjectCreator.getTemplateObject("parent");

		parent3.setLabel("Guest");
		parent3.setId("role3");

		parentList1.add(parent3);

		return new ResponseEntity<List<ParentNodeTemplate>>(parentList1, HttpStatus.OK);

	}

}
