package com.bt.controller.login;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bt.security.entity.UserVO;
import com.bt.security.service.TokenAuthenticationService;
import com.bt.security.service.UserService;

@RestController
@RequestMapping("/app")
public class LoginController {
	private static final Logger logger = LoggerFactory.getLogger(LoginController.class);
	@Autowired
	UserService userservice;
	
	@Autowired
	TokenAuthenticationService tokenAuthenticationService;	
	
	
	@RequestMapping(value = "/login", method = RequestMethod.POST,produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UserVO> login() {
		if (logger.isDebugEnabled()) {
			logger.debug(" login()  ");
		}
		UserVO uservo = null;
		if (SecurityContextHolder.getContext().getAuthentication().isAuthenticated()) {
			if (SecurityContextHolder.getContext().getAuthentication().getPrincipal() instanceof UserVO) {
				uservo = (UserVO) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
				if (StringUtils.isEmpty(uservo.getToken())) {
					String token = tokenAuthenticationService.getTokenHandler().createTokenForUser(uservo);
					uservo.setToken(token);
				} else {
					uservo = tokenAuthenticationService.getTokenHandler().parseUserFromToken(uservo.getToken());
				}
			}

		}
		if (logger.isDebugEnabled()) {
			logger.debug(" getAllReports() : reportdatlist: ");
		}
		return new ResponseEntity<UserVO>(uservo, HttpStatus.OK);
	}
	
	

}
