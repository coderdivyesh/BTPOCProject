package com.bt.controller.admin;

import java.util.Base64;
import java.util.HashMap;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bt.entity.report.DefaultReport;
import com.bt.entity.report.ReportDataList;
import com.bt.security.entity.Authority;
import com.bt.security.entity.User;
import com.bt.security.entity.UserVO;
import com.bt.security.service.UserActive;
import com.bt.service.report.template.ReportTemplateService;
import com.bt.service.user.UserService;

@RestController
@RequestMapping("/admin")
public class AdminController {
	
	
	@Autowired
	UserService userService;
	@Autowired
	ReportTemplateService reporttemplateservice;
	
	private static final Logger logger = LoggerFactory.getLogger(AdminController.class);
	
	
	@RequestMapping(value="/createNewUser", method = RequestMethod.POST)
	public ResponseEntity<User> createNewUser(@RequestBody User newUser) {
		if (null != newUser) {
			try {
                if(newUser.getAuthorities() != null)
                {
                	for(Authority auth :newUser.getAuthorities())
                	{
                		if(auth.getName().equals("READ WRITE"))
                			auth.setName("ROLE_ADMIN");
                		else
                			auth.setName("ROLE_USER");
                		  
                	}
                }
				newUser.setPassword(Base64.getEncoder().encodeToString(newUser.getPassword().getBytes()));
				userService.insertUser(newUser);
				//setup default template for user
				DefaultReport defaultreport =new DefaultReport();
				defaultreport.setUsername(newUser.getUsername());
				reporttemplateservice.insertUserDefaultTemplate(defaultreport);
			} catch (Exception ex) {
				logger.error(" createNewUser() "+ex.getMessage(),ex);
				return	new ResponseEntity<User>(newUser, HttpStatus.BAD_REQUEST);
			}
		} else {
			return	new ResponseEntity<User>(newUser, HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<User>(newUser, HttpStatus.OK);
	}
	

	
	
	@RequestMapping(value="/updateUser", method = RequestMethod.POST)
	public ResponseEntity<User> updateUser(@RequestBody User updUser) {
		if (null != updUser) {
			try {
                
				userService.updateUser(updUser);
				userService.loadUser();
			} catch (Exception ex) {
				logger.error(" updateUser() "+ex.getMessage(),ex);
				return	new ResponseEntity<User>(updUser, HttpStatus.BAD_REQUEST);
			}
		} else {
			return	new ResponseEntity<User>(updUser, HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<User>(updUser, HttpStatus.OK);
	}

	
	
	@RequestMapping(value="/loadDefaultUser", method = RequestMethod.GET)
	public void loadUsers() {
		try {
			userService.loadUser();
		} catch (Exception ex) {
			logger.error(" loadUsers() "+ex.getMessage(),ex);
		}
	}
	
	/**
	 * for showing active users 
	 * @return
	 */
	
	@RequestMapping(value = "/showActiveUsers", method = RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE )
	public ResponseEntity<List<UserActive>> getAllActiveUser() {
		if (logger.isDebugEnabled()) {
			logger.debug(" getActiveUsers() : ");
		}
		List<UserActive> ActiveUserList=null;
		try {
			ActiveUserList = userService.getActiveUsers();
		} catch (Exception ex) {
			logger.error("  getAllActiveUser() :"+ex.getMessage(),ex);
		}
		if (logger.isDebugEnabled()) {
			logger.debug(" getActiveUsers() : ActiveUserList: " + ActiveUserList);
		}
		return new ResponseEntity<List<UserActive>>(ActiveUserList, HttpStatus.OK);
	}
	
	
	

	
	
	@RequestMapping(value = "/getAllUser", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE , consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<HashMap<String, UserVO>> getAllUser() {
		if (logger.isDebugEnabled()) {
			logger.debug(" getAllUser() : ");
		}
		loadUsers();
		HashMap<String, UserVO> listofuser=com.bt.security.service.UserService.getAllUser();
		/*if(null==listofuser || listofuser.isEmpty()){
			loadUsers();
			listofuser=com.bt.security.service.UserService.getAllUser();
		}*/
		if (logger.isDebugEnabled()) {
			logger.debug(" getAllUser() : Userdatalist: " + listofuser);
		}
		return new ResponseEntity<HashMap<String, UserVO>>(listofuser, HttpStatus.OK);
	}
	/**
	 * for deleting  active users from admin end
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value = "/killActiveUsers",method = RequestMethod.POST,produces = MediaType.APPLICATION_JSON_VALUE , consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UserActive> killAllActiveUser(@RequestBody UserActive uactive) throws Exception{
		if (logger.isDebugEnabled()) {
			logger.debug(" killActiveUsers() : ");
		}
		if (!StringUtils.isEmpty(uactive.getTokenId())&&!StringUtils.isEmpty(uactive.getUsername())) {
			userService.killActiveUsers(uactive);
		} else {
			return new ResponseEntity<UserActive>(uactive, HttpStatus.BAD_REQUEST);
		}
		
		return new ResponseEntity<UserActive>(uactive, HttpStatus.OK);
		
	}
}
