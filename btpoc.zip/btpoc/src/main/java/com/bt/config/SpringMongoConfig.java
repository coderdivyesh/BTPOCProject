package com.bt.config;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.StringUtils;

import com.mongodb.DBCollection;
import com.mongodb.MongoClient;
/**
 * All configuration related for mongo data base . It load mongo related properties from mopngo.properties file.
 * @author 611022163
 *
 */
@Configuration
public class SpringMongoConfig   {

	private static final Logger logger = LoggerFactory.getLogger(SpringMongoConfig.class);
	private  Map<String,DBCollection> collectionlist;
	
	@Autowired
	MongoDBProperties dpDbProperties;
		
	
	
	public DBCollection getCollection(String collectioname) {
		DBCollection collection = null;
		if (null == collectionlist) {
			collectionlist = new HashMap<String, DBCollection>();
		}
		synchronized (SpringMongoConfig.class) {

			if (StringUtils.isEmpty(collectioname)) {
				collection = collectionlist.get(dpDbProperties.dbcollection);
				if (null == collection) {
					collection = new MongoClient(dpDbProperties.contactpoints,
							Integer.parseInt(dpDbProperties.portnumber)).getDB(dpDbProperties.dbname)
									.getCollection(dpDbProperties.dbcollection);
					collectionlist.put(dpDbProperties.dbcollection, collection);
				}
			} else {
				collection = collectionlist.get(collectioname);
				if (null == collection) {
					collection = new MongoClient(dpDbProperties.contactpoints,
							Integer.parseInt(dpDbProperties.portnumber)).getDB(dpDbProperties.dbname)
									.getCollection(collectioname);
					collectionlist.put(collectioname, collection);
				}
			}
		}
		return collection;
	}

}
