package com.bt.common;

public class TemplateConfiguration {
	

	protected String templateid;
	
	protected String templateconfig;

}
