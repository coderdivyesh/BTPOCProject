package com.bt.common;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Stack;

import org.springframework.util.StringUtils;

import com.bt.constant.FilterCondition;
import com.bt.entity.common.CommonData;
import com.bt.entity.common.TemplateConfiguration;
import com.bt.entity.template.ExpressionDetails;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mongodb.BasicDBObject;
import com.mongodb.BasicDBObjectBuilder;
import com.mongodb.DBObject;
import com.mongodb.util.JSON;

public class QueryForm {
	
	
	public static BasicDBObject formQuery(CommonData commandata) throws Exception {
		long filtertime = 0;
		BasicDBObject wherequery = new BasicDBObject();
		if (!StringUtils.isEmpty(commandata.getDuration())) {
			filtertime = convertDurationToMiliseconds(commandata.getDuration());
			wherequery.put("OpenedAt", new BasicDBObject("$gte",filtertime));
		} else if (!StringUtils.isEmpty(commandata.getEndtime()) && !StringUtils.isEmpty(commandata.getStarttime())) {
			wherequery.put("OpenedAt",
					new BasicDBObject("$gte", commandata.getStarttime()).append("$lte", commandata.getEndtime()));
		} else if (!StringUtils.isEmpty(commandata.getEndtime())) {
			wherequery.put("OpenedAt", commandata.getEndtime());
		} else if (!StringUtils.isEmpty(commandata.getStarttime())) {
			wherequery.put("OpenedAt", commandata.getStarttime());
		}
		
		return wherequery;
	}

	public static long convertEpoch(String datestring) throws Exception{
		    SimpleDateFormat df = new SimpleDateFormat("MMM dd yyyy HH:mm:ss.SSS zzz");
		    Date date = df.parse(datestring);
		   return date.getTime();
	}
	
	private static long convertDurationToMiliseconds(String duration) {
		long timeseconds = 60;
		long timeminutes = 60;
	    long defaultvale=0;
		ZoneId zoneId = ZoneId.of("UTC"); 
		if (!StringUtils.isEmpty(duration)) {
			String timevalue = null;
			if (duration.contains("seconds")) {
				timevalue = duration.replace("seconds", "");
				long time = Long.parseLong(timevalue);
				LocalDate local=LocalDate.now();
				return local.atStartOfDay(zoneId).toEpochSecond()+time;
			} else if (duration.contains("minutes")) {
				timevalue = duration.replace("minutes", "");
				long time = Long.parseLong(timevalue);
				LocalDate local=LocalDate.now();
				return local.atStartOfDay(zoneId).toEpochSecond()+(timeseconds*time);
			} else if (duration.contains("hours")) {
				timevalue = duration.replace("hours", "");
				long time = Long.parseLong(timevalue);
				LocalDate local=LocalDate.now();
				return local.atStartOfDay(zoneId).toEpochSecond()+(timeminutes*timeseconds*time);
			} else if (duration.contains("day")) {
				timevalue = duration.replace("day", "");
				long time = Long.parseLong(timevalue);
				LocalDate local=LocalDate.now().minusDays(time);
				return local.atStartOfDay(zoneId).toEpochSecond();
			} else if (duration.contains("week")) {
				timevalue = duration.replace("week", "");
				long time = Long.parseLong(timevalue);
				LocalDate local=LocalDate.now().minusWeeks(time);
				return local.atStartOfDay(zoneId).toEpochSecond();
			} else if (duration.contains("month")) {
				timevalue = duration.replace("month", "");
				long time = Long.parseLong(timevalue);
				LocalDate local=LocalDate.now().minusMonths(time);
				return local.atStartOfDay(zoneId).toEpochSecond();
				
			} else if (duration.contains("year")) {
				timevalue = duration.replace("year", "");
				long time = Long.parseLong(timevalue);
				LocalDate local=LocalDate.now().minusYears(time);
				return local.atStartOfDay(zoneId).toEpochSecond();
			}
		}
		return defaultvale;
	
	}
	
	public static BasicDBObject formQuery(List<QueryFormParameter> params) {
		BasicDBObject conditionquery = new BasicDBObject();
		for (QueryFormParameter parameter : params) {
			String name = parameter.getColumname();
			Object value = parameter.getColumvalue();
			if (Condition.EQUALS.equals(parameter.getCondition())) {
				conditionquery.append(name,value);
				}
		}
		return conditionquery;
	}
	
	public static BasicDBObject formQueryForNodeDeletion(List<QueryFormParameter> params) {
		BasicDBObject wherequery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		for (QueryFormParameter parameter : params) {
			String name = parameter.getColumname();
			Object value = parameter.getColumvalue();
			BasicDBObject conditionquery = new BasicDBObject();
			if (Condition.EQUALS.equals(parameter.getCondition())) {
				conditionquery.put(name, value);
				obj.add(conditionquery);
				wherequery.put("$and", obj);
			}
		}
		
		return wherequery;
	}

	

	
	
	public static DBObject fromDBObject(Object nodes) throws Exception {
		ObjectMapper jsonObjectmapper = new ObjectMapper();
		String jsonString = jsonObjectmapper.writeValueAsString(nodes);
		return (DBObject) JSON.parse(jsonString);

	}

	
	public static BasicDBObject fromBasicDBObject(Object nodes) throws Exception {
		ObjectMapper jsonObjectmapper = new ObjectMapper();
		String jsonString = jsonObjectmapper.writeValueAsString(nodes);
		return (BasicDBObject) JSON.parse(jsonString);
	}

	
	/**
	 * 
	 * @param templateconfig
	 * @return
	 * @throws Exception
	 */
	public static BasicDBObject formQueryAccordingToTemplateConfiguration(TemplateConfiguration templateconfig) throws Exception {
		BasicDBObject openAtQuery = new BasicDBObject();
	long filtertime=0;
		if (!StringUtils.isEmpty(templateconfig.getNode().getDuration())) {
			filtertime = convertDurationToMiliseconds(templateconfig.getNode().getDuration());
			openAtQuery.put("OpenedAt", new BasicDBObject("$gte",filtertime));
		}
		return formQueryForExpression(templateconfig.getExpressionmap(),openAtQuery);
	}

	/**
	 * 
	 * @param expressionmap
	 * @param wherequery
	 * @return
	 */
	public static BasicDBObject formQueryForExpression(Map<String, ExpressionDetails> expressionMapDetails,
			BasicDBObject openAtQuery) {
		BasicDBObject  whereQuery=new BasicDBObject();
		List<BasicDBObject> andexpressionquery = new ArrayList<BasicDBObject>();
		List<BasicDBObject> orexpressionquery = new ArrayList<BasicDBObject>();
		if (null != expressionMapDetails && !expressionMapDetails.isEmpty()) {
			for (Map.Entry<String, ExpressionDetails> entry : expressionMapDetails.entrySet()) {
	                String key=entry.getKey();
					ExpressionDetails expdetails = entry.getValue();
					if (null != expdetails) {
						BasicDBObject basicdb = new BasicDBObject();
						if (FilterCondition.EQUALS.equals(expdetails.getInnerJoinOpeartion())) {
							basicdb.put(key, expdetails.getValue());
						} else if (FilterCondition.NOT_EQUALS.equals(expdetails.getInnerJoinOpeartion())) {
							basicdb.put(key, new BasicDBObject(FilterCondition.MONGO_NOT_EQUALS.getValue(),
									expdetails.getValue()));
						} else if (FilterCondition.GRATER_THAN.equals(expdetails.getInnerJoinOpeartion())) {
							basicdb.put(key, new BasicDBObject(FilterCondition.MONGO_GRATER_THAN.getValue(),
									expdetails.getValue()));
						} else if (FilterCondition.GRATER_THAN_EQUALS.equals(expdetails.getInnerJoinOpeartion())) {
							basicdb.put(key, new BasicDBObject(FilterCondition.MONGO_GRATER_THAN_EQUALS.getValue(),
									expdetails.getValue()));
						} else if (FilterCondition.LESS_THAN.equals(expdetails.getInnerJoinOpeartion())) {
							basicdb.put(key,
									new BasicDBObject(FilterCondition.MONGO_LESS_THAN.getValue(), expdetails.getValue()));
						} else if (FilterCondition.LESS_THAN_EQUALS.equals(expdetails.getInnerJoinOpeartion())) {
							basicdb.put(key, new BasicDBObject(FilterCondition.MONGO_LESS_THAN_EQUALS.getValue(),
									expdetails.getValue()));
						}
						if (FilterCondition.AND.equals(expdetails.getOuterJoinOperation())) {
							andexpressionquery.add(basicdb);
						}
						if (FilterCondition.OR.equals(expdetails.getOuterJoinOperation())) {
							orexpressionquery.add(basicdb);
						}
					}
			}

			if (andexpressionquery != null && !andexpressionquery.isEmpty()) {
				andexpressionquery.add(openAtQuery);
				whereQuery.append("$and", andexpressionquery);
			
			}
			if (orexpressionquery != null && !orexpressionquery.isEmpty()) {
				whereQuery.append("$or", andexpressionquery);
			}
		}
		if (whereQuery.isEmpty()) {
			return openAtQuery;
		}

		return whereQuery;
	}

	

}
