package com.bt.common;
/**
 * 
 * @author 611022675
 *
 */
public enum Condition {
	EQUALS("="),OR("||");
	private final String text;

	/**
	 * @param text
	 */
	private Condition(final String text) {
		this.text = text;
	}

	@Override
	public String toString() {
		return text;
	}

}
