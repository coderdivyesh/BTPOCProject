package com.bt.common;

import java.io.Serializable;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.bt.entity.common.CommonData;
import com.bt.entity.report.ReportData;
/**
 * 
 * @author 611022163
 *
 */
@Repository
public class AbstractDAO extends MongoOperationUtils implements Serializable {
	/**
	 * 
	 */
	private static final Logger logger = LoggerFactory.getLogger(AbstractDAO.class);
	
	private static final long serialVersionUID = 3530428536344475625L;
	


      @SuppressWarnings("unchecked")
	public List<ReportData> selectAll(){
    	  return (List<ReportData>)getAllObjects(ReportData.class);
      }

      @SuppressWarnings("unchecked")
  	public List<ReportData> selectAll(int pagenumber, int pagesize){
      	  return (List<ReportData>)getAllObjects(ReportData.class,pagenumber,pagesize);
        }
      
      @SuppressWarnings("unchecked")
    	public List<ReportData> selectAllAccotringtoTemplate(CommonData reportdata) throws Exception{
        	  return (List<ReportData>)getAllObjectsAccordingToTemplate(reportdata);
          }
    
}
