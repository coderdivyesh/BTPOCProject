package com.bt.common;

import java.lang.annotation.Annotation;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Spliterator;
import java.util.StringTokenizer;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.util.StringUtils;

import com.bt.constant.OperationType;
import com.bt.entity.common.CommonData;
import com.bt.entity.template.Node;
import com.mongodb.BasicDBObject;

public class QueryHelper  implements QueryConstant{

	static String DELIM_OPERATOR = "."; 
	static int START_OF_SECOND_ELEMENT=1;
	
	/**
	 * Create a graph query according to time period such as 3 month data
	 * @param commandata
	 * @param filtertime
	 * @return
	 * @throws Exception
	 */
	public static BasicDBObject formGraphQuery(CommonData commandata,long filtertime) throws Exception {
		BasicDBObject wherequery = new BasicDBObject();
		String xparam = commandata.getDisplayprams().get(0).getDbname();
		if (!StringUtils.isEmpty(commandata.getDuration())) {		
			wherequery.put(xparam, new BasicDBObject(GREATERTHANEQUAL,filtertime));
		}
		return wherequery;
	}
	
	public static BasicDBObject formQuery(CommonData commandata) throws Exception {
		long filtertime = 0;
		BasicDBObject wherequery = new BasicDBObject();
		String xparam = commandata.getDisplayprams().get(0).getDbname();

		if (!StringUtils.isEmpty(commandata.getDuration())) {
			filtertime = convertToEpochSeconds(commandata.getDuration());
			wherequery.put(xparam, new BasicDBObject(GREATERTHANEQUAL,filtertime));
		} else if (!StringUtils.isEmpty(commandata.getEndtime()) && !StringUtils.isEmpty(commandata.getStarttime())) {
			wherequery.put(xparam,
					new BasicDBObject(GREATERTHANEQUAL, commandata.getStarttime()).append(LESSTHANEQUAL, commandata.getEndtime()));
		} else if (!StringUtils.isEmpty(commandata.getEndtime())) {
			wherequery.put(xparam, commandata.getEndtime());
		} else if (!StringUtils.isEmpty(commandata.getStarttime())) {
			wherequery.put(xparam, commandata.getStarttime());
		}
		
		return wherequery;
	}

	public static long convertEpoch(String datestring) throws Exception{
		    SimpleDateFormat df = new SimpleDateFormat("MMM dd yyyy HH:mm:ss.SSS zzz");
		    Date date = df.parse(datestring);
		   return date.getTime();
	}
	
	/**
	 * Convert given time into epoch seconds
	 * @param sampleTime
	 * @return
	 */
	public static long convertToEpochSeconds(String sampleTime) {
		long timeseconds = 60;
		long timeminutes = 60;
	    long defaultvale=0;
		ZoneId zoneId = ZoneId.of("UTC"); 
		if (!StringUtils.isEmpty(sampleTime)) {
			String timevalue = null;
			if (sampleTime.contains(SECONDS)) {
				timevalue = sampleTime.replace(SECONDS, "");
				long time = Long.parseLong(timevalue);
				LocalDate local=LocalDate.now();
				return local.atStartOfDay(zoneId).toEpochSecond()+time;
			} else if (sampleTime.contains(MINUTES)) {
				timevalue = sampleTime.replace(MINUTES, "");
				long time = Long.parseLong(timevalue);
				LocalDate local=LocalDate.now();
				return local.atStartOfDay(zoneId).toEpochSecond()+(timeseconds*time);
			} else if (sampleTime.contains(HOURS)) {
				timevalue = sampleTime.replace(HOURS, "");
				long time = Long.parseLong(timevalue);
				LocalDate local=LocalDate.now();
				return local.atStartOfDay(zoneId).toEpochSecond()+(timeminutes*timeseconds*time);
			} else if (sampleTime.contains(DAY)) {
				timevalue = sampleTime.replace(DAY, "");
				long time = Long.parseLong(timevalue);
				LocalDate local=LocalDate.now().minusDays(time);
				return local.atStartOfDay(zoneId).toEpochSecond();
			} else if (sampleTime.contains(WEEK)) {
				timevalue = sampleTime.replace(WEEK, "");
				long time = Long.parseLong(timevalue);
				LocalDate local=LocalDate.now().minusWeeks(time);
				return local.atStartOfDay(zoneId).toEpochSecond();
			} else if (sampleTime.contains(MONTH)) {
				timevalue = sampleTime.replace(MONTH, "");
				long time = Long.parseLong(timevalue);
				LocalDate local=LocalDate.now().minusMonths(time);
				return local.atStartOfDay(zoneId).toEpochSecond();
				
			} else if (sampleTime.contains(YEAR)) {
				timevalue = sampleTime.replace(YEAR, "");
				long time = Long.parseLong(timevalue);
				LocalDate local=LocalDate.now().minusYears(time);
				return local.atStartOfDay(zoneId).toEpochSecond();
			}
		}
		return defaultvale;
	
	}
	
	/**
	 * Find colletion to fetch
	 * 
	 * @param claz
	 * @return
	 */
	public static  String getColletion(Class claz) {
		String collection = null;
		Annotation ety = claz.getAnnotation(Document.class);
		if (ety instanceof Document) {
			Document myAnnotation = (Document) ety;
			return myAnnotation.collection();
		}
		return collection;
	}
	

	/**
	 * This method will help in building the updatequery based on node level
	 * @param nodelevel
	 */
	public static String formInsertQueryAsPerNodeLevel(Queue<Integer> splitArray) {
		
		String sb="";
		int start=0;
		int[] intSplitArray = new int[splitArray.size()];
		Iterator<Integer> it=splitArray.iterator();
		while(it.hasNext())
		{
			intSplitArray[start]=it.next();
			start++;
		}
		// Staring the iteration from NODE_LEVEL_INSERT_CONFIGURATION because the first depth included the GLOBAL TEMPLATE also.
		for(int i=START_OF_SECOND_ELEMENT;i<splitArray.size();i++)
		{
			//here the value is substracted by NODE_LEVEL_INSERT_CONFIGURATION because in mongo the node level is started from 0
			sb=sb.concat("nodes." + intSplitArray[i] + "." );
		}
		return sb.concat("nodes");
	}
	
	public static String formDeleteQueryAsPerNodeLevel(Queue<Integer> splitArray) {
		
		String sb="";
		int start=0;
		int[] intSplitArray = new int[splitArray.size()];
		Iterator<Integer> it=splitArray.iterator();
		while(it.hasNext())
		{
			intSplitArray[start]=it.next();
			start++;
		}
		// Staring the iteration from NODE_LEVEL_INSERT_CONFIGURATION because the first depth included the GLOBAL TEMPLATE also.
		for(int i=START_OF_SECOND_ELEMENT;i<splitArray.size()-1;i++)
		{
			//here the value is substracted by NODE_LEVEL_INSERT_CONFIGURATION because in mongo the node level is started from 0
			sb=sb.concat("nodes." + intSplitArray[i] + "." );
		}
		return sb.concat("nodes");
	}
	
	
	/**
	 * 
	 * 
	 * @param node
	 * @return
	 */
	public static BasicDBObject formDeleteQueryForNode(Node node)
	{
	return new BasicDBObject().append(PARENTID, node.getParentid()).append(ID, node.getId() );
	}
	


	
	public static  int nodeLevelCounts(String nodelevel)
	{
		StringTokenizer tokens=null;
		if(!StringUtils.isEmpty(nodelevel)){
		 tokens=new StringTokenizer(nodelevel,".");
		}
	    return tokens.countTokens();
	}

	/**
	 * convert input time to seconds
	 * @param sampleTime
	 * @return
	 */
	public static long convertToSeconds(String sampleTime) {
	    long time=0;
		if (!StringUtils.isEmpty(sampleTime)) {
			String timevalue = null;
			if (sampleTime.contains(SECONDS)) {
				timevalue = sampleTime.replace(SECONDS, "");
				time = Long.parseLong(timevalue);
			} else if (sampleTime.contains(MINUTES)) {
				timevalue = sampleTime.replace(MINUTES, "");
				time = Long.parseLong(timevalue) * 60;
			} else if (sampleTime.contains(HOURS)) {
				timevalue = sampleTime.replace(HOURS, "");
				time = Long.parseLong(timevalue) * 3600;
			} else if (sampleTime.contains(DAY)) {
				timevalue = sampleTime.replace(DAY, "");
				time = Long.parseLong(timevalue) * 86400;
			} else if (sampleTime.contains(WEEK)) {
				timevalue = sampleTime.replace(WEEK, "");
				time = Long.parseLong(timevalue) * 604800;
			} else if (sampleTime.contains(MONTH)) {
				timevalue = sampleTime.replace(MONTH, "");
				time = Long.parseLong(timevalue) * 2592000;
			}
		}
		return time;
	}
	
	/**
     * 
      * 
      * @param nodelevel
     * @return
     */
     public static Queue<Integer> hierarchyIndexListForElement(String nodelevel) {
            Queue<Integer> indexlist =null;
            if (!StringUtils.isEmpty(nodelevel)) {
                   indexlist= new LinkedList<Integer>();
                   StringTokenizer tokens = new StringTokenizer(nodelevel, DELIM_OPERATOR);
                   while (tokens.hasMoreTokens()) {
                         if (indexlist.isEmpty()) {
                                indexlist.offer(0);
                                tokens.nextToken(); 
                         } else {
                         int  index=Integer.valueOf(tokens.nextToken())-1;
                                indexlist.offer(index);
                         }
                   }
            }
            
            return indexlist;
     }
     
/**
 * 
 * @param nodelevlcount
 * @param operationType
 * @return
 */
	public static String formNodeIdentifierAccordingToNodeLeveCount(int nodelevlcount, OperationType operationType) {
		int defaultcount = 1;
		int nodecount = nodelevlcount;
		StringBuilder buildnode = new StringBuilder();
		if (OperationType.SEARCH.equals(operationType)) {
			defaultcount = 2;
			while (defaultcount < nodecount) {
				buildnode.append("nodes").append(".");
				--nodecount;
			}
			buildnode.append("id");
		}

		return buildnode.toString();
	}

}
