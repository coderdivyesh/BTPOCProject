package com.bt.common;
/**
 * 
 * @author 611022675
 *
 */
public interface QueryConstant {
	String DELIM_OPERATOR = ".";
	String NODES_INSIDE_NODES = "nodes.$.nodes";
	String NODES = "nodes";
	String ID = "id";
	String PARENTID = "parentid";
	String GREATERTHANEQUAL = "$gte";
	String LESSTHANEQUAL = "$lte";
	String PULL = "$pull";
    String PUSH = "$push";
    int NODE_LEVEL_INSERT_CONFIGURATION=1;
    int NODE_LEVEL_DELETE_CONFIGURATION=2;
    
    //graph constants
    static final String $MATCH = "$match";
    static final String $GROUP = "$group";
	static final String $SORT = "$sort";
	static final String $DIVIDE = "$divide";
	static final String $MOD = "$mod";
	static final String $SUBTRACT = "$subtract";
	static final String $MULTIPLY = "$multiply";
	
    static final String SECONDS = "seconds";
    static final String MINUTES = "minutes";
    static final String HOURS = "hours";
    static final String DAY = "day";
    static final String WEEK = "week";
    static final String MONTH = "month";
    static final String YEAR = "year";  
}
