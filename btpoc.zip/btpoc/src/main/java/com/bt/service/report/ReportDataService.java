package com.bt.service.report;

import java.util.List;

import com.bt.entity.common.CommonData;
import com.bt.entity.report.ReportData;
/**
 * 
 * @author 611022163
 *
 */
public interface ReportDataService {

	public List<ReportData> getAllReports(int pagenumber,int pagesize);
	
	public List<ReportData> getAllReports();
	
	public List<ReportData> getAllReportsAccoringtoTemplate(CommonData reportData)throws Exception;
}
