package com.bt.service.graph;

import com.bt.entity.common.CommonData;
import com.bt.entity.graph.GraphDetails;

/**
 * 
 * @author 611022163
 *
 */
public interface GraphService {

	public GraphDetails fetchGraphdata(CommonData commondata) throws Exception;
	
}
