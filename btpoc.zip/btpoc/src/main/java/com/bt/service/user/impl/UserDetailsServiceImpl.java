package com.bt.service.user.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.bt.dao.user.UserServiceDAO;
import com.bt.security.entity.User;
import com.bt.security.helper.UserFactory;
import com.bt.service.user.UserService;

public class UserDetailsServiceImpl implements UserDetailsService,UserService {

    @Autowired
    UserServiceDAO userdao;


    public UserDetails loadUserByUsername( ) throws UsernameNotFoundException {
    	return loadUserByUsername("");
}

	
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		  User user = userdao.loadUserByUsername(username);
	        if (user == null) {
	            throw new UsernameNotFoundException(String.format("No user found with username '%s'.", username));
	        } else {
	            return UserFactory.create(user);
	        }
	    

	}
	
}
