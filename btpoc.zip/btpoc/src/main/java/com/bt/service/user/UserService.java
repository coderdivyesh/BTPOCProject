package com.bt.service.user;

import java.util.List;

//import com.bt.controller.admin.List;
import com.bt.security.entity.User;
import com.bt.security.service.UserActive;
public interface UserService {

	public void insertUser(User newUser) throws Exception;
	
	public void loadUser() throws Exception;

	public void updateUser(User updUser) throws Exception;
	
	public void insertToken(UserActive Useract) throws Exception;
	
	// for activeusers
	public List<UserActive> getActiveUsers() throws Exception;
	//for kill Active users
	public void killActiveUsers(UserActive uactive) throws Exception;

	
}
