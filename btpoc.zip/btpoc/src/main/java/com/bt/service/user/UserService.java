package com.bt.service.user;

public interface UserService {

}
