package com.bt.service.report.template.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Queue;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.bt.common.QueryForm;
import com.bt.common.QueryFormParameter;
import com.bt.common.QueryHelper;
import com.bt.dao.report.template.ReportTemplateDAO;
import com.bt.dao.report.template.impl.ReportTemplateDAOImpl;
import com.bt.entity.common.TemplateConfiguration;
import com.bt.entity.report.DefaultReport;
import com.bt.entity.report.GlobalReportTemplate;
import com.bt.entity.report.UserReportTemplate;
import com.bt.entity.template.ExpressionDetails;
import com.bt.entity.template.Node;
import com.bt.entity.template.NodeColumn;
import com.bt.service.report.template.ReportTemplateService;
import com.bt.util.ReportHelper;
import com.mongodb.BasicDBObject;

@Service
@Transactional
public class ReportTemplateServiceImpl implements ReportTemplateService {

	@Autowired
	ReportTemplateDAO reportTemplateDAO;

	@ExceptionHandler(Exception.class)
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
	public List<GlobalReportTemplate> fetchAllGlobalTemplate() throws Exception {
		return reportTemplateDAO.fetchAllGlobalTemplate();

	}

	@ExceptionHandler(Exception.class)
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
	public UserReportTemplate fetchUserTemplate(String username) throws Exception {
		return reportTemplateDAO.fetcSingleUserTemplate(username);

	}
	
	/**
	 * This method will insert the user node and supported upto two levels
	 */

	@SuppressWarnings("unused")
	@ExceptionHandler(Exception.class)
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void insertUserTemplate(UserReportTemplate userreporttemplate) throws Exception {
			reportTemplateDAO.updateDocumentArray(userreporttemplate.getNode(),ReportTemplateDAOImpl.formFilterParamter(userreporttemplate),UserReportTemplate.class);
	}


	/**
	 * This method will delete the user node and supported upto two levels
	 */
	@SuppressWarnings("unused")
	@ExceptionHandler(Exception.class)
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public List<GlobalReportTemplate>  deleteGlobalTemplate(GlobalReportTemplate globalreporttemplate) throws Exception {
		reportTemplateDAO.deteleDocumentArray(globalreporttemplate.getNode(), ReportTemplateDAOImpl.formFilterParamterforNodeDeletion(globalreporttemplate),GlobalReportTemplate.class);
		List<GlobalReportTemplate> listOfGlobalReport = reportTemplateDAO.fetchAllGlobalTemplate();
		return listOfGlobalReport;
			
	}
	
	
	@SuppressWarnings("unused")
	@ExceptionHandler(Exception.class)
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public UserReportTemplate deleteUserNode(UserReportTemplate userreporttemplate) throws Exception {
		reportTemplateDAO.deteleDocumentArray(userreporttemplate.getNode(), ReportTemplateDAOImpl.formFilterParamterforNodeDeletion(userreporttemplate),UserReportTemplate.class);
		UserReportTemplate existingNode= reportTemplateDAO.fetcSingleUserTemplate(userreporttemplate.getUsername());
		return existingNode;

	}

	@Override
	@ExceptionHandler(Exception.class)
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void insertUserDefaultTemplate(DefaultReport defaultreport) throws Exception {
		reportTemplateDAO.insertUserDefaultTemplate(defaultreport);
	}

	@Override
	@ExceptionHandler(Exception.class)
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
	public DefaultReport fetchUserDefaultTemplate(String userid) throws Exception {
		return reportTemplateDAO.fetchUserDefaultTemplate(userid);
	}

	
	@SuppressWarnings("unused")
	@ExceptionHandler(Exception.class)
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
	public void insertGlobalTemplate(GlobalReportTemplate globalreporttemplate, List<GlobalReportTemplate> globaltemplates) throws Exception {
		Iterator<GlobalReportTemplate> it=globaltemplates.iterator();
		while(it.hasNext())
		{
			if(globalreporttemplate.getId().equals(it.next().getId()))
			{	
				reportTemplateDAO.updateDocumentArray(globalreporttemplate.getNode(), ReportTemplateDAOImpl.formFilterParamter(globalreporttemplate), GlobalReportTemplate.class);
				break;
			}
		}
		
		
	}
	
	/**
	 * This method use to populate default template properties. 
	 * and {@link DefaultReport} and default report load from 
	 * properties  file.
	 * 
	 * @param userreporttemplate
	 * @param defaultreport
	 */
	private void setDefaultTemplateToParent(UserReportTemplate userreporttemplate, DefaultReport defaultreport) {
		Node node = userreporttemplate.getNode();
		if (null == node.getColumns()) {
			node.setColumns(new ArrayList<NodeColumn>());
		}
		TemplateConfiguration templateconfig = defaultreport.getCommondata();
		if (null != templateconfig) {
			node.setColumns(templateconfig.getNode().getColumns());
			node.setDuration(templateconfig.getNode().getDuration());
			node.setPagesize(templateconfig.getNode().getPagesize());
		}

	}
	
	/**
	 * 
	 */
	@ExceptionHandler(Exception.class)
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void updateUserTemplate(UserReportTemplate userreporttemplate,TemplateConfiguration template) throws Exception {
		List<QueryFormParameter> queryparam = ReportTemplateDAOImpl.formFilterParamterForSelect(userreporttemplate);
		BasicDBObject basicdataobject = QueryForm.formQuery(queryparam);
		UserReportTemplate fetchUserTemplate = reportTemplateDAO.fetchUserReportTemplate(userreporttemplate, basicdataobject);
		if (null != fetchUserTemplate) {
			Queue<Integer> indexlist = null;
			Node inputNode = userreporttemplate.getNode();
			if (null != inputNode) {
				indexlist = QueryHelper.hierarchyIndexListForElement(inputNode.getNodelevel());
			}
			List<Node> fetchnodes = fetchUserTemplate.getNodes();
			if (!fetchnodes.isEmpty()) {
				ReportHelper.expressionBuilder(template, fetchUserTemplate.getFilterExpression());
				while (!indexlist.isEmpty()) {
					findNodeAccordingToPostion(template, indexlist, fetchnodes, inputNode);
				}
			}
		}
			reportTemplateDAO.updateNodes(fetchUserTemplate	, basicdataobject); 
			Map<String, ExpressionDetails> expressionDetails=	ReportHelper.expressionAnalyzer(template);
			template.setExpressionmap(expressionDetails);
	}

	
	
	

	/**
	 * 
	 * @param template
	 * @param indexlist
	 * @param fetchnodes
	 * @param inputNode
	 */
	private void findNodeAccordingToPostion(TemplateConfiguration template, Queue<Integer> indexlist,
			List<Node> fetchnodes, Node inputNode) {
		Node fetchnode = null;
		boolean isUpdate = false;
		if (null != indexlist && !indexlist.isEmpty()) {
			fetchnode = fetchnodes.get(indexlist.remove());
		}
		if (null != fetchnode && !indexlist.isEmpty()) {
			ReportHelper.expressionBuilder(template, fetchnode.getFilterExpression());
			if (fetchnode.getId().equals(inputNode.getId())) {
				updateExistingNode(fetchnode, inputNode, template);
				isUpdate = true;
			}
		}
		if (!isUpdate && null!=fetchnode ) {
			List<Node> childNodes = fetchnode.getNodes();
			if (null != childNodes && !childNodes.isEmpty()) {
				findNodeAccordingToPostion(template, indexlist, childNodes, inputNode);
			}
		}
	}
	
	
	
	/**
	 * 
	 * @param existingNode
	 * @param updateNode
	 * @param template
	 */
	private void  updateExistingNode(Node existingNode , Node updateNode,TemplateConfiguration template){
	
		existingNode.setLabel(updateNode.getLabel());
		existingNode.setDuration(updateNode.getDuration());
		existingNode.setPagesize(updateNode.getPagesize());
		existingNode.setColumns(updateNode.getColumns());
		if (!StringUtils.isEmpty(updateNode.getFilterExpression())) {
			existingNode.setFilterExpression(updateNode.getFilterExpression().trim());
		}
		ReportHelper.expressionBuilder(template, existingNode.getFilterExpression());
	}
	
	
}

