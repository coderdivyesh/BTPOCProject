package com.bt.service.user.impl;

import java.util.List;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.bt.common.QueryForm;
import com.bt.common.QueryFormParameter;
import com.bt.dao.user.UserDAO;
import com.bt.dao.user.impl.UserDAOImpl;
import com.bt.entity.report.ReportData;
import com.bt.security.entity.User;
import com.bt.security.entity.UserVO;
import com.bt.security.helper.TokenHandler;
import com.bt.security.service.UserActive;
import com.bt.service.user.UserService;
import com.mongodb.BasicDBObject;

@Service
@Transactional
public class UserServiceImpl implements UserService{

	
	
	private static final Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);

	@Autowired
	private UserDAO userDAO;
	
	
	@Override
	@ExceptionHandler(Exception.class)
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void insertUser(User newUser) throws Exception {
		userDAO.insertUser(newUser);
	}

	
	@Override
	@ExceptionHandler(Exception.class)
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
	public void updateUser(User updUser) throws Exception {
		
		List<QueryFormParameter> queryparam = UserDAOImpl.formFilterParamter(updUser);
		BasicDBObject basicdataobject = QueryForm.formQuery(queryparam);
		User existuser = userDAO.fetchUserData(updUser, basicdataobject);
		if (null != existuser) {
				String users = existuser.getUsername();
					existuser.setFirstname(updUser.getFirstname());
					existuser.setLastname(updUser.getLastname());
					existuser.setEmail(updUser.getEmail());
			
			userDAO.updateUser(existuser, basicdataobject);
			
		}

	
	}

	@Override
	@ExceptionHandler(Exception.class)
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
	public void loadUser() throws Exception {
		userDAO.loadUser();
	}


	
	
	// for insert token
	@Override
	@ExceptionHandler(Exception.class)
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void insertToken(UserActive useract) throws Exception {
		userDAO.insertToken(useract);
	}

	//for activeusers
	@Override
	@ExceptionHandler(Exception.class)
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
	public List<UserActive> getActiveUsers() throws Exception {
		List<UserActive> activeUserList = new ArrayList<UserActive>();
		List<UserActive> activeUsers= userDAO.getActiveUsers();
		HashMap<String, UserVO> userMap =com.bt.security.service.UserService.getAllUser();
		for(UserActive activeuser:activeUsers){
			
			UserVO user = userMap.get((activeuser.getUsername()));
			activeuser.setEmail(user.getEmail());
			 activeUserList.add(activeuser);
			
		 }
		

		return activeUserList;
	}
	// for kill active users
	@Override
	@ExceptionHandler(Exception.class)
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
	public void killActiveUsers(UserActive uactive) throws Exception{
		String tokenid = uactive.getTokenId();
		String userDbName = TokenHandler.getUsernameFromToken(tokenid);
		HashMap<String, UserVO> userMap =com.bt.security.service.UserService.getAllUser();
		if(userDbName.equals(uactive.getUsername())){
			userDAO.killActiveUsers(uactive);
			userMap.remove(uactive.getUsername());
		}
		logger.error("  active user not killed");
	}
		
}
