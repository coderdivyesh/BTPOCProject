package com.bt.entity.common;

import java.util.Map;

import com.bt.entity.template.ExpressionDetails;
import com.bt.entity.template.Node;

public class TemplateConfiguration {
	
	private Node node;
	private int pagenumber;
	private long totalRecordCount;
	private Map<String,ExpressionDetails> expressionmap;
	private String allfilterexpression;

	
	public String getAllfilterexpression() {
		return allfilterexpression;
	}

	public void setAllfilterexpression(String allfilterexpression) {
		this.allfilterexpression = allfilterexpression;
	}

	public long getTotalRecordCount() {
		return totalRecordCount;
	}
	public void setTotalRecordCount(long totalRecordCount) {
		this.totalRecordCount = totalRecordCount;
	}
	public Node getNode() {
		return node;
	}
	public void setNode(Node node) {
		this.node = node;
	}
	public int getPagenumber() {
		return pagenumber;
	}
	public void setPagenumber(int pagenumber) {
		this.pagenumber = pagenumber;
	}

	public Map<String, ExpressionDetails> getExpressionmap() {
		return expressionmap;
	}

	public void setExpressionmap(Map<String, ExpressionDetails> expressionmap) {
		this.expressionmap = expressionmap;
	}

	@Override
	public String toString() {
		return "TemplateConfiguration [node=" + node + ", pagenumber=" + pagenumber + ", totalRecordCount="
				+ totalRecordCount + ", expressionmap=" + expressionmap + ", allfilterexpression=" + allfilterexpression
				+ "]";
	}


}
