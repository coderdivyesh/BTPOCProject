package com.bt.entity.common;

import java.util.List;
import java.util.Map;
import java.util.Stack;

import javax.validation.constraints.NotNull;

import com.bt.entity.template.ExpressionDetails;
import com.bt.entity.template.NodeColumn;


public class CommonData {
	
	@NotNull
	private Integer pagenumber;
	@NotNull
	private Integer pagesize;
	
	private String templateid;
	
	private long totalrecordCount;
	
	private String configid;
	
	private String duration;
	
	private String aggrType;
	
	private String samplingPeriod;
	
	private String starttime;
	
	private String endtime;
	
	private List<NodeColumn> displayprams;


	public long getTotalrecordCount() {
		return totalrecordCount;
	}

	public void setTotalrecordCount(long totalrecordCount) {
		this.totalrecordCount = totalrecordCount;
	}

	public String getSamplingPeriod() {
		return samplingPeriod;
	}

	public void setSamplingPeriod(String samplingPeriod) {
		this.samplingPeriod = samplingPeriod;
	}
	
	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	public String getAggrType() {
		return aggrType;
	}

	public void setAggrType(String aggrType) {
		this.aggrType = aggrType;
	}

	public String getStarttime() {
		return starttime;
	}

	public void setStarttime(String starttime) {
		this.starttime = starttime;
	}


	public Integer getPagenumber() {
		return pagenumber;
	}

	public void setPagenumber(Integer pagenumber) {
		this.pagenumber = pagenumber;
	}

	public Integer getPagesize() {
		return pagesize;
	}

	public void setPagesize(Integer pagesize) {
		this.pagesize = pagesize;
	}

	public String getTemplateid() {
		return templateid;
	}

	public void setTemplateid(String templateid) {
		this.templateid = templateid;
	}

	public String getConfigid() {
		return configid;
	}

	public void setConfigid(String configid) {
		this.configid = configid;
	}

	public List<NodeColumn> getDisplayprams() {
		return displayprams;
	}

	public void setDisplayprams(List<NodeColumn> displayprams) {
		this.displayprams = displayprams;
	}

	
	public String getEndtime() {
		return endtime;
	}

	public void setEndtime(String endtime) {
		this.endtime = endtime;
	}

	@Override
	public String toString() {
		return "CommonData [pagenumber=" + pagenumber + ", pagesize=" + pagesize + ", templateid=" + templateid
				+ ", totalrecordCount=" + totalrecordCount + ", configid=" + configid + ", duration=" + duration
				+ ", aggrType=" + aggrType + ", samplingPeriod=" + samplingPeriod + ", starttime=" + starttime
				+ ", endtime=" + endtime + ", displayprams=" + displayprams + "]";
	}



}
