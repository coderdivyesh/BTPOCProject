package com.bt.entity.template;

public class ColumnsTemplate {

	private String name;
	private String nodeproperty;
	private String sort;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getNodeproperty() {
		return nodeproperty;
	}

	public void setNodeproperty(String nodeproperty) {
		this.nodeproperty = nodeproperty;
	}

	public String getSort() {
		return sort;
	}

	public void setSort(String sort) {
		this.sort = sort;
	}

}
