package com.bt.entity.report;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;

import com.bt.entity.template.Node;

@Document(collection="globalreport")
public class GlobalReportTemplate {
	private String label;
	//private String globalreportid;
	private String id;
	private String parentid;
	private String filterExpression;
	private Node node;
	private List<Node> nodes=new ArrayList<Node>();

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public String getParentid() {
		return parentid;
	}

	public void setParentid(String parentid) {
		this.parentid = parentid;
	}

	public String getFilterExpression() {
		return filterExpression;
	}

	public void setFilterExpression(String filterExpression) {
		this.filterExpression = filterExpression;
	}

	public List<Node> getNodes() {
		return nodes;
	}

	public void setNodes(List<Node> nodes) {
		this.nodes = nodes;
	}
	

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
	
	
	public Node getNode() {
		return node;
	}

	public void setNode(Node node) {
		this.node = node;
	}

	@Override
	public String toString() {
		return "GlobalReportTemplate [label=" + label + ", id=" + id + ", parentid=" + parentid + ", filterExpression="
				+ filterExpression + ", node=" + node + ", nodes=" + nodes + "]";
	}
	

	/*public String getGlobalreportid() {
		return globalreportid;
	}

	public void setGlobalreportid(String globalreportid) {
		this.globalreportid = globalreportid;
	}*/

	
	

}
