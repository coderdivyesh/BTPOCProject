package com.bt.entity.report;

public class ReportTemplate {
	
	private UserReportTemplate usertemplate;
	
	private AllGlobalTemplate globaltemplate;

	public UserReportTemplate getUsertemplate() {
		return usertemplate;
	}

	public void setUsertemplate(UserReportTemplate usertemplate) {
		this.usertemplate = usertemplate;
	}

	public AllGlobalTemplate getGlobaltemplate() {
		return globaltemplate;
	}

	public void setGlobaltemplate(AllGlobalTemplate globaltemplate) {
		this.globaltemplate = globaltemplate;
	}

	@Override
	public String toString() {
		return "ReportTemplate [usertemplate=" + usertemplate + ", globaltemplate=" + globaltemplate + "]";
	}


	

}
