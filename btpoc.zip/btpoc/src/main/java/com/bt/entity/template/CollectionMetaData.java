package com.bt.entity.template;

import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;


@Document(collection = "CollectionMetaData")
public class CollectionMetaData {

	private  String name;

	private List<NodeColumn> columns;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<NodeColumn> getColumns() {
		return columns;
	}

	public void setColumns(List<NodeColumn> columns) {
		this.columns = columns;
	}

	@Override
	public String toString() {
		return "TableMetaData [name=" + name + ", columns=" + columns + "]";
	}

	
}
