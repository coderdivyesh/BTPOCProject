package com.bt.entity.template;

import com.bt.constant.FilterCondition;

/**
 * 
 * @author 611022163
 *
 */
public class ExpressionDetails {
	

	private String value;
	private String key;
	private FilterCondition innerJoinOpeartion;
	private FilterCondition outerJoinOperation;
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public FilterCondition getInnerJoinOpeartion() {
		return innerJoinOpeartion;
	}
	public void setInnerJoinOpeartion(FilterCondition innerJoinOpeartion) {
		this.innerJoinOpeartion = innerJoinOpeartion;
	}
	public FilterCondition getOuterJoinOperation() {
		return outerJoinOperation;
	}
	public void setOuterJoinOperation(FilterCondition outerJoinOperation) {
		this.outerJoinOperation = outerJoinOperation;
	}
	
	@Override
	public String toString() {
		return "ExpressionDetails [value=" + value + ", key=" + key + ", innerJoinOpeartion=" + innerJoinOpeartion
				+ ", outerJoinOperation=" + outerJoinOperation + "]";
	}
	
	
}
