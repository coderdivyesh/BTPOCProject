package com.bt.entity.template;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;

public class Node {
	
    private String parentid;
	private String id;
	private String label;
	private String filterExpression;
	private int pagesize;
	private String duration;
	private String nodelevel;
	private List<NodeColumn> columns=new ArrayList<NodeColumn>();
	private List<Node> nodes=new ArrayList<Node>();
	
	public int getPagesize() {
		return pagesize;
	}
	public void setPagesize(int pagesize) {
		this.pagesize = pagesize;
	}
	public String getDuration() {
		return duration;
	}
	public void setDuration(String duration) {
		this.duration = duration;
	}
	public String getParentid() {
		return parentid;
	}
	public void setParentid(String parentid) {
		this.parentid = parentid;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getLabel() {
		return label;
	}
	public void setLabel(String label) {
		this.label = label;
	}
	public String getFilterExpression() {
		return filterExpression;
	}
	public void setFilterExpression(String filterExpression) {
		this.filterExpression = filterExpression;
	}
	public List<NodeColumn> getColumns() {
		return columns;
	}
	public void setColumns(List<NodeColumn> columns) {
		this.columns = columns;
	}
	
	public List<Node> getNodes() {
		return nodes;
	}
	public void setNodes(List<Node> nodes) {
		this.nodes = nodes;
	}
	public String getNodelevel() {
		return nodelevel;
	}
	public void setNodelevel(String nodelevel) {
		this.nodelevel = nodelevel;
	}
	@Override
	public String toString() {
		return "Node [parentid=" + parentid + ", id=" + id + ", label=" + label + ", filterExpression="
				+ filterExpression + ", pagesize=" + pagesize + ", duration=" + duration + ", nodelevel=" + nodelevel
				+ ", columns=" + columns + ", nodes=" + nodes + "]";
	}

	
}
