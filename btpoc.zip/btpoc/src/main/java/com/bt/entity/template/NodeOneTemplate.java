package com.bt.entity.template;

public class NodeOneTemplate 
{
	private String label;
	private String id;

	public String getLabel() {
		return label;
	}

	public String setLabel(String label) {
		return this.label = label;
	}

	public String getId() {
		return id;
	}

	public String setId(String id) {
		return this.id = id;
	}

}
