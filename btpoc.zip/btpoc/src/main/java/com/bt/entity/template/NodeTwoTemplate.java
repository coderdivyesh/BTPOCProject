package com.bt.entity.template;

import java.util.List;

public class NodeTwoTemplate 
{
	private long id;

	private String name;

	private String duration;

	private int paging;

	private int order;
	private String filterexpression;

	private List<ColumnsTemplate> columns;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	public int getPaging() {
		return paging;
	}

	public void setPaging(int paging) {
		this.paging = paging;
	}

	public int getOrder() {
		return order;
	}

	public void setOrder(int order) {
		this.order = order;
	}

	public String getFilterexpression() {
		return filterexpression;
	}

	public void setFilterexpression(String filterexpression) {
		this.filterexpression = filterexpression;
	}

	public List<ColumnsTemplate> getColumns() {
		return columns;
	}

	public void setColumns(List<ColumnsTemplate> columns) {
		this.columns = columns;
	}

}
