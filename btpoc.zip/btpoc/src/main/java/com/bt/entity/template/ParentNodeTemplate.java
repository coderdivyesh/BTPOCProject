package com.bt.entity.template;

import java.util.ArrayList;
import java.util.List;

public class ParentNodeTemplate 
{
	private String label;
	private String id;
	private List<NodeOneTemplate> children = new ArrayList<NodeOneTemplate>();

	public String getLabel() {
		return label;
	}

	public String setLabel(String label) {
		return this.label = label;
	}

	public String getId() {
		return id;
	}

	public String setId(String id) {
		return this.id = id;
	}

	public List<NodeOneTemplate> getChildren() {
		return children;
	}

	public void setChildren(List<NodeOneTemplate> children) {
		this.children = children;
	}

}
