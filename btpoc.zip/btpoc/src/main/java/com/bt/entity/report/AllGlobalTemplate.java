package com.bt.entity.report;

import java.util.List;

public class AllGlobalTemplate {
	
private	List<GlobalReportTemplate> globaltemplates;

public List<GlobalReportTemplate> getGlobaltemplates() {
	return globaltemplates;
}

public void setGlobaltemplates(List<GlobalReportTemplate> globaltemplates) {
	this.globaltemplates = globaltemplates;
}

}
