(function() {
	'use strict';

	angular
	.module('reportTool')
	.controller(
			'AdminController',
			[
			 '$scope',
			 '$http',
			 'AdminService',
			 'ManageDivService',
			 function($scope, $http, AdminService,
					 ManageDivService) {

				 $scope.request = {};
				 $scope.updrequest = {};

				 ManageDivService
				 .setDefaultdivValuesForAdminView($scope);

				 $scope.userRoles = [ "READ ONLY", "READ WRITE" ];

				 $scope.UserList = [];
				 $scope.userData = [];
				 $scope.message = '';
				 console.log("$scope.userData "
						 + $scope.userData);

				 $scope.firstname = '';

				 $scope.displayRegisterUserScreen = function() {
					 ManageDivService
					 .setDefaultdivValuesForAdminView($scope);
					 ManageDivService
					 .enableUserRegistrationView(true,
							 $scope);

				 }

				 $scope.createNewUser = function(newUserObj) {
					 console.log(" newUserObj " + newUserObj);

					 $scope.request.username = newUserObj.username;
					 $scope.request.firstname = newUserObj.firstname;
					 $scope.request.lastname = newUserObj.lastname;
					 $scope.request.email = newUserObj.email;
					 $scope.request.password = newUserObj.password;

					 $scope.request.authorities = [ {
						 name : newUserObj.authority
					 } ];

					 console.log(" $scope.request "
							 + $scope.request);

					 AdminService
					 .createNewUser($scope,
							 $scope.request)
							 .success(
									 function(response, status,
											 headers, config) {
										 console
										 .log(" user is created");
										 $scope.message = 'User is Created successfully';
										 ManageDivService
										 .setDefaultdivValuesForAdminView($scope);
										 ManageDivService
										 .enableSuccessMsgViewForAdmin(
												 true,
												 $scope);
									 });

				 }

				 // PMR here

				 $scope.updateUser = function(updateUserObj) {
					 console.log(" updateUserObj "
							 + updateUserObj);
					 $scope.updrequest.username = updateUserObj.userData.username;
					 $scope.updrequest.firstname = updateUserObj.userData.firstname;
					 $scope.updrequest.lastname = updateUserObj.userData.lastname;
					 $scope.updrequest.email = updateUserObj.userData.email;

					 $scope.updrequest.authorities = [ {
						 name : updateUserObj.authority
					 } ];

					 console.log(" $scope.request "
							 + $scope.updrequest);

					 AdminService
					 .updateUser($scope,
							 $scope.updrequest)
							 .success(
									 function(response, status,
											 headers, config) {
										 console
										 .log(" user is updated succesfully");
										 $scope.message = 'User is updated succesfully';
										 ManageDivService
										 .setDefaultdivValuesForAdminView($scope);
										 ManageDivService
										 .enableSuccessMsgViewForAdmin(
												 true,
												 $scope);
									 });

				 }

				 $scope.getUserScreen = function() {

					 ManageDivService
					 .setDefaultdivValuesForAdminView($scope);
					 ManageDivService
					 .enabledisplayUserViewForAdmin(
							 true, $scope);

					 AdminService.showUserList($scope).success(
							 function(data, status) {
								 $scope.UserList = data;
								 console.log(" user List "
										 + data);

							 });

				 }
				 // for all active users @method
				 // getActiveUserScreen()
				 $scope.getActiveUserScreen = function() {

					 ManageDivService
					 .setDefaultdivValuesForAdminView($scope);
					 ManageDivService.displayActiveUserView(
							 true, $scope);
					 AdminService.showActiveUserList($scope)
					 .success(function(data, status) {
						 $scope.ActiveUserList = data;

					 });

				 }
				 // for kill active users

				 $scope.killActiveUser = function(newUserObj) {

					 console.log(" newUserObj " + newUserObj);
					 $scope.request.username = newUserObj.username;
					 $scope.request.tokenId = newUserObj.tokenId;

					 console.log(" $scope.request "
							 + $scope.request);

					 AdminService
					 .killActiveUser($scope.request)
					 .success(
							 function(response, status,
									 headers, config) {
								 console
								 .log(" active user deleted");
								 $scope.message = 'active user deleted';
								 ManageDivService
								 .setDefaultdivValuesForAdminView($scope);

							 });

				 }

				 $scope.displayUserScreen = function(user) {

					 ManageDivService
					 .setDefaultdivValuesForAdminView($scope);
					 ManageDivService
					 .enableExistingUserUpdateView(true,
							 $scope);

					 console.log(" user data " + user);
					 $scope.userData = user;
					 $scope.authorities = $scope.userData.authorities;

					 angular
					 .forEach(
							 $scope.authorities,
							 function(value, key) {
								 $scope.authority = value.authority;
							 });
					 $scope.upduserRoles = [ $scope.authority,
					                         "READ ONLY", "READ WRITE" ];

				 };

			 } ]);
}());