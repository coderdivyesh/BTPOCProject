(function() {
	'use strict';
	angular.module('reportTool').controller(
			'AuthController',
			[
			 '$scope',
			 '$http',
			 '$location',
			 'AuthenticationService',
			 function($scope, $http, $location, AuthenticationService) {

				 console.log("in AuthController ");

				 $scope.loading = true;

				 AuthenticationService.loadDefaultUsers().success(
						 function(response) {
							 console.log("users are loaded");
							 $location.path('/login');

						 });
				 $scope.loading = false;
			 } ]);
}());
