
angular.module('reportTool').controller('ViewReportController',['$scope','$http','ViewReportService','$sce','$location','$state','ManageDivService','AppConstants','$sessionStorage', function($scope, $http ,ViewReportService,$sce,$location,$state,ManageDivService,AppConstants,$sessionStorage)  {


	$scope.filterExpression='';
	$scope.loading = true;
	$scope.error1=false;
	$scope.pagenumber=1;
	$scope.pagetotalsize=100;
	$scope.totalRecordCount='';
	$scope.formats = ["XLS", "CSV","TXT","PDF"];
	$scope.lastid=1;

	$scope.enableDisplayOptions = false;
	$scope.timeIntervals = ["past 15 min" ,"past 30 min", "past 1 day" ,"past 1 week","past 1 month" ,"past 3 month","past 4 month","past 5 month","past 6 month","past 1 year"];
	$scope.durationIntervals = ["past 1 hour", "past 1 day", "past 1 week", "past 1 month", "past quarter", "past half year", "past 1 year"];
	$scope.samplingPeriodIntervals = ["15 min" ,"30 min", "1 hour", "6 hours", "1 day" ,"1 week","1 month", "quarter", "half year"];
	$scope.aggrTypes = ["sum" , "avg", "min", "max", "count"];
	$scope.chartOptions = ["Column Chart" ,"Bar Chart", "Line Chart", "Pie Chart"];
	$scope.operatorList=AppConstants.FilterExpressionEnum;
	$scope.conditionalOperatorList=[{key:'AND',value:'#AND#'},{key:'OR',value:'#OR#'}];
	$scope.input=[];
	$scope.min=0;
	$scope.max=15;
	$scope.duration='4month';
	$scope.samplingPeriod='1day';
	$scope.aggrType='sum';
	$scope.chartType='column';
	$scope.starttime=null;
	$scope.endtime=null;
	$scope.filterObjects=[];
	$scope.showCondition=false;
	$scope.selectedConditionalOp='';
	$scope.columns =[];

	$scope.date = new Date();

	$scope.username='';
	$scope.templtid='';
	$scope.newReportparentId='';
	$scope.newReportid='';
	$scope.content='';
	$scope.pageCountList = [10,20,30,40,50,60,70,80,90,100];
	$scope.newReportName='';
	$scope.newReportPagesize='';
	$scope.request={};

	$scope.defaultpageCount=10;
	$scope.pagesize=10;
	$scope.selectedpageCount=10;

	$scope.totalPagedisplaySize = 10;

	$scope.records=[{id:1}];

	$scope.range=[];

	$scope.totalPagedisplaySize = Math.ceil(100 / $scope.selectedpageCount);

	var matchfound=false;
	var isFolder=false;

	$scope.resultMessage='';
	$scope.displayfilterExpression='';

	

	var range = [];
	for(var i=1;i<=$scope.totalPagedisplaySize;i++) {
		range.push(i);
	}
	$scope.range = range;

	$scope.globadata='';
	$scope.globaltemplatetree='';
	$scope.usertemplatetree ='';
	$scope.globaltreedata = '';


	$scope.request.username=$scope.username;
	$scope.request.id=$scope.templtid;

	$scope.nodelevel='';

	ManageDivService.setDefaultdivValues($scope);

	$scope.request.node=
	{
			duration:$scope.duration,
			id:$scope.newReportid,
			parentid:$scope.newReportparentId,
			columns:$scope.columns

	};

	$scope.temporaryNode = {
			nodes: []
	};

	

	$scope.newReport = {
			tabcolumns:[]

	};

	//graph
	$scope.xParamTableColumns = [
	                             {name:'openedat',label:'OPENEDAT',dbname:'OpenedAt'},
	                             {name:'closedat',label:'CLOSEDAT',dbname:'ClosedAt'},
	                             {name:'updatedat',label:'UPDATEAT',dbname:'UpdatedAt'}
	                             ];
	//graph
	$scope.yParamTableColumns=[
	                           {name:'id',label:'ID',dbname:'_id'},
	                           {name:'name',label:'NAME',dbname:'Name'},
	                           {name:'openedat',label:'OPENEDAT',dbname:'OpenedAt'},
	                           {name:'source',label:'SOURCE',dbname:'Source'},
	                           {name:'classname',label:'CLASSNAME',dbname:'ClassName'},
	                           {name:'instancename',label:'INSTANCE_NAME',dbname:'InstanceName'},
	                           {name:'eventname',label:'EVENT_NAME',dbname:'Eventname'},
	                           {name:'classdisplayname',label:'CLASS_DISPLAY_NAME',dbname:'ClassDisplayName'},
	                           {name:'instancedisplayname',label:'INSTANCE_DISPLAY_NAME',dbname:'InstanceDisplayName'},
	                           {name:'eventdisplayname',label:'EVENT_DISPLAY_NAME',dbname:'EventDisplayName'},
	                           {name:'elementclassname',label:'ELEMENT_CLASS_NAME',dbname:'ElementClassName'},
	                           {name:'elementname',label:'ELEMENT_NAME',dbname:'ElementName'},
	                           {name:'sourcedomainname',label:'SOURCE_DOMAINNAME',dbname:'SourcedomainName'},
	                           {name:'sourceeventtype',label:'SOURCE_EVENTTYPE',dbname:'SourceEventtype'},
	                           {name:'active',label:'ACTIVE',dbname:'Active'},
	                           {name:'closedat',label:'CLOSEDAT',dbname:'ClosedAt'},
	                           {name:'duration',label:'DURATION',dbname:'Duration'},
	                           {name:'lastchangedat',label:'LAST_CHANEDDATE',dbname:'LastChangedAt'},
	                           {name:'isroot',label:'ISROOT',dbname:'isRoot'},
	                           {name:'isproblem',label:'ISPROBLEM',dbname:'IsProblem'},
	                           {name:'eventtype',label:'EVENTTYPE',dbname:'EventType'},
	                           {name:'category',label:'CATEGORY',dbname:'Category'},
	                           {name:'severity',label:'SEVERITY',dbname:'Severity'},
	                           {name:'impact',label:'IMPACT',dbname:'Impact'},
	                           {name:'certainty',label:'CERTAINITY',dbname:'Certainty'},
	                           {name:'inMaintenance',label:'INMAINTATINANCE',dbname:'InMaintenance'},
	                           {name:'troubleticketiD',label:'TROUBLE_TICKETID',dbname:'TroubleTicketID'},
	                           {name:'owner',label:'OWNER',dbname:'Owner'},
	                           {name:'updatedat',label:'UPDATEAT',dbname:'UpdatedAt'},
	                           {name:'userdefined1',label:'USERDEFINED1',dbname:'UserDefined1'},
	                           {name:'userdefined2',label:'USERDEFINED2',dbname:'UserDefined2'},
	                           {name:'userdefined3',label:'USERDEFINED3',dbname:'UserDefined3'},
	                           {name:'userdefined4',label:'USERDEFINED4',dbname:'UserDefined4'},
	                           {name:'userdefined5',label:'USERDEFINED5',dbname:'UserDefined5'},
	                           {name:'userdefined6',label:'USERDEFINED6',dbname:'UserDefined6'},
	                           {name:'userdefined7',label:'USERDEFINED7',dbname:'UserDefined7'},
	                           {name:'userdefined8',label:'USERDEFINED8',dbname:'UserDefined8'},
	                           {name:'userdefined9',label:'USERDEFINED9',dbname:'UserDefined9'},
	                           {name:'userdefined10',label:'USERDEFINED10',dbname:'UserDefined10'},
	                           {name:'userdefined11',label:'USERDEFINED11',dbname:'UserDefined11'},
	                           {name:'userdefined12',label:'USERDEFINED12',dbname:'UserDefined12'},
	                           {name:'userdefined13',label:'USERDEFINED13',dbname:'UserDefined13'},
	                           {name:'userdefined14',label:'USERDEFINED14',dbname:'UserDefined14'},
	                           {name:'userdefined15',label:'USERDEFINED15',dbname:'UserDefined15'},
	                           {name:'userdefined16',label:'USERDEFINED16',dbname:'UserDefined16'},
	                           {name:'userdefined17',label:'USERDEFINED17',dbname:'UserDefined17'},
	                           {name:'userdefined18',label:'USERDEFINED18',dbname:'UserDefined18'},
	                           {name:'userdefined19',label:'USERDEFINED19',dbname:'UserDefined19'},
	                           {name:'userdefined20',label:'USERDEFINED20',dbname:'UserDefined20'}
	                           ];


	$scope.tableColumns1=[
	                      {name:'id',label:'ID',dbname:'_id'},
	                      {name:'name',label:'NAME',dbname:'Name'},
	                      {name:'openedat',label:'OPENEDAT',dbname:'OpenedAt'},
	                      {name:'source',label:'SOURCE',dbname:'Source'},
	                      {name:'classname',label:'CLASSNAME',dbname:'ClassName'},
	                      {name:'instancename',label:'INSTANCE_NAME',dbname:'InstanceName'},
	                      {name:'eventname',label:'EVENT_NAME',dbname:'Eventname'},
	                      {name:'classdisplayname',label:'CLASS_DISPLAY_NAME',dbname:'ClassDisplayName'},
	                      {name:'instancedisplayname',label:'INSTANCE_DISPLAY_NAME',dbname:'InstanceDisplayName'},
	                      {name:'eventdisplayname',label:'EVENT_DISPLAY_NAME',dbname:'EventDisplayName'},
	                      {name:'elementclassname',label:'ELEMENT_CLASS_NAME',dbname:'ElementClassName'},
	                      {name:'elementname',label:'ELEMENT_NAME',dbname:'ElementName'},
	                      {name:'sourcedomainname',label:'SOURCE_DOMAINNAME',dbname:'SourcedomainName'},
	                      {name:'sourceeventtype',label:'SOURCE_EVENTTYPE',dbname:'SourceEventtype'},
	                      {name:'active',label:'ACTIVE',dbname:'Active'},
	                      {name:'closedat',label:'CLOSEDAT',dbname:'ClosedAt'},
	                      {name:'lastchangedat',label:'LAST_CHANEDDATE',dbname:''},
	                      {name:'isroot',label:'ISROOT',dbname:''},
	                      {name:'isproblem',label:'ISPROBLEM',dbname:''},
	                      {name:'eventtype',label:'EVENTTYPE',dbname:''},
	                      {name:'severity',label:'SEVERITY',dbname:''},
	                      {name:'impact',label:'IMPACT',dbname:''},
	                      {name:'certainty',label:'CERTAINITY',dbname:'Certainty'},
	                      {name:'inMaintenance',label:'INMAINTATINANCE',dbname:''},
	                      {name:'troubleticketiD',label:'TROUBLE_TICKETID',dbname:''},
	                      {name:'owner',label:'OWNER',dbname:''},
	                      {name:'updatedat',label:'UPDATEAT',dbname:''},
	                      {name:'userdefined1',label:'USERDEFINED1',dbname:''},
	                      {name:'userdefined2',label:'USERDEFINED2',dbname:''},
	                      {name:'userdefined3',label:'USERDEFINED3',dbname:''},
	                      {name:'userdefined4',label:'USERDEFINED4',dbname:''},
	                      {name:'userdefined5',label:'USERDEFINED5',dbname:''},
	                      {name:'userdefined6',label:'USERDEFINED6',dbname:''},
	                      {name:'userdefined7',label:'USERDEFINED7',dbname:''},
	                      {name:'userdefined8',label:'USERDEFINED8',dbname:''},
	                      {name:'userdefined9',label:'USERDEFINED9',dbname:''},
	                      {name:'userdefined10',label:'USERDEFINED10',dbname:''},
	                      {name:'userdefined11',label:'USERDEFINED11',dbname:''},
	                      {name:'userdefined12',label:'USERDEFINED12',dbname:''},
	                      {name:'userdefined13',label:'USERDEFINED13',dbname:''},
	                      {name:'userdefined14',label:'USERDEFINED14',dbname:''},
	                      {name:'userdefined15',label:'USERDEFINED15',dbname:''},
	                      {name:'userdefined16',label:'USERDEFINED16',dbname:''},
	                      {name:'userdefined17',label:'USERDEFINED17',dbname:''},
	                      {name:'userdefined18',label:'USERDEFINED18',dbname:''},
	                      {name:'userdefined19',label:'USERDEFINED19',dbname:''},
	                      {name:'userdefined20',label:'USERDEFINED20',dbname:''}
	                      ];


	$scope.$watch( 'global.currentNode', function( newObj, oldObj ) {
		if( $scope.global && angular.isObject($scope.global.currentNode) ) {
			console.log( 'Node Selected!!' );
			console.log( $scope.global.currentNode );
			ManageDivService.enableReportAddOptions(true,$scope);
			$scope.temporaryNode.selected=undefined;
			$scope.newReportid=$scope.global.currentNode.id;
			$scope.newReportparentId=$scope.global.currentNode.parentid;
			$scope.columns=$scope.global.currentNode.columns;
			$scope.global.currentNode.selected='selected';
			$scope.nodelevel= $scope.global.currentNode.nodelevel;
			if($scope.callShowReport == true)
				$scope.showReport();
		}

		
	}
	, false);

	$scope.$watch('selection', function(newVal, oldVal){
		switch(newVal){
		case 'XLS':
		{
			ViewReportService.loadXLSData($scope.request).success(function(data, status) {
				var xlsinput = new Blob([data]); 
				window.navigator.msSaveOrOpenBlob(xlsinput, 'report.xlsx'); 
			});
		};
		break;
		case 'CSV':
		{
			ViewReportService.loadCSVData($scope.request).success(function(data, status) {
				var csvinput = new Blob([data]); 
				window.navigator.msSaveOrOpenBlob(csvinput, 'report.csv'); 
			});
		};
		break;
		case 'PDF':
		{
			ViewReportService.loadPDFData($scope.request).success(function(data, status) {
				var file = new Blob([data]);
				window.navigator.msSaveOrOpenBlob(file, 'report.pdf');        

			});
		};
		break;
		default:
			break;
		}
	});

	$scope.loadtreedata= function() {
		ViewReportService.getTreeData($scope).success(function(data, status) {
			$scope.loading = true;
			if(data == "")
			{
				console.log("The request failed with no response  and status code " + status);
				$scope.loading = false;
				$scope.error1 = "Invalid Session !! Please Login Again !!";

			}
			$scope.globaltreedata = data.globaltemplate.globaltemplates;
			$scope.setTreeData(data.globaltemplate.globaltemplates,data.usertemplate);
			$scope.loading = false;
			console.log(" $scope.globaltreedata.length " +$scope.globaltreedata.length);
			for(var i= 0 ;i<$scope.globaltreedata.length;i++)
			{ 
				if($scope.globaltreedata[i].node != null)
					$scope.globaltreedata[i].node.nodelevel=i+1;
				$scope.setNodeLevel($scope.globaltreedata[i].nodes,i+1);
			}
		}).error(function(response, status) {  
			console.log("The request failed with response " + response + " and status code " + status);
			$scope.loading = false;

		});

	};

	$scope.setTreeData = function(globaltemplates ,usertemplate){
		$scope.usertemplatetree=usertemplate;
		$scope.globadata=globaltemplates;
		$scope.globaltreedata= $scope.globadata.concat($scope.usertemplatetree);
		$scope.username=usertemplate.username;
		$scope.templtid=usertemplate.id;
	}

	$scope.done = function () {
		/* reset */
		$scope.global.currentNode.selected = undefined;
		$scope.global.currentNode = undefined;
		$scope.mode = undefined;

	};

	$scope.addChildDone = function () {
		/* add child */
		$scope.temporaryNode.id= ViewReportService.genrateUniqueId();
		$scope.temporaryNode.label = "New Report";
		$scope.temporaryNode.parentid=$scope.global.currentNode.id;
 
		if( $scope.temporaryNode.id && $scope.temporaryNode.label ) {
			if( $scope.global.currentNode.nodes == null)
			{
				$scope.global.currentNode.nodes=[];
				
			
			}
			$scope.global.currentNode.nodes.push( angular.copy($scope.temporaryNode) );

		}
		$scope.newReportparentId=$scope.temporaryNode.parentid
		$scope.newReportid=$scope.temporaryNode.id;
		$scope.nodelevel = $scope.global.currentNode.nodelevel;
		$scope.request.username=$scope.username;
		$scope.request.id=$scope.templtid;
		$scope.newReportName="New Report";


		if($scope.global.currentNode.nodelevel == null || $scope.global.currentNode.nodelevel=='')
			$scope.nodelevel = $scope.global.currentNode.node.nodelevel;
		var request = $scope.constructRequestObj($scope);
		
		//if role is admin then report will be inserted as gobal template in db
		if($sessionStorage.role == AppConstants.RoleEnum['admin'])
		{
			request.username='';
			request.id='';
			ViewReportService.insertGlobalTemplate(request).success(function(data, status) {
				console.log("New Report Template is inserted successfully");
				$scope.request.node='';
				$scope.getNewReportScreen(data);
			});
		}
		
		else{
		ViewReportService.insertNewReportTemplate(request).success(function(data, status) {
			console.log("New Report Template is inserted successfully");
			$scope.request.node='';
			$scope.getNewReportScreen(data);
		});
		}
		$scope.done();

		//highlight newly added report node
		for(var i= 0 ;i<$scope.globaltreedata.length;i++)
		{ 
			$scope.recursiveSearch($scope.globaltreedata[i].nodes,'id',$scope.newReportid,i+1,'selected','');
		}
		/* reset */
		$scope.temporaryNode.id = "";
		$scope.temporaryNode.label = "";
	};

	$scope.showReport = function()
	{
		ManageDivService.setDefaultdivValues($scope);
		ManageDivService.enableShowReportView(true,$scope);

		$scope.request.pagenumber=$scope.pagenumber;
		$scope.request.node={pagesize:$scope.selectedpageCount,duration:$scope.duration,id:$scope.newReportid ,parentid:$scope.newReportparentId ,columns:$scope.columns};

		ViewReportService.showReport($scope).success(function(data, status) {
			$scope.records = data.reportdatalist;
			$scope.tableColumns = data.commondata.displayprams;
			$scope.newReport.tabcolumns=data.commondata.displayprams;
			$scope.totalRecordCount=data.commondata.totalrecordCount;
		});
	};

	$scope.nextPage = function() {
		if ($scope.pagenumber < $scope.pagetotalsize) {
			$scope.disableNext =false;
			$scope.disablePrevious = false;
			$scope.pagenumber++;
			$scope.displayNewReportTab=false;
			$scope.displayGraph=false;
			if($scope.pagenumber > $scope.range.length)
			{
				$scope.range.push($scope.pagenumber);
			}
			ViewReportService.showReport($scope).success(function(data, status) {
				$scope.records = data.reportdatalist;
				$scope.tableColumns = data.commondata.displayprams;
				$scope.newReport.tabcolumns=data.commondata.displayprams;
			});
		}
		else
			$scope.disableNext =true;
	};

	$scope.previousPage = function() {
		if ($scope.pagenumber > 1) {
			$scope.disableNext =false;
			$scope.disablePrevious = false;
			$scope.pagenumber--;
			$scope.displayNewReportTab=false;
			$scope.displayGraph=false;

			ViewReportService.showReport($scope).success(function(data, status) {
				$scope.records = data.reportdatalist;
				$scope.tableColumns = data.commondata.displayprams;
				$scope.newReport.tabcolumns=data.commondata.displayprams;
			});
		}else
			$scope.disablePrevious = true;
	};

	$scope.$watch('selectedpageCount', function(){
		$scope.defaultpageCount =$scope.selectedpageCount;
		$scope.pagesize=$scope.selectedpageCount;
	});

	$scope.exportData = function () {
		alasql('SELECT * INTO CSV("records.csv",{headers:true}) FROM ?',[$scope.records]);
	};

	$scope.displayOptions = function(){
		ManageDivService.setDefaultdivValues($scope);
		ManageDivService.enableShowReportView(true,$scope);
		ManageDivService.enabledisplayOptionView(true,$scope);
	}

	$scope.$watch('timeIntervalselection', function(newVal, oldVal){
		switch(newVal){
		case 'past 15 min':
		{
			$scope.duration="15minutes";
		};
		break;
		case 'past 30 min':
		{
			$scope.duration="30minutes";
		};
		break;
		case 'past 1 day':
		{
			$scope.duration="1day";
		};
		break;
		case 'past 1 week':
		{
			$scope.duration="1week";
		};
		break;
		case 'past 1 month':
		{
			$scope.duration="1month";
		};
		break;
		case 'past 4 month':
		{
			$scope.duration="4month";
		};
		break;
		case 'past 5 month':
		{
			$scope.duration="5month";
		};
		break;
		case 'past 6 month':
		{
			$scope.duration="6month";
		};
		break;
		case 'past 1 year':
		{
			$scope.duration="1year";
		};
		break;
		default:
			return;
		}
		ViewReportService.showReport($scope).success(function(data, status) {
			$scope.records = data.reportdatalist;
			$scope.tableColumns = data.commondata.filterParameter;
			$scope.newReport.tabcolumns=data.commondata.displayprams;
		});
	});

	$scope.$watch('graphDurationIntervalSelection', function(newVal, oldVal){
		switch(newVal){
		case 'past 1 hour':
		{
			$scope.duration="1hour";
		};
		break;
		case 'past 1 day':
		{
			$scope.duration="1day";
		};
		break;
		case 'past 1 week':
		{
			$scope.duration="1week";
		};
		break;
		case 'past 1 month':
		{
			$scope.duration="1month";
		};
		break;
		case 'past quarter':
		{
			$scope.duration="3month";
		};
		break;
		case 'past half year':
		{
			$scope.duration="6month";
		};
		break;
		case 'past 1 year':
		{
			$scope.duration="1year";
		};
		break;
		default:
			break;
		}
	});

	$scope.$watch('graphSamplingPeriodSelection', function(newVal, oldVal){
		switch(newVal){
		case '15 min':
		{
			$scope.samplingPeriod="15minutes";
		};
		break;
		case '30 min':
		{
			$scope.samplingPeriod="30minutes";
		};
		break;
		case '1 hour':
		{
			$scope.samplingPeriod="1hour";
		};
		break;
		case '6 hours':
		{
			$scope.samplingPeriod="6hours";
		};
		break;
		case '1 day':
		{
			$scope.samplingPeriod="1day";
		};
		break;
		case '1 week':
		{
			$scope.samplingPeriod="1week";
		};
		break;
		case '1 month':
		{
			$scope.samplingPeriod="1month";
		};
		break;
		case 'quarter':
		{
			$scope.samplingPeriod="3month";
		};
		break;
		case 'half year':
		{
			$scope.samplingPeriod="6month";
		};
		break;
		default:
			break;
		}

	});

	$scope.$watch('graphAggregationTypeSelection', function(newVal, oldVal){
		switch(newVal){
		case 'sum':
		{
			$scope.aggrType="sum";
		};
		break;
		case 'avg':
		{
			$scope.aggrType="avg";
		};
		break;
		case 'min':
		{
			$scope.aggrType="min";
		};
		break;
		case 'max':
		{
			$scope.aggrType="max";
		};
		break;
		case 'count':
		{
			$scope.aggrType="count";
		};
		break;
		default:
			break;
		}
	});

	$scope.$watch('graphChartTypeSelection', function(newVal, oldVal){
		switch(newVal){
		case 'Column Chart':
		{
			$scope.chartType="column";
		};
		break;
		case 'Bar Chart':
		{
			$scope.chartType="bar";
		};
		break;
		case 'Line Chart':
		{
			$scope.chartType="line";
		};
		break;
		case 'Pie Chart':
		{
			$scope.chartType="pie";
		};
		break;
		default:
			break;
		}
	});


	$scope.getReportbyPage= function(pagNo)
	{
		$scope.pagenumber = pagNo;
		$scope.showReport();
	};

	$scope.activePageClass = function (page) {
		if(page == $scope.pagenumber)
		{
			return 'active';
		}
	};

	$scope.getNewReportScreen = function(data)
	{
		$scope.newReport.tabcolumns=data.node.columns;
		$scope.newReportTimeInterval=data.node.duration;
		$scope.newReportPagesize=data.node.pagesize;
		if(data.node.filterExpression == null)
		   $scope.filterExpression ='';
		else
		$scope.filterExpression=data.node.filterExpression;
		
		$scope.displayfilterExpression =$scope.filterExpression;
		
		
		ManageDivService.setDefaultdivValues($scope);
		ManageDivService.enableNewReportView(true,$scope);
	};

	$scope.saveNewReport = function(){

		$scope.request.username=$scope.username;
		$scope.request.id=$scope.templtid;

		switch($scope.newReportTimeInterval){
		case 'past 15 min':
		{
			$scope.newReportTimeInterval="15minutes";
		};
		break;
		case 'past 30 min':
		{
			$scope.newReportTimeInterval="30minutes";
		};
		break;
		case 'past 1 day':
		{
			$scope.newReportTimeInterval="1day";
		};
		break;r
		case 'past 1 week':
		{
			$scope.newReportTimeInterval="1week";
		};
		break;
		case 'past 1 month':
		{
			$scope.newReportTimeInterval="1month";
		};
		break;
		case 'past 3 month':
		{
			$scope.newReportTimeInterval="3month";
		};
		break;
		case 'past 4 month':
		{
			$scope.newReportTimeInterval="4month";
		};
		break;
		case 'past 5 month':
		{
			$scope.newReportTimeInterval="5month";
		};
		break;
		case 'past 6 month':
		{
			$scope.newReportTimeInterval="6month";
		};
		break;
		case 'past 1 year':
		{
			$scope.newReportTimeInterval="1year";
		};
		break;
		default:
			break;
		}


		$scope.request.node=
		{
				parentid:$scope.newReportparentId, 
				id:$scope.newReportid,
				label:$scope.newReportName,
				columns:$scope.newReport.tabcolumns,
				label:$scope.newReportName,
				pagesize:$scope.newReportPagesize,
				duration:$scope.newReportTimeInterval,
				filterExpression:$scope.filterExpression,
				nodelevel:$scope.nodelevel


		};

		//update new report Name on UI
		for(var i= 0 ;i<$scope.globaltreedata.length;i++)
		{
			var depth=i+1;
			$scope.recursiveSearch($scope.globaltreedata[i].nodes,'id',$scope.newReportid,depth,'label',$scope.newReportName);
		}	

		//if role is admin then report will be save as gobal template in db
		if($sessionStorage.role == AppConstants.RoleEnum['admin'])
			{
			
			}
		
		else{
		ViewReportService.saveNewReport($scope.request).success(function(data, status) {


			ManageDivService.setDefaultdivValues($scope);
			ManageDivService.enableShowReportView(true,$scope);


			$scope.selectedpageCount=$scope.newReportPagesize;
			$scope.duration=$scope.newReportTimeInterval;

			$scope.records = data.reportdatalist;
			$scope.tableColumns = data.commondata.displayprams;
			$scope.newReport.tabcolumns=data.commondata.displayprams;


			console.log("data :- "+data);

		});
		$scope.selectedConditionalOp='';
		$scope.selectedColumn='';
		$scope.selectedOp='';
		$scope.FilterValue='';
		
		}

	};


	$scope.savefilterExpression = function(){
		$scope.showCondition=true;
		$scope.displayfilterExpression= $scope.displayfilterExpression+"    "+$scope.selectedConditionalOp.key+"  "+$scope.selectedColumn+"  "  +$scope.selectedOp+ " " +$scope.FilterValue;
		
		$scope.filterExpression=$scope.filterExpression+($scope.filterExpression== ''?'':$scope.selectedConditionalOp.value)+$scope.selectedColumn+$scope.selectedOp+$scope.FilterValue;
	
		console.log("$scope.filterExpression  "+$scope.filterExpression);
	}

	$scope.clearfilterExpression= function(){
		$scope.filterExpression='';
		$scope.displayfilterExpression='';
		$scope.selectedConditionalOp=$scope.conditionalOperatorList[1];
		$scope.showCondition=false;
	}


	$scope.constructRequestObj = function (mainObject)
	{
		mainObject.request.username=$scope.username;
		mainObject.request.id=$scope.templtid;

		mainObject.request.node=
		{
				pagesize:$scope.selectedpageCount,
				duration:$scope.duration,
				id:$scope.newReportid,
				parentid:$scope.newReportparentId,
				columns:$scope.columns,
				nodelevel:$scope.nodelevel,
				label:$scope.newReportName

		};
		return mainObject.request;
	}

	$scope.deleteReporttemplate = function()
	{

		ManageDivService.setDefaultdivValues($scope);
		var request = $scope.constructRequestObj($scope);
		var success = false;
        var parentid = $scope.global.currentNode.parentid;
        var currentNodelevel = $scope.global.currentNode.nodelevel;
        
        if($sessionStorage.role == AppConstants.RoleEnum['admin'])
        	
        	{
        	request.username='';
			request.id='';
        	 ViewReportService.deleteglobalTemplate(request).success(function(data, status){
        		 
        	 });
        	}

        else{
        ViewReportService.deleteReportTemplate(request).success(function(data, status) {
			console.log(" data   "+data);
			if(status == 200)
			{
				var usertemplatetree=data;

				var globaltreedata1= $scope.globadata.concat(data);
				$scope.username=data.username;
				$scope.templtid=data.id;
				for(var i= 0 ;i<globaltreedata1.length;i++)
				{ 
					if(globaltreedata1[i].node != null)
					{
						globaltreedata1[i].node.nodelevel=i+1;
					}
					if(data.label ==globaltreedata1[i].label )
					{
						globaltreedata1[i].collapsed =!globaltreedata1[i].collapsed;
					}
					if(globaltreedata1[i].id == parentid)
					{
						globaltreedata1[i].selected='selected';
					}
					else
					{	$scope.recursiveSearch(globaltreedata1[i].nodes,'id',parentid,i+1,'deleted','');}
				}
				$scope.globaltreedata =globaltreedata1;
			}
		});
        
        }
 
 	
	} 

	$scope.showGraph = function()
	{
		ManageDivService.setDefaultdivValues($scope);
		ManageDivService.enableGraphView(true,$scope);	
	};	 
	$scope.drawGraph = function()
	{
		ManageDivService.setDefaultdivValues($scope);
		ManageDivService.enableGraphView(true,$scope);	

		$scope.xCoordinate=$scope.xValue;
		$scope.yCoordinate=$scope.yValue;

		ViewReportService.drawGraph($scope).success(function(data, status, jqxhr) {
			alert("graph");
			var processed_json = new Array();
			var a;
			var b;

           data.sort(sortByProperty($scope.xCoordinate));			
           $.each(data, function() {
				var str = "";
				$.each(this, function(key, val){
					if(str.length==0) {
						str=str.concat(val);
						a=val;
					} else {
						str=str.concat(", ",val);
						b=val;
					}  
				});
				processed_json.push([a*1000, b]);
			});

			/*$.map(data, function(obj, i) {
					     processed_json.push([obj.OpenedAt, obj.ClosedAt]);
					 });*/

			var chart = new Highcharts.Chart({
				colors: ["#7cb5ec", "#f7a35c"],
				chart: {
					type: $scope.chartType,
					//type: 'bar',
					zoomType: 'xy',
					renderTo: 'viz'
				},
				title: {
					text: capitalizeFirstLetter($scope.chartType) + (" Chart")
				},
				xAxis: {
					type : 'datetime',
					title: {
						text: $scope.xCoordinate
					}
				},
				yAxis: {
					title: {
						text: $scope.yCoordinate
					}
				},
				series: [{
					data: processed_json
					//data: data
				}]
			});		 
		});
	};	 

	function capitalizeFirstLetter(string) {
		return string.charAt(0).toUpperCase() + string.slice(1);
	}
	/**
	 * Generic array sorting
	 *
	 * @param property
	 * @returns {Function}
	 */
	var sortByProperty = function (property) {
	    return function (x, y) {
	        return ((x[property] === y[property]) ? 0 : ((x[property] > y[property]) ? 1 : -1));
	    };
	};
	
	$scope.recursiveSearch = function(nodes,attrbuteName,attributeValue,depth,updateProperty,updatedpropValue)
	{
		var childrenNode = nodes;
		childrenNode.nodelevel=depth;
       
		if(childrenNode[attrbuteName] != null && childrenNode[attrbuteName]!='')
		{
			if(childrenNode[attrbuteName] == attributeValue)
			{
				console.log("got ids match" +childrenNode);
				if(updateProperty == 'selected')
				{
					$scope.global.currentNode=childrenNode;
					$scope.global.currentNode.selected='selected';
					console.log("childrenNode.collapsed "+childrenNode.collapsed);
					$scope.global.currentNode.collapsed = !$scope.global.currentNode.collapsed;
					$scope.callShowReport=false;
				}

				if(updateProperty == 'deleted')
				{
			
					childrenNode.selected='selected';
					$scope.global.currentNode=childrenNode;
					$scope.global.currentNode.selected = 'selected';
					console.log("$scope.global.currentNode.collapsed  "+$scope.global.currentNode.collapsed);
					/*if($scope.global.currentNode.collapsed)*/
						$scope.global.currentNode.collapsed = !$scope.global.currentNode.collapsed;
					matchfound = true;
					
				}
				if(updateProperty!=null && updateProperty!='')
				{
					childrenNode[updateProperty] = updatedpropValue;
					childrenNode.columns=$scope.newReport.tabcolumns;
					childrenNode.pagesize=$scope.newReportPagesize;
					childrenNode.duration=$scope.newReportTimeInterval;
					childrenNode.filterExpression=$scope.filterExpression;  
					return;
				}
				
				return childrenNode;
			}
			if(updateProperty == 'deleted')
				{
			     if(matchfound == false)
			     {  childrenNode.collapsed=!childrenNode.collapsed;}
					
				}

		}
		var temp;
		if (childrenNode!=null && childrenNode.length>0)
		{
			for (var i = 0; i < childrenNode.length; i++) {  
				if(i>0)
				{
					if(childrenNode[i].parentid == childrenNode[i-1].parentid)
					{
						depth=depth.substring(0,depth.lastIndexOf('.')) ;
						depth=depth+'.'+(i+1);
					}
					else
						depth=depth+'.'+(i+1);
				}
				else
					depth=depth+'.'+(i+1);
				console.log( "Children__"  +childrenNode[i].label   +  "    "+ "" +" "   +  depth);

				temp =  $scope.recursiveSearch( childrenNode[i] ,attrbuteName, attributeValue,depth,updateProperty,updatedpropValue);
				if(childrenNode[i].nodes!=null)
				{
					temp =  $scope.recursiveSearch( childrenNode[i].nodes ,attrbuteName, attributeValue,depth,updateProperty,updatedpropValue);
				}            

			}
		}
	}



	$scope.setNodeLevel = function (nodes, depth)
	{
		var childrenNode = nodes;
		childrenNode.nodelevel=depth;

		if (childrenNode!=null && childrenNode.length>0){

			for (var i = 0; i < childrenNode.length; i++) {  
				if(i>0)
				{
					if(childrenNode[i].parentid == childrenNode[i-1].parentid)
					{
						depth=depth.substring(0,depth.lastIndexOf('.')) ;
						depth=depth+'.'+(i+1);
					}
					else
						depth=depth+'.'+(i+1);
				}
				else
					depth=depth+'.'+(i+1);

				console.log( "  set nodelevel   : children"  +childrenNode[i].label   +  "    "+ "" +" "   +  depth);

				$scope.setNodeLevel( childrenNode[i],depth);
				if(childrenNode[i].nodes!=null)
				{
					$scope.setNodeLevel( childrenNode[i].nodes,depth);
				}            

			}
		}
	}

	$scope.editReporttemplate = function()
	{
		var data={
				node:$scope.global.currentNode
		} 
		console.log(" data " + data);
		console.log(" data.node " + data.node);
		$scope.newReportName=$scope.global.currentNode.label;
		$scope.getNewReportScreen(data);
	}

}]);

