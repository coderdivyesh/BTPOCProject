'use strict';
 
angular.module('reportTool').controller('LoginController',['$scope','$http', '$rootScope', '$location', 'AuthenticationService','ViewReportService',function ($scope, $http, $rootScope, $location, AuthenticationService,ViewReportService) {
        // reset login status
       /* AuthenticationService.ClearCredentials();*/
	
	$scope.hostName='';
	$scope.hostPort='';
	$scope.applicationName='';
	$scope.nextPageURL='';
	$scope.previousPageURL='';
	$scope.showReportURL='';
	$scope.downloadCSVURL='';
	$scope.downloadPDFURL='';
	$scope.downloadXLSURL='';
	
	$http.get('HostConfig.properties').then(function (response) {
		$scope.hostName=response.data.hostName;
		$scope.hostPort=response.data.hostPort;
		$scope.applicationName=response.data.applicationName;
		$scope.showReportURL=response.data.showReportURL;
		$scope.downloadCSVURL=response.data.downloadCSVURL;
		$scope.downloadPDFURL=response.data.downloadPDFURL;
		$scope.downloadXLSURL=response.data.downloadXLSURL;
		
	});

	
        $scope.login = function () {
        	
            $scope.dataLoading = true;
            
       
            AuthenticationService.Login($scope).success(function(response){
            
            	if(response.token != '')
               {
            		AuthenticationService.setAuthenticationToken(response.token)
            	 $location.path('/report');
               }
               
            })
        };
    }]);