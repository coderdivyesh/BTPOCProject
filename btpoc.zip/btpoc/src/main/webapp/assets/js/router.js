(function () {
   
    angular.module('reportTool').config(function ($stateProvider, $urlRouterProvider) {
    
        // setting up the states
        
        $urlRouterProvider.otherwise("/");
  
        $stateProvider
                .state('report', {
                    url: "/report",
                    templateUrl:"assets/js/views/report/ViewReport.html",
                    controller:'ViewReportController'
                }),
                
                
             $stateProvider
                .state('login', {
                    url: "/",
                    templateUrl:"login.html",
                    controller:'LoginController'
                })
    });
})();