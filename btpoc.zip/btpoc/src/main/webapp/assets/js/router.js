(function () {
   
    angular.module('reportTool').config(function ($stateProvider, $urlRouterProvider) {
    
        // setting up the states
        
        $urlRouterProvider.otherwise("/");
  
        $stateProvider
                .state('report', {
                    url: "/report",
                    templateUrl:"assets/js/views/report/ViewReport.html",
                    controller:'ViewReportController'
                }),
                
                
                $stateProvider
                .state('graph', {
                    url: "/graph",
                    templateUrl:"assets/js/views/graph/graph.html",
                    controller:'GraphController'
                }),
                
             $stateProvider
                .state('login', {
                    url: "/login",
                    templateUrl:"assets/js/views/login/login.html",
                    controller:'LoginController'
                }),
                
                $stateProvider
                .state('admin', {
                    url: "/admin",
                    templateUrl:"assets/js/views/admin/AdminView.html",
                    controller:'AdminController'
                    
                }),
                $stateProvider
                .state('authusers', {
                    url: "/",
                    controller:'AuthController'
                    
                })
    });
})();