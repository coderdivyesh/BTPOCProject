(function () {
	'use strict';
angular.module('reportTool').factory('AdminService', ['$http' ,'AuthenticationService','AppConstants' ,function ($http ,AuthenticationService,AppConstants){
	
	return {
		
		createNewUser: function ($scope ,request) {
			
       	 var url = AppConstants.hostName+AppConstants.hostPort+AppConstants.applicationName+AppConstants.createNewUserURL;
    	 return  $http.post(url,request);

      },
	
      
      
      updateUser: function ($scope ,request) {
			
        	 var url = AppConstants.hostName+AppConstants.hostPort+AppConstants.applicationName+AppConstants.updateUserURL;
     	 return  $http.post(url,request);

       },
      
	
	showUserList: function ($scope) {
		
        return  $http({
                method: 'GET',
                url: AppConstants.hostName+AppConstants.hostPort+AppConstants.applicationName+AppConstants.getAllUserURL,
                dataType :'json',
                data : ''
         })
		
     },
	//for allActive users
     showActiveUserList: function ($scope) {
          return  $http({
                  method: 'GET',
                  url: 'http://127.0.0.1:8080/btpoc/admin/showActiveUsers',
                  dataType :'json',
                  data : ''
           })

       },
       
       killActiveUser: function (request) {
			
         	 var url = AppConstants.hostName+AppConstants.hostPort+AppConstants.applicationName+AppConstants.killActiveUserURL;
      	 return  $http.post(url,request);

        },   
     

       }

	
}]);
}());