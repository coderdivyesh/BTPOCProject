
(function () {
	'use strict';
	angular.module('reportTool').factory('ViewReportService', ['$http' ,'AuthenticationService','AppConstants' ,function ($http ,AuthenticationService,AppConstants){

	return {

		showReport: function ($scope) {
			var url = AppConstants.hostName+AppConstants.hostPort+AppConstants.applicationName+AppConstants.showReportURL;

			return  $http.post(url,$scope.request)

		},



		loadCSVData: function (request) {
			var url = AppConstants.hostName+AppConstants.hostPort+AppConstants.applicationName+AppConstants.downloadCSVURL;
			return  $http.post(url,request)

		},



		loadPDFData: function (request) {
			var url = AppConstants.hostName+AppConstants.hostPort+AppConstants.applicationName+AppConstants.downloadPDFURL;
			return  $http.post(url,request)

		},      



		loadXLSData: function (request) {
			var url = AppConstants.hostName+AppConstants.hostPort+AppConstants.applicationName+AppConstants.downloadXLSURL;
			return  $http.post(url,request)

		},      

		getTreeData : function($scope) {
			return $http({
				method: 'GET',
				url: AppConstants.hostName+AppConstants.hostPort+AppConstants.applicationName+AppConstants.treedataURL,
				headers: {'Content-Type': 'application/json','AUTH-TOKEN':AuthenticationService.getAuthenticationToken} ,
				dataType : 'json',
				data : ''
			})
		},


		drawGraph: function ($scope) {
			return  $http({
				method: 'GET',
				url: AppConstants.hostName+AppConstants.hostPort+AppConstants.applicationName+AppConstants.graphdataURL+$scope.xCoordinate+'/'+$scope.yCoordinate+'/'+$scope.duration+'/'+$scope.samplingPeriod+'/'+$scope.aggrType,
				headers: {'Content-Type': 'application/json' ,'AUTH-TOKEN':AuthenticationService.getAuthenticationToken },
				dataType :'json',
				data : ''
			})
		},

		saveNewReport: function (request) {
			var url = AppConstants.hostName+AppConstants.hostPort+AppConstants.applicationName+AppConstants.saveNewReportURL;
			return  $http.post(url,request)

		},

		insertNewReportTemplate: function (request) {
			var url = AppConstants.hostName+AppConstants.hostPort+AppConstants.applicationName+AppConstants.insertNewReportTemplateURL;
			return  $http.post(url,request)

		},

		deleteReportTemplate: function (request) {
			var url = AppConstants.hostName+AppConstants.hostPort+AppConstants.applicationName+AppConstants.deleteUserTemplateURL;
			return  $http.post(url,request)

		}, 

		genrateUniqueId: function() { 
			function _p8(s) { 
				var p = (Math.random().toString(16)+"000000000").substr(2,8); 
				return s ? "-" + p.substr(0,4) + "-" + p.substr(4,4) : p ; 
			} 
			return _p8() + _p8(true) + _p8(true) + _p8(); 
		}, 

		getEditReport:function ($scope){
			var httpRequest = $http({
				method: 'GET',
				url: ''
			})
		},
		
		insertGlobalTemplate: function (request) {
			var url = AppConstants.hostName+AppConstants.hostPort+AppConstants.applicationName+AppConstants.insertGobalTemplateURL;
			return  $http.post(url,request)

		},
		
		deleteglobalTemplate: function (request) {
			var url = AppConstants.hostName+AppConstants.hostPort+AppConstants.applicationName+AppConstants.deleteGlobalTemplateURL;
			return  $http.post(url,request)

		}, 
	}
}]);

}());