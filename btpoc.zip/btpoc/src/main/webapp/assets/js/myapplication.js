/**
 * 
 */

(function () {
    'use strict';
    
   angular.module('reportTool', [
        'ui.router','checklist-model','angularTreeview','ngStorage'
  ]).constant('AppConstants', {
	   'hostName':'http://127.0.0.1:', 
	   'hostPort': '8080' ,
	   'applicationName' : '/btpoc' ,
	   'get' : 'GET' ,  
	   'post' : 'POST' , 
	   'showReportURL' : '/api/report/getReportsAccordingTemplate',
	   'downloadCSVURL':'/api/filereport/downloadFileReport/CSV/',
	   'downloadPDFURL':'/api/filereport/downloadFileReport/PDF/',
	   'downloadXLSURL':'/api/filereport/downloadFileReport/XLS/',
	   'saveNewReportURL' :'/api/report/saveUserTemplate',
	   'createNewUserURL' :'/admin/createNewUser',
	   'updateUserURL' :'/admin/updateUser',
	   'loadDefaultUserURL' : '/admin/loadDefaultUser',
	   'getAllUserURL' : '/admin/getAllUser',
	   'loginURL' :'/api/login',
	   'insertNewReportTemplateURL' :'/api/report/insertUserTemplate',
		'killActiveUserURL' : '/admin/killActiveUsers',
	   'treedataURL' : '/api/report/getAllTemplate',
	   'graphdataURL' : '/graph/getChart/',
	   'deleteUserTemplateURL' : '/api/report/deleteUserTemplateNode',
	   'insertGobalTemplateURL' :'/api/report/insertGlobalTemplate',
	   'deleteGlobalTemplateURL' :'/api/report/deleteUserTemplateNode',
	   
	   'FilterExpressionEnum': [
            { Id: 1, displayName:'is', expression: '=' ,expressionAsString:''},
            { Id: 2, displayName:'is not', expression: '!=' ,expressionAsString:''},
            { Id: 3, displayName:'is like', expression: 'like' ,expressionAsString:''},
            { Id: 4, displayName:'is not like', expression: '!like' ,expressionAsString:''},
            { Id: 5, displayName:'is present', expression: 'Present' ,expressionAsString:''},
            { Id: 6, displayName:'is not present', expression: '!Present' ,expressionAsString:''},
            { Id: 7, displayName:'starts with', expression: 'startsWith' ,expressionAsString:''}, 
            { Id: 8, displayName:'does not  starts with', expression: '!startsWith' ,expressionAsString:''},
            { Id: 8, displayName:'ends with', expression: 'endsWith' ,expressionAsString:''},
            { Id: 9, displayName:'does not ends with', expression: '!endsWith',expressionAsString:'' },
            {Id: 10, displayName:'contains', expression: 'contains' ,expressionAsString:''},
            {Id: 11, displayName:'does not contains', expression: '!contains' ,expressionAsString:''}
		 
         ],
         
         'RoleEnum' :
        	 {
        	  admin:'ROLE_ADMIN',
        	  user:'ROLE_USER'
        	 }

	});
  
}());