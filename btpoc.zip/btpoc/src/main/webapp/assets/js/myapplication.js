/**
 * 
 */

(function () {
    'use strict';
    
   angular.module('reportTool', [
        'ui.router','checklist-model'
  ]);
  
}());