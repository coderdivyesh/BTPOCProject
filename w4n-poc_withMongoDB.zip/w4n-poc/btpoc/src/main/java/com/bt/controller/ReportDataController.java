package com.bt.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bt.entity.CommonData;
import com.bt.entity.ReportData;
import com.bt.entity.ReportDataList;
import com.bt.service.ReportDataService;

@RestController
@RequestMapping("/report")
public class ReportDataController {

	private static final Logger logger = LoggerFactory.getLogger(ReportDataController.class);

	@Autowired
	ReportDataService reportDataService;

	@RequestMapping(value = "/getAllReports", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<ReportData>> getAllReports() {
		if (logger.isDebugEnabled()) {
			logger.debug(" getAllReports() : ");
		}
		List<ReportData> reportdatalist = reportDataService.getAllReports();
		if (logger.isDebugEnabled()) {
			logger.debug(" getAllReports() : reportdatlist: " + reportdatalist);
		}
		return new ResponseEntity<List<ReportData>>(reportdatalist, HttpStatus.OK);
	}

	@RequestMapping(value = "/getAllReportwithPageination/{pagenumber}/{pagesize}/{lastid}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<ReportData>> getAllReports(@PathVariable int pagenumber, @PathVariable int pagesize,
			@PathVariable int lastid) {
		if (logger.isDebugEnabled()) {
			logger.debug(getAllReports() + " Page Number : " + pagenumber + " Page Size : " + pagesize);
		}
		List<ReportData> reportdatalist = reportDataService.getAllReports(pagenumber, pagesize);
		if (logger.isDebugEnabled()) {
			logger.debug(" getAllReports() : reportdatlist: " + reportdatalist);
		}
		return new ResponseEntity<List<ReportData>>(reportdatalist, HttpStatus.OK);
	}

	/**
	 * 
	 * @param reportData
	 * @return
	 */

	@RequestMapping(value = "/getReportsAccordingTemplate/{pagenumber}/{pagesize}/{templateid}/{configid}/{duration}/{starttime}/{endtime}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ReportDataList> getReportsAccordingTemplate(@PathVariable int pagenumber,
			@PathVariable int pagesize, @PathVariable String templateid, @PathVariable String configid,
			@PathVariable String duration, @PathVariable String starttime, @PathVariable String endtime) {
		if (logger.isDebugEnabled()) {
			logger.debug("getReportsForTemplate() CommonData  ");
		}
		ReportDataList reportdetails = new ReportDataList();
		List<ReportData> reportdatalist = null;
		CommonData commonprop = new CommonData();
		commonprop.setPagenumber(pagenumber);
		commonprop.setPagesize(pagesize);
		if (!StringUtils.isEmpty(duration)) {
			commonprop.setDuration(duration);
		}
		if (!StringUtils.isEmpty(starttime) && !"null".equalsIgnoreCase(starttime)) {
			commonprop.setStarttime(starttime);	
		}
		if (!StringUtils.isEmpty(starttime)	&& !"null".equalsIgnoreCase(starttime)) {
			commonprop.setEndtime(endtime);
		}
		if (!StringUtils.isEmpty(configid) && !StringUtils.isEmpty(templateid)) {
			commonprop.setConfigid(configid);
			commonprop.setTemplateid(templateid);
		} else {
			return new ResponseEntity<ReportDataList>(reportdetails, HttpStatus.BAD_REQUEST);
		}
		try {
			reportdatalist = reportDataService.getAllReportsAccoringtoTemplate(commonprop);
			reportdetails.setReportdatalist(reportdatalist);
			reportdetails.setCommondata(commonprop);
		} catch (Exception ex) {
			logger.error(" Unable to process request :" + ex.getMessage(), ex);
			return new ResponseEntity<ReportDataList>(reportdetails, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		if (logger.isDebugEnabled()) {
			logger.debug(" getAllReports() : reportdatlist: " + reportdatalist);
		}
		return new ResponseEntity<ReportDataList>(reportdetails, HttpStatus.OK);
	}

}
