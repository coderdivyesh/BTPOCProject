package com.bt.constant;

public enum TimeEnum {
	ONE_HOUR(1000 * 60 * 60), 
	ONE_DAY(1000 * 60 * 60 * 24), 
	THIRTY_MIN(1000 * 60 * 30), 
	FIFTEEN_MIN(1000 * 60 * 15);

	private final long value;

	private TimeEnum(long value) {
		this.value = value;
	}

	public long getValue() {
		return value;
	}

	public static TimeEnum getEnum(long value) {
		for (TimeEnum v : values())
			if (v.getValue() == value)
				return v;
		throw new IllegalArgumentException();
	}

}
