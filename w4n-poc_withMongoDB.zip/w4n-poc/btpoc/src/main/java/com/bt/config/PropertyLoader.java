package com.bt.config;

import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.support.PropertiesLoaderUtils;

public class PropertyLoader {
	private static final String REPORT_TEMPLATE_PROPERTIES = "/reporttemplate.properties";
	private static final Logger logger = LoggerFactory.getLogger(PropertyLoader.class);

	private static Properties configProp;
	
	/**
	 * 
	 * @return
	 */
	 public static Properties getConfigProp() {
		 if(null==configProp){
			 loadDefaultProperties();
		 }
			return configProp;
		}
	 /**
	  * 
	  */
	private static void loadDefaultProperties() {
		if (null == configProp) {
			try {
				configProp = PropertiesLoaderUtils.loadAllProperties(REPORT_TEMPLATE_PROPERTIES);
			} catch (Exception ex) {
				logger.error("Unable to load reporttemplate.properties "+ex.getMessage(),ex);
			}
		}
	}
	
}
