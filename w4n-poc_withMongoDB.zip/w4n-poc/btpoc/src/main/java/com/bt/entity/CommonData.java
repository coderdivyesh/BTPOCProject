package com.bt.entity;

import java.util.List;
import java.util.Map;

import javax.validation.constraints.NotNull;

import com.bt.common.DisplayParam;


public class CommonData {
	
	@NotNull
	private Integer pagenumber;
	@NotNull
	private Integer pagesize;
	
	private String templateid;
	
	private String configid;
	
	private String duration;
	
	private String starttime;
	
	private String endtime;
	
	

	private List<DisplayParam> displayprams;

	private Map<Object,String> filterparamlist;

	
	
	
	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	public String getStarttime() {
		return starttime;
	}

	public void setStarttime(String starttime) {
		this.starttime = starttime;
	}


	public Integer getPagenumber() {
		return pagenumber;
	}

	public void setPagenumber(Integer pagenumber) {
		this.pagenumber = pagenumber;
	}

	public Integer getPagesize() {
		return pagesize;
	}

	public void setPagesize(Integer pagesize) {
		this.pagesize = pagesize;
	}

	public String getTemplateid() {
		return templateid;
	}

	public void setTemplateid(String templateid) {
		this.templateid = templateid;
	}

	public String getConfigid() {
		return configid;
	}

	public void setConfigid(String configid) {
		this.configid = configid;
	}

	public List<DisplayParam> getDisplayprams() {
		return displayprams;
	}

	public void setDisplayprams(List<DisplayParam> displayprams) {
		this.displayprams = displayprams;
	}

	
	public Map<Object, String> getFilterparamlist() {
		return filterparamlist;
	}

	public void setFilterparamlist(Map<Object, String> filterparamlist) {
		this.filterparamlist = filterparamlist;
	}
	
	public String getEndtime() {
		return endtime;
	}

	public void setEndtime(String endtime) {
		this.endtime = endtime;
	}

	@Override
	public String toString() {
		return "CommonData [pagenumber=" + pagenumber + ", pagesize=" + pagesize + ", templateid=" + templateid
				+ ", configid=" + configid + ", duration=" + duration + ", starttime=" + starttime + ", endtime="
				+ endtime + ", displayprams=" + displayprams + ", filterparamlist=" + filterparamlist + "]";
	}


}
