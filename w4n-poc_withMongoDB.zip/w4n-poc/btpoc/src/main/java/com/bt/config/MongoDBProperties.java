package com.bt.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.stereotype.Component;

@Component
public class MongoDBProperties {

	
	@Value("${mongo.dbname}")
	protected String dbname;
	
	@Value("${mongo.contactpoints}")
	protected String contactpoints;
	
	@Value("${mongo.port}")
	protected String portnumber;
    
	@Value("${mongo.fetchlimit}")
	protected String fetchsize;

	@Value("${mongo.dbCollection}")
	protected String dbcollection;
	
	@Bean
	public static PropertySourcesPlaceholderConfigurer propertyConfigInDev() {
		return new PropertySourcesPlaceholderConfigurer();
	}

	
	@Override
	public String toString() {
		return "DBProperties [dbname=" + dbname + ", contactpoints=" + contactpoints + ", portnumber=" + portnumber
				+ ", fetchsize=" + fetchsize + ", dbcollection=" + dbcollection + "]";
	}

    
    
	

}
