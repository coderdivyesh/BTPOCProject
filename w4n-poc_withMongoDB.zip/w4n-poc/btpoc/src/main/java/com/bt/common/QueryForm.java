package com.bt.common;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;

import org.springframework.util.StringUtils;

import com.bt.entity.CommonData;
import com.mongodb.BasicDBObject;

public class QueryForm {
	
	
	public static BasicDBObject formQuery(CommonData commandata) throws Exception {
		long filtertime = 0;
		BasicDBObject wherequery = new BasicDBObject();
		if (!StringUtils.isEmpty(commandata.getDuration())) {
			filtertime = convertDurationToMiliseconds(commandata.getDuration());
			wherequery.put("OpenedAt", new BasicDBObject("$gte",filtertime));
		} else if (!StringUtils.isEmpty(commandata.getEndtime()) && !StringUtils.isEmpty(commandata.getStarttime())) {
			wherequery.put("OpenedAt",
					new BasicDBObject("$gte", commandata.getStarttime()).append("$lte", commandata.getEndtime()));
		} else if (!StringUtils.isEmpty(commandata.getEndtime())) {
			wherequery.put("OpenedAt", commandata.getEndtime());
		} else if (!StringUtils.isEmpty(commandata.getStarttime())) {
			wherequery.put("OpenedAt", commandata.getStarttime());
		}
		
		return wherequery;
	}

	public static long convertEpoch(String datestring) throws Exception{
		    SimpleDateFormat df = new SimpleDateFormat("MMM dd yyyy HH:mm:ss.SSS zzz");
		    Date date = df.parse(datestring);
		   return date.getTime();
	}
	
	private static long convertDurationToMiliseconds(String duration) {
		long timeseconds = 60;
		long timeminutes = 60;
	    long defaultvale=0;
		ZoneId zoneId = ZoneId.of("UTC"); 
		if (!StringUtils.isEmpty(duration)) {
			String timevalue = null;
			if (duration.contains("seconds")) {
				timevalue = duration.replace("seconds", "");
				long time = Long.parseLong(timevalue);
				LocalDate local=LocalDate.now();
				return local.atStartOfDay(zoneId).toEpochSecond()+time;
			} else if (duration.contains("minutes")) {
				timevalue = duration.replace("minutes", "");
				long time = Long.parseLong(timevalue);
				LocalDate local=LocalDate.now();
				return local.atStartOfDay(zoneId).toEpochSecond()+(timeseconds*time);
			} else if (duration.contains("hours")) {
				timevalue = duration.replace("hours", "");
				long time = Long.parseLong(timevalue);
				LocalDate local=LocalDate.now();
				return local.atStartOfDay(zoneId).toEpochSecond()+(timeminutes*timeseconds*time);
			} else if (duration.contains("day")) {
				timevalue = duration.replace("day", "");
				long time = Long.parseLong(timevalue);
				LocalDate local=LocalDate.now().minusDays(time);
				return local.atStartOfDay(zoneId).toEpochSecond();
			} else if (duration.contains("week")) {
				timevalue = duration.replace("week", "");
				long time = Long.parseLong(timevalue);
				LocalDate local=LocalDate.now().minusWeeks(time);
				return local.atStartOfDay(zoneId).toEpochSecond();
			} else if (duration.contains("month")) {
				timevalue = duration.replace("month", "");
				long time = Long.parseLong(timevalue);
				LocalDate local=LocalDate.now().minusMonths(time);
				return local.atStartOfDay(zoneId).toEpochSecond();
				
			} else if (duration.contains("year")) {
				timevalue = duration.replace("year", "");
				long time = Long.parseLong(timevalue);
				LocalDate local=LocalDate.now().minusYears(time);
				return local.atStartOfDay(zoneId).toEpochSecond();
			}
		}
		return defaultvale;
	
	}

}
