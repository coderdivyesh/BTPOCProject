package com.bt.common;

public class DisplayParam {
	
	public String filedname;
	
	public String displayFiledName;
	
	public boolean isDisplay;
	
	public String databasefieldname;

	public String getFiledname() {
		return filedname;
	}

	public void setFiledname(String filedname) {
		this.filedname = filedname;
	}

	public boolean isDisplay() {
		return isDisplay;
	}

	public void setDisplay(boolean isDisplay) {
		this.isDisplay = isDisplay;
	}

	public String getDisplayFiledName() {
		return displayFiledName;
	}

	public void setDisplayFiledName(String displayFiledName) {
		this.displayFiledName = displayFiledName;
	}

	
	public String getDatabasefieldname() {
		return databasefieldname;
	}

	public void setDatabasefieldname(String databasefieldname) {
		this.databasefieldname = databasefieldname;
	}

	@Override
	public String toString() {
		return "FilterParameter [filedname=" + filedname + ", displayFiledName=" + displayFiledName + ", isDisplay="
				+ isDisplay + ", databasefieldname=" + databasefieldname + "]";
	}

	
}
