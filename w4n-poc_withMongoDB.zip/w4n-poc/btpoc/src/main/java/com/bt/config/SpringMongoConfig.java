package com.bt.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import com.mongodb.DBCollection;
import com.mongodb.MongoClient;
/**
 * All configuration related for mongo data base . It load mongo related properties from mopngo.properties file.
 * @author 611022163
 *
 */
@Configuration
public class SpringMongoConfig   {

	private static final Logger logger = LoggerFactory.getLogger(SpringMongoConfig.class);
	private static DBCollection collection;
	
	@Autowired
	MongoDBProperties dpDbProperties;
	

	public  DBCollection getCollection() {
		if (null == collection) {
			synchronized (SpringMongoConfig.class) {
				if (null == collection) {
					collection = new MongoClient(dpDbProperties.contactpoints, Integer.parseInt(dpDbProperties.portnumber)).getDB(dpDbProperties.dbname)
							.getCollection(dpDbProperties.dbcollection);
				}
			}
		}
		return collection;
	}

}
