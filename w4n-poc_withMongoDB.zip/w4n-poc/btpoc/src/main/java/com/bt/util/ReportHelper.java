package com.bt.util;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.util.StringUtils;
import org.supercsv.cellprocessor.ift.CellProcessor;
import org.supercsv.io.ICsvBeanWriter;

import com.bt.common.DisplayParam;
import com.bt.entity.CommonData;
import com.bt.entity.ReportData;
import com.bt.entity.ReportDataList;

public class ReportHelper {
	
	/**
	 * 
	 * @param reportData
	 */
	public static void getFilterfield(CommonData reportData) {
		List<DisplayParam> filterparams = null;
		String Keys = FileHelper.getPropertieskeyForTemplate(reportData);
		if (!StringUtils.isEmpty(Keys)) {
			String[] keys = Keys.split(",");
			filterparams = new ArrayList<DisplayParam>(keys.length);
			for (String key : keys) {
				if (!StringUtils.isEmpty(key) && !"all".equalsIgnoreCase(key)) {
					DisplayParam filterparam = new DisplayParam();
					filterparam.setFiledname(key.toLowerCase());
					filterparam.setDisplay(Boolean.TRUE);
					filterparam.setDisplayFiledName(key.toUpperCase());
					filterparam.setDatabasefieldname(key);
					filterparams.add(filterparam);
				}
				}
			reportData.setDisplayprams(filterparams);
		}
	
	}
	
	/**
	 * This method will crate report for CSV
	 * @param csvbeanwriter
	 * @param reportdatalist
	 * @throws Exception
	 */
	public static void createCSV(ICsvBeanWriter csvbeanwriter, ReportDataList reportdetails) throws Exception {
		List<ReportData> reportdatalist = reportdetails.getReportdatalist();
		if (!reportdetails.getReportdatalist().isEmpty()) {
			List<DisplayParam> filterparams = reportdetails.getCommondata().getDisplayprams();
			String[] csvHeader = FileHelper.getHeaderList(filterparams);
			String[] fieldlist = FileHelper.getFieldList(filterparams);
			final CellProcessor[] processors = FileHelper.getProcessors(fieldlist);
			csvbeanwriter.writeHeader(csvHeader);
			for (ReportData report : reportdatalist) {
				csvbeanwriter.write(report, csvHeader, processors);
			}
		}
	}

	/**
	 * This method will create PDF
	 * @param reportDataList
	 * @return
	 * @throws Exception
	 */
	public static ByteArrayOutputStream createPDF(ReportDataList reportdetails) throws Exception {
		return ReportPDFWriter.getInstance().createPDFContent("report", reportdetails);
	}

	/**
	 * This method will create TXT file 
	 * @param reportDataList
	 * @return
	 * @throws Exception
	 */
	public static ByteArrayOutputStream createTXT(ReportDataList reportdetails) throws Exception {
		InputStream inputstream=null;// FileHelper.createTXT("report", reportDataList);
		ByteArrayOutputStream baos=new ByteArrayOutputStream();
		IOUtils.copy(inputstream, baos);
		return baos;
	}
	
/**
 * Thsi method wiil create xls file 
 * @param workBook
 * @param excelSheet
 * @throws Exception
 */
	public static HSSFWorkbook createExcel(HttpServletResponse response,ReportDataList reportdetails) throws Exception {
		
		response.setContentType("application/vnd.ms-excel");
	    response.setHeader("Expires", "0");
	    response.setHeader("Cache-Control", "must-revalidate, post-check=0, pre-check=0");
	    response.setHeader("Pragma", "public");
	    response.setHeader("Content-Disposition", "attachment; filename=ReportsData.xls");
	    
		HSSFWorkbook workBook = new HSSFWorkbook();
		HSSFSheet excelSheet = workBook.createSheet("report_excel");
		HSSFRow excelHeader = excelSheet.createRow(0);
		String[] xlsHeaders = FileHelper.getHeaderList(reportdetails.getCommondata().getDisplayprams());
		String[] xlsFields =FileHelper.getFieldList(reportdetails.getCommondata().getDisplayprams());
		for (int i = 0; i < xlsHeaders.length; i++) {
			excelHeader.createCell(i).setCellValue(xlsHeaders[i]);
		}
		List<ReportData> reportDataList = reportdetails.getReportdatalist();
		for (int row = 1; row < reportDataList.size(); row++) {
			HSSFRow excelRow = excelSheet.createRow(row);
			for (int record = 0; record < xlsHeaders.length; record++) {
				Field field = ReportData.class.getDeclaredField(xlsFields[record]);
				field.setAccessible(Boolean.TRUE);
				Object value = field.get(reportDataList.get(row));
				excelRow.createCell(record).setCellValue(String.valueOf(value));
			}
		}
		
		return workBook;
	}

}
