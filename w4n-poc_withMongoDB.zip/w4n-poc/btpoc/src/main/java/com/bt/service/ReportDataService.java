package com.bt.service;

import java.io.ByteArrayOutputStream;
import java.util.List;

import org.supercsv.io.ICsvBeanWriter;

import com.bt.entity.CommonData;
import com.bt.entity.ReportData;
/**
 * 
 * @author 611022163
 *
 */
public interface ReportDataService {

	public List<ReportData> getAllReports(int pagenumber,int pagesize);
	
	public List<ReportData> getAllReports();
	
	public List<ReportData> getAllReportsAccoringtoTemplate(CommonData reportData)throws Exception;
}
