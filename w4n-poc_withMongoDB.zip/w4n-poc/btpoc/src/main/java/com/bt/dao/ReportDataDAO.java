package com.bt.dao;

import java.util.List;

import com.bt.entity.CommonData;
import com.bt.entity.ReportData;

public interface ReportDataDAO {
	
	public List<ReportData> getAllReports();
	
	public List<ReportData> getAllReports(int pagenumber,int pagesize);
	
	public List<ReportData> getAllReports(CommonData reportdata)throws Exception;
	public List<ReportData> fetchReports(CommonData reportdata)throws Exception;

}
