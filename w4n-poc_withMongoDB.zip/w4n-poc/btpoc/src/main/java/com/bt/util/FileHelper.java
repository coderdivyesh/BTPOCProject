package com.bt.util;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.util.List;
import java.util.Properties;

import org.supercsv.cellprocessor.Optional;
import org.supercsv.cellprocessor.constraint.NotNull;
import org.supercsv.cellprocessor.ift.CellProcessor;

import com.bt.common.DisplayParam;
import com.bt.config.PropertyLoader;
import com.bt.entity.CommonData;
import com.bt.entity.ReportData;



/**
 * 
 * @author 611022163
 *
 */
public class FileHelper {
	
    /**
     * 
     * @param fields
     * @return
     * @throws Exception
     */
	public static CellProcessor[] getProcessors(String[] fields) throws Exception {
		final CellProcessor[] processors = new CellProcessor[fields.length];
		for (int row = 0; row < fields.length; row++) {
			Field fetchfield = ReportData.class.getDeclaredField(fields[row]);
			if (fetchfield.getType().isAssignableFrom(String.class)) {
				processors[row] = new NotNull();
			} else {
				processors[row] = new Optional();
			}
		}
		return processors;
	}

	/**
	 * 
	 * @param filename
	 * @param reportlist
	 * @return
	 * @throws Exception
	 */
	public static InputStream createTXT(String filename, List<ReportData> reportlist) throws Exception {
		return new ByteArrayInputStream(reportlist.toString().getBytes("UTF8"));
	}

	/**
	 * 
	 * @param common
	 * @return
	 */
	public static String getPropertieskeyForTemplate(CommonData common) {
		Properties properties = PropertyLoader.getConfigProp();
		String key = "report.template." + common.getTemplateid() + "." + common.getConfigid();
		return properties.getProperty(key);
	}

	/**
	 * 
	 * @param filterparams
	 * @return
	 */
	public static String[] getHeaderList(List<DisplayParam> filterparams) {

		String[] header = null;
		if (null != filterparams && !filterparams.isEmpty()) {
			int arraysize = filterparams.size();
			header = new String[arraysize];
			for (int i = 0; i < arraysize; i++) {
				header[i] = filterparams.get(i).getDisplayFiledName();
			}
		}
		return header;
	}
	/**
	 * 
	 * @param filterparams
	 * @return
	 */
	public static String[] getFieldList(List<DisplayParam> filterparams) {

		String[] fieldname = null;
		if (null != filterparams && !filterparams.isEmpty()) {
			int arraysize = filterparams.size();
			fieldname = new String[arraysize];
			for (int i = 0; i < arraysize; i++) {
				fieldname[i] = filterparams.get(i).getFiledname();
			}
		}
		return fieldname;
	}
}
