(function () {
    'use strict';
    angular.module('reportTool').config(function ($stateProvider, $urlRouterProvider) {
    
        // setting up the states
        
        $urlRouterProvider.otherwise("/report");
  
        $stateProvider
                .state('report', {
                    url: "/report",
                    templateUrl:"assets/js/views/report/ViewReport.html",
                    controller:'ViewReportController'
                })
                
    });
})();