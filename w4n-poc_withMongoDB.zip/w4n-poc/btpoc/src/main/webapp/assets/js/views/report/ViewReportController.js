angular.module('reportTool').controller('ViewReportController',['$scope','$http','ViewReportService','$sce' , function($scope, $http ,ViewReportService,$sce)  {
	
	
	
	$scope.pagenumber=1;
	$scope.pagetotalsize=100;
	$scope.formats = ["XLS", "CSV","TXT","PDF"];
	$scope.lastid=1;
	$scope.enabledisplay=false;
	$scope.enableDisplayOptions = false;
	$scope.timeIntervals = ["past 15 min" ,"past 30 min", "past 1 day" ,"past 1 week","past 1 month"];
	$scope.templateid='all';
	$scope.configid='general';
	$scope.input=[];
	$scope.min=0;
	$scope.max=15;
	 $scope.duration='1month';
	 $scope.starttime=null;
	 $scope.endtime=null;
	 
	 

	$scope.hostName='';
	$scope.hostPort='';
	$scope.applicationName='';
	$scope.nextPageURL='';
	$scope.previousPageURL='';
	$scope.showReportURL='';
	$scope.downloadCSVURL='';
	$scope.downloadPDFURL='';
	$scope.downloadXLSURL='';
	  $scope.content='';
	$scope.pageCountList = [10,20,30,40,50,60,70,80,90,100];


	$scope.defaultpageCount=10;
	$scope.pagesize=10;
	$scope.selectedpageCount=10;
	
	$scope.totalpageNotoDisaplay = 10;

	$scope.records=[{id:1}];

	$http.get('HostConfig.properties').then(function (response) {
		$scope.hostName=response.data.hostName;
		$scope.hostPort=response.data.hostPort;
		$scope.applicationName=response.data.applicationName;
		$scope.showReportURL=response.data.showReportURL;
		$scope.downloadCSVURL=response.data.downloadCSVURL;
		$scope.downloadPDFURL=response.data.downloadPDFURL;
		$scope.downloadXLSURL=response.data.downloadXLSURL;
		
	});


	$scope.tableColumns1=[
	                     {filedname:'id',displayFiledName:'ID'},
	                     {filedname:'name',displayFiledName:'NAME'},
	                     {filedname:'openedat',displayFiledName:'OPENEDAT'},
	                     {filedname:'source',displayFiledName:'SOURCE'},
	                     {filedname:'classname',displayFiledName:'CLASSNAME'},
	                     {filedname:'instancename',displayFiledName:'INSTANCE_NAME'},
	                     {filedname:'eventname',displayFiledName:'EVENT_NAME'},
	                     {filedname:'classdisplayname',displayFiledName:'CLASS_DISPLAY_NAME'},
	                     {filedname:'instancedisplayname',displayFiledName:'INSTANCE_DISPLAY_NAME'},
	                     {filedname:'eventdisplayname',displayFiledName:'EVENT_DISPLAY_NAME'},
	                     {filedname:'elementclassname',displayFiledName:'ELEMENT_CLASS_NAME'},
	                     {filedname:'elementname',displayFiledName:'ELEMENT_NAME'},
	                     {filedname:'sourcedomainname',displayFiledName:'SOURCE_DOMAINNAME'},
	                     {filedname:'sourceeventtype',displayFiledName:'SOURCE_EVENTTYPE'},
	                     {filedname:'active',displayFiledName:'ACTIVE'},
	                     {filedname:'closedat',displayFiledName:'CLOSEDAT'},
	                     {filedname:'lastchangedat',displayFiledName:'LAST_CHANEDDATE'},
	                     {filedname:'isroot',displayFiledName:'ISROOT'},
	                     {filedname:'isproblem',displayFiledName:'ISPROBLEM'},
	                     {filedname:'eventtype',displayFiledName:'EVENTTYPE'},
	                     {filedname:'severity',displayFiledName:'SEVERITY'},
	                     {filedname:'impact',displayFiledName:'IMPACT'},
	                     {filedname:'certainty',displayFiledName:'CERTAINITY'},
	                     {filedname:'inMaintenance',displayFiledName:'INMAINTATINANCE'},
	                     {filedname:'troubleticketiD',displayFiledName:'TROUBLE_TICKETID'},
	                     {filedname:'owner',displayFiledName:'OWNER'},
	                     {filedname:'updatedat',displayFiledName:'UPDATEAT'},
	                     {filedname:'userdefined1',displayFiledName:'USERDEFINED1'},
	                     {filedname:'userdefined2',displayFiledName:'USERDEFINED2'},
	                     {filedname:'userdefined3',displayFiledName:'USERDEFINED3'},
	                     {filedname:'userdefined4',displayFiledName:'USERDEFINED4'},
	                     {filedname:'userdefined5',displayFiledName:'USERDEFINED5'},
	                     {filedname:'userdefined6',displayFiledName:'USERDEFINED6'},
	                     {filedname:'userdefined7',displayFiledName:'USERDEFINED7'},
	                     {filedname:'userdefined8',displayFiledName:'USERDEFINED8'},
	                     {filedname:'userdefined9',displayFiledName:'USERDEFINED9'},
	                     {filedname:'userdefined10',displayFiledName:'USERDEFINED10'},
	                     {filedname:'userdefined11',displayFiledName:'USERDEFINED11'},
	                     {filedname:'userdefined12',displayFiledName:'USERDEFINED12'},
	                     {filedname:'userdefined13',displayFiledName:'USERDEFINED13'},
	                     {filedname:'userdefined14',displayFiledName:'USERDEFINED14'},
	                     {filedname:'userdefined15',displayFiledName:'USERDEFINED15'},
	                     {filedname:'userdefined16',displayFiledName:'USERDEFINED16'},
	                     {filedname:'userdefined17',displayFiledName:'USERDEFINED17'},
	                     {filedname:'userdefined18',displayFiledName:'USERDEFINED18'},
	                     {filedname:'userdefined19',displayFiledName:'USERDEFINED19'},
	                     {filedname:'userdefined20',displayFiledName:'USERDEFINED20'}
	                     ];

	$scope.$watch('selection', function(newVal, oldVal){
		switch(newVal){
		case 'XLS':
		{
			ViewReportService.loadXLSData($scope).success(function(response) {
				var xlsinput = new Blob([response]); 
				window.navigator.msSaveOrOpenBlob(xlsinput, 'report.xlsx'); 
			});
		};
		break;
		case 'CSV':
		{
			ViewReportService.loadCSVData($scope).success(function(response) {
				var csvinput = new Blob([response]); 
				window.navigator.msSaveOrOpenBlob(csvinput, 'report.csv'); 
			});
		};
		break;
		case 'PDF':
		{
			ViewReportService.loadPDFData($scope).success(function(response) {
			
				var file = new Blob([response]);
				window.navigator.msSaveOrOpenBlob(file, 'report.pdf');        


			});
		};
		break;
		default:
			break;
		}
	});

	$scope.enablelink = false;
	$scope.showReportTable = false;
	$scope.editReportTable = false;
	$scope.disableNext =false;
	$scope.disablePrevious = true;

	$scope.enableReportLink = function() {
		$scope.editReportTable = false;
		$scope.showReportTable = false;
		$scope.enablelink = true;
		$scope.disableNext =false;
		$scope.disablePrevious = true;
	};


	$scope.showReport = function(templateId)
	{
		
		alert("showreport");
		$scope.showReportTable = true;
		$scope.editReportTable = false;
		$scope.enablelink = true;
		$scope.disableNext =false;
		$scope.disablePrevious = true;
		$scope.enableDisplayOptions = false;
	    $scope.templateid=templateId;

		ViewReportService.showReport($scope).success(function(data, status) {
			$scope.records = data.reportdatalist;
			$scope.tableColumns = data.commondata.displayprams;
			if($scope.templateid == 'all')
				{
				$scope.tableColumns=$scope.tableColumns1;
				}
			
		});
		
	};



	$scope.editReport = function()
	{
		$scope.showReportTable = true;
		$scope.enablelink = true;
		$scope.disableNext =false;
		$scope.disablePrevious = true;

		ViewReportService.showReport($scope).success(function(data, status) {
			$scope.records = data;
		});


	}      

	$scope.nextPage = function() {

		if ($scope.pagenumber < $scope.pagetotalsize) {
			$scope.disableNext =false;
			$scope.disablePrevious = false;
			$scope.pagenumber++;
			
			ViewReportService.showReport($scope).success(function(data, status) {
				$scope.records = data.reportdatalist;
				$scope.tableColumns = data.commondata.displayprams;
				if($scope.templateid == 'all')
				{
				
				$scope.tableColumns=$scope.tableColumns1;
				}
			
			});
			
		}
		else
			$scope.disableNext =true;

	};

	$scope.previousPage = function() {
		if ($scope.pagenumber > 1) {
			$scope.disableNext =false;
			$scope.disablePrevious = false;
			$scope.pagenumber--;

			ViewReportService.showReport($scope).success(function(data, status) {
				$scope.records = data.reportdatalist;
				$scope.tableColumns = data.commondata.displayprams;
				if($scope.templateid == 'all')
				{
				
				$scope.tableColumns=$scope.tableColumns1;
				}
			
			});
         
			
		}else
			$scope.disablePrevious = true;
	};

	$scope.$watch('selectedpageCount', function(){
		$scope.defaultpageCount =$scope.selectedpageCount;
		$scope.pagesize=$scope.selectedpageCount;

	});

	$scope.exportData = function () {
		alasql('SELECT * INTO CSV("records.csv",{headers:true}) FROM ?',[$scope.records]);
	};
	
	$scope.gettimeinterval = function()
	{
		$scope.showReportTable = false;
		$scope.editReportTable = false;
		$scope.enablelink = false;
		$scope.disableNext =false;
		$scope.disablePrevious = false;
		$scope.enabledisplay=true;
	}
	
	$scope.displayOptions = function(){
		$scope.showReportTable = true;
		$scope.editReportTable = false;
		$scope.enablelink = true;
		$scope.disableNext =true;
		$scope.disablePrevious = true;
		$scope.enabledisplay=true;
		$scope.enableDisplayOptions=true;
	}

	$scope.$watch('timeIntervalselection', function(newVal, oldVal){
		switch(newVal){
		case 'past 15 min':
		{
              $scope.duration="15minutes";
		};
		break;
		case 'past 30 min':
		{
			 $scope.duration="30minutes";
		};
		break;
		case 'past 1 day':
		{
			$scope.duration="1day";
		};
		break;
		case 'past 1 week':
		{
			$scope.duration="1week";
		};
		break;
		case 'past 1 month':
		{
			$scope.duration="1month";
		};
		break;
		default:
			break;
		}
		
		
		ViewReportService.showReport($scope).success(function(data, status) {
			$scope.records = data.reportdatalist;
			$scope.tableColumns = data.commondata.filterParameter;
			if($scope.templateid == 'all')
			{
			
			$scope.tableColumns=$scope.tableColumns1;
			}
		
		});
	});
	
	 
}]);