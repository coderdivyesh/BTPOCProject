angular.module('reportTool').factory('ViewReportService', ['$http' ,function ($http){
	
	return {
		
		showReport: function ($scope) {
           return  $http({
                   method: 'GET',
                   url: $scope.hostName+$scope.hostPort+$scope.applicationName+$scope.showReportURL+$scope.pagenumber+'/'+$scope.selectedpageCount+'/'+$scope.templateid+'/'+$scope.configid+
                          '/'+$scope.duration+'/'+$scope.starttime+'/'+$scope.endtime,
                   headers: {'Content-Type': 'application/json'} ,
                   dataType :'json',
                   data : ''
            })
        },
        
        showReport1: function (commomdata) {
            return  $http({
                    method: 'GET',
                    url: $scope.hostName+$scope.hostPort+$scope.applicationName+$scope.showReportURL,
                    headers: {'Content-Type': 'application/json'} ,
                    dataType :'json',
                    data : commomdata
             })
         },
         
        loadCSVData :function ($scope){
        	return $http({
                method: 'GET',
                url: $scope.hostName+$scope.hostPort+$scope.applicationName+$scope.downloadCSVURL+$scope.templateid+'/'+$scope.configid
          })
        },
        loadPDFData :function ($scope){
        	return $http({
                method: 'GET',
                url: $scope.hostName+$scope.hostPort+$scope.applicationName+$scope.downloadPDFURL+$scope.templateid+'/'+$scope.configid
          })
        },
        loadXLSData :function ($scope){
        	return $http({
                method: 'GET',
                url: $scope.hostName+$scope.hostPort+$scope.applicationName+$scope.downloadXLSURL+$scope.templateid+'/'+$scope.configid
          })
        },

        getEditReport:function ($scope){
        	var httpRequest = $http({
                method: 'GET',
                url: ''
          })
        }
	}
}]);