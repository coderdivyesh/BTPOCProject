/**
 * 
 */

(function () {
    'use strict';
    
   angular.module('reportTool', [
        'ui.router'//for advance routers
  ]);
  
}());