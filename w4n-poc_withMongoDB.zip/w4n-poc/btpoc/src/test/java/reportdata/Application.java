package reportdata;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.bt.entity.ReportData;
import com.bt.service.ReportDataService;

public class Application {

	@SuppressWarnings("resource")
	public static void main(String[] args) {

		ApplicationContext applicationContext = new AnnotationConfigApplicationContext(MainAppConfiguration.class);

		ReportDataService reportService = applicationContext.getBean(ReportDataService.class);
		List<ReportData> repots= reportService.getAllReports();
		System.out.println("Reopt size : "+ repots.size());
	
	}

}
