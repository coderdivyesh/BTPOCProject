package reportdata;

import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

public class TextItext {
	
	 public static void main( String[] args ) throws DocumentException, IOException
	    {
		 ByteArrayOutputStream bytearray=new ByteArrayOutputStream();
		 Document document1 = new Document();
			@SuppressWarnings("unused")
			PdfWriter pdfWriter1 = PdfWriter.getInstance(document1, bytearray);
			document1.open();
			Paragraph paragraph1 = new Paragraph();
			paragraph1.add("Hello World!");
			paragraph1.setAlignment(Element.ALIGN_CENTER);
			Paragraph otherParagraph1 = new Paragraph();
			otherParagraph1.add("Welcome to JCG!");
			otherParagraph1.setAlignment(Element.ALIGN_CENTER);
			document1.add(paragraph1);
			document1.add(otherParagraph1);
			document1.close();
			bytearray.writeTo(new java.io.FileOutputStream("newPdfFile.pdf")); 
			bytearray.flush();
			bytearray.close();
			
	        System.out.println( "PDF Created!" );
	    }


}
