package reportdata;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.bt.common.AbstractDAO;
import com.bt.dao.ReportDataDAO;
import com.bt.dao.impl.ReportDataDAOImpl;
import com.bt.service.ReportDataService;
import com.bt.service.impl.ReportDataServiceImpl;

@Configuration
public class MainAppConfiguration {

	@Bean
	public ReportDataDAO getReportDataDAO() {
		return new ReportDataDAOImpl();
	}

	@Bean
	public ReportDataService getReportDataService() {
		return new ReportDataServiceImpl();
	}
	
	@Bean
	public AbstractDAO getAbstractDAO() {
		return new AbstractDAO();
	}
	
	
}
