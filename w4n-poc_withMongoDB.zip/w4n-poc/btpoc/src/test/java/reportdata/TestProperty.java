package reportdata;

import java.util.Properties;

import com.bt.config.PropertyLoader;

public class TestProperty {
	
	    
	  public static void main(String args[]){
		  PropertyLoader propload= null;//PropertyLoader.getInstance();
		  Properties prop=  propload.getConfigProp();
		  System.out.println(prop.get("cassandra.contactpoints"));
		  System.out.println(prop.get("cassandra.port"));
		  System.out.println(prop.get("cassandra.keyspace"));
	  }  
}
